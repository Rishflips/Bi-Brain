/** Reviewer-only panel. Clearly separate from the product; lets every state be reached deterministically. */
import type { FixtureControls } from '../adapters/BrainAdapter';
import { Button } from '../components/Button';
import { Dialog } from '../components/Dialog';
import type { Appearance, BrainState } from '../domain/types';

const STATES: [BrainState, string][] = [
  ['new', 'New'],
  ['quiet', 'Quiet'],
  ['active', 'Active'],
  ['review', 'Review'],
  ['failure', 'Failure'],
  ['paused', 'Paused'],
  ['offline', 'Offline'],
];

export interface PrototypeControlsProps {
  brainState: BrainState;
  fixture: FixtureControls;
  appearance: Appearance;
  reducedMotionOverride: boolean | null;
  onBrainState: (s: BrainState) => void;
  onFixture: (patch: Partial<FixtureControls>) => void;
  onAppearance: (a: Appearance) => void;
  onReducedMotion: (v: boolean | null) => void;
  onResetDemo: () => void;
  onFirstUse: () => void;
  onClose: () => void;
}

export function PrototypeControls(p: PrototypeControlsProps) {
  return (
    <Dialog
      title="Prototype controls"
      description="For reviewing states only. These are not part of BiBrain."
      onClose={p.onClose}
      size="side"
      footer={
        <Button variant="primary" onClick={p.onClose}>
          Done
        </Button>
      }
    >
      <Radio legend="Today state" name="pc-state" value={p.brainState} options={STATES} onChange={p.onBrainState} />
      <Radio
        legend="Next save result"
        name="pc-save"
        value={p.fixture.nextSaveOutcome}
        options={[
          ['saved', 'Saved'],
          ['duplicate', 'Duplicate found'],
          ['write-failed', 'Write failed'],
        ]}
        onChange={(v) => p.onFixture({ nextSaveOutcome: v })}
      />
      <Radio
        legend="Preparation after save"
        name="pc-prep"
        value={p.fixture.preparationOutcome}
        options={[
          ['prepared', 'Prepared'],
          ['delayed', 'Delayed'],
          ['failed', 'Failed'],
        ]}
        onChange={(v) => p.onFixture({ preparationOutcome: v })}
      />
      <Radio
        legend="After “Keep this plan”"
        name="pc-later"
        value={p.fixture.laterWorkAfterAccept ? 'later' : 'clean'}
        options={[
          ['clean', 'Undo available'],
          ['later', 'Newer work exists (Compare versions)'],
        ]}
        onChange={(v) => p.onFixture({ laterWorkAfterAccept: v === 'later' })}
      />
      <Radio
        legend="Appearance"
        name="pc-app"
        value={p.appearance}
        options={[
          ['light', 'Light'],
          ['dark', 'Dark'],
          ['system', 'System'],
        ]}
        onChange={p.onAppearance}
      />
      <Radio
        legend="Motion"
        name="pc-motion"
        value={p.reducedMotionOverride ? 'reduce' : 'device'}
        options={[
          ['device', 'Follow device'],
          ['reduce', 'Reduce motion'],
        ]}
        onChange={(v) => p.onReducedMotion(v === 'reduce' ? true : null)}
      />
      <div className="bb-actions">
        <a className="bb-btn bb-btn--sm" href="#components" onClick={p.onClose}>
          Component states
        </a>
        <Button size="sm" onClick={p.onResetDemo}>
          Reset example
        </Button>
        <Button size="sm" onClick={p.onFirstUse}>
          Back to first use
        </Button>
      </div>
    </Dialog>
  );
}

function Radio<T extends string>({
  legend,
  name,
  value,
  options,
  onChange,
}: {
  legend: string;
  name: string;
  value: T;
  options: [T, string][];
  onChange: (v: T) => void;
}) {
  return (
    <fieldset style={{ border: 0, padding: 0, margin: 0 }}>
      <legend className="bb-label" style={{ marginBottom: 8 }}>
        {legend}
      </legend>
      <div className="bb-segmented">
        {options.map(([v, l]) => (
          <label key={v}>
            <input type="radio" name={name} value={v} checked={value === v} onChange={() => onChange(v)} />
            <span>{l}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
