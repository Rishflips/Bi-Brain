/**
 * Prototype controller — the ONLY place that holds app state and talks to an adapter.
 *
 * Screens and components receive view models + callbacks from here. To wire the
 * real product, keep the callback names and replace the adapter calls (and the
 * in-memory state updates that stand in for service responses).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { BrainAdapter, FixtureControls } from '../adapters/BrainAdapter';
import { CAPTURE_LIMIT_CHARS } from '../adapters/BrainAdapter';
import { createFixtureAdapter, FIXTURE_NOW } from '../adapters/fixtureAdapter';
import {
  DEMO_WORKSPACE_NAME,
  demoAgents,
  demoKnowledgeSources,
  demoPrepared,
  demoProjects,
  demoSources,
} from '../fixtures/demoWorkspace';
import type {
  AgentGrant,
  BackgroundHelpState,
  BrainState,
  CaptureDraft,
  CaptureState,
  KnowledgeSourceConnection,
  NoticeTone,
  PreparationState,
  PreparedItem,
  ProjectRef,
  SearchFilters,
  SearchScope,
  SearchState,
  SessionState,
  SettingsVM,
  SourceDetail,
  Toast,
} from '../domain/types';

export interface AppState {
  session: SessionState;
  brainState: BrainState;
  sources: SourceDetail[];
  projects: ProjectRef[];
  prepared: PreparedItem[];
  knowledge: KnowledgeSourceConnection[];
  agents: AgentGrant[];
  settings: SettingsVM;
  capture: {
    open: boolean;
    draft: CaptureDraft;
    state: CaptureState;
    preparation: PreparationState;
  };
  /** Transient: a save is being put in place (living field "organizing"). */
  organizing: boolean;
  /** Source whose preparation failed, for Today's failure state. */
  failedSourceId: string | null;
  search: { query: string; scope: SearchScope; filters: SearchFilters; state: SearchState };
  fixture: FixtureControls;
  reducedMotionOverride: boolean | null;
  toasts: Toast[];
}

const emptyDraft = (): CaptureDraft => ({ title: '', content: '', destination: null });

const defaultSettings = (): SettingsVM => ({
  appearance: 'system',
  backgroundHelp: {
    remember: true,
    prepare: true,
    paused: false,
    quietHoursOn: true,
    quietFrom: '21:00',
    quietTo: '07:30',
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local time',
  },
  spending: { providerConsent: false, dailyCap: '', perJobCap: '' },
});

const initialState = (): AppState => ({
  session: { kind: 'first-use' },
  brainState: 'new',
  sources: [],
  projects: [],
  prepared: [],
  knowledge: [],
  agents: [],
  settings: defaultSettings(),
  capture: { open: false, draft: emptyDraft(), state: { kind: 'empty' }, preparation: 'idle' },
  organizing: false,
  failedSourceId: null,
  search: { query: '', scope: { kind: 'everything' }, filters: { types: [], updated: 'any' }, state: { kind: 'empty' } },
  fixture: { nextSaveOutcome: 'saved', preparationOutcome: 'prepared', laterWorkAfterAccept: false },
  reducedMotionOverride: null,
  toasts: [],
});

/** Local-preview knowledge sources: available types only, nothing connected. */
const previewKnowledge = (): KnowledgeSourceConnection[] =>
  demoKnowledgeSources.map((k) => ({
    ...k,
    name: k.sourceType === 'Folder on this computer' ? 'A folder on this computer' : k.sourceType,
    scope: 'Not chosen yet',
    lastSuccessfulCheck: null,
    freshness: 'unknown',
    state: 'not-connected',
    importedCount: 0,
  }));

let toastSeq = 1;

export function usePrototypeController() {
  const [s, setS] = useState<AppState>(initialState);
  const stateRef = useRef(s);
  stateRef.current = s;
  const adapter: BrainAdapter = useMemo(() => createFixtureAdapter(() => stateRef.current.fixture), []);

  /* ---------- toasts ---------- */
  const toast = useCallback((tone: NoticeTone, text: string, action?: Toast['action']) => {
    const id = toastSeq++;
    setS((p) => ({ ...p, toasts: [...p.toasts.slice(-2), { id, tone, text, action }] }));
    window.setTimeout(() => setS((p) => ({ ...p, toasts: p.toasts.filter((t) => t.id !== id) })), 7000);
  }, []);
  const dismissToast = useCallback((id: number) => setS((p) => ({ ...p, toasts: p.toasts.filter((t) => t.id !== id) })), []);

  /* ---------- session ---------- */
  const startDemo = useCallback(() => {
    setS((p) => ({
      ...initialState(),
      settings: p.settings,
      fixture: p.fixture,
      reducedMotionOverride: p.reducedMotionOverride,
      session: { kind: 'demo', workspaceName: DEMO_WORKSPACE_NAME },
      brainState: 'review',
      sources: structuredClone(demoSources),
      projects: demoProjects,
      prepared: structuredClone(demoPrepared),
      knowledge: structuredClone(demoKnowledgeSources),
      agents: structuredClone(demoAgents),
    }));
  }, []);

  const pair = useCallback(
    async (code: string) => {
      setS((p) => ({ ...p, session: { kind: 'pairing' } }));
      const r = await adapter.pair(code);
      if (!r.ok) {
        setS((p) => ({ ...p, session: { kind: 'pairing-error', message: r.message } }));
        return;
      }
      setS((p) => ({
        ...initialState(),
        settings: p.settings,
        fixture: p.fixture,
        reducedMotionOverride: p.reducedMotionOverride,
        session: { kind: 'local', preview: true },
        brainState: 'new',
        projects: [],
        knowledge: previewKnowledge(),
      }));
    },
    [adapter],
  );

  const signOut = useCallback(() => {
    setS((p) => ({ ...initialState(), settings: p.settings, fixture: p.fixture, reducedMotionOverride: p.reducedMotionOverride }));
  }, []);

  /* ---------- capture ---------- */
  const openCapture = useCallback(() => {
    setS((p) => ({
      ...p,
      capture: {
        ...p.capture,
        open: true,
        // A retained draft (e.g. after a failed write) is kept; a finished receipt starts fresh.
        ...(p.capture.state.kind === 'saved' || p.capture.state.kind === 'duplicate'
          ? { draft: emptyDraft(), state: { kind: 'empty' as const }, preparation: 'idle' as const }
          : {}),
      },
    }));
  }, []);

  const closeCapture = useCallback(() => {
    setS((p) => {
      const keepDraft = p.capture.state.kind !== 'saved';
      return {
        ...p,
        capture: {
          ...p.capture,
          open: false,
          draft: keepDraft ? p.capture.draft : emptyDraft(),
          state: keepDraft ? p.capture.state : { kind: 'empty' },
        },
      };
    });
  }, []);

  const changeDraft = useCallback((draft: CaptureDraft) => {
    setS((p) => {
      const empty = !draft.title.trim() && !draft.content.trim();
      const tooLarge = draft.content.length > CAPTURE_LIMIT_CHARS;
      const state: CaptureState = tooLarge
        ? { kind: 'too-large', currentChars: draft.content.length, limitChars: CAPTURE_LIMIT_CHARS }
        : empty
          ? { kind: 'empty' }
          : p.capture.state.kind === 'write-failed' || p.capture.state.kind === 'unsupported-file'
            ? p.capture.state
            : { kind: 'drafting' };
      return { ...p, capture: { ...p.capture, draft, state } };
    });
  }, []);

  const importFile = useCallback(
    async (file: File) => {
      const r = await adapter.readImport(file);
      if (r.kind === 'unsupported') {
        setS((p) => ({ ...p, capture: { ...p.capture, state: { kind: 'unsupported-file', fileName: r.fileName } } }));
        return;
      }
      setS((p) => {
        const draft = {
          ...p.capture.draft,
          title: p.capture.draft.title || r.title,
          content: p.capture.draft.content ? `${p.capture.draft.content}\n\n${r.content}` : r.content,
          importedFileName: r.fileName,
        };
        const tooLarge = draft.content.length > CAPTURE_LIMIT_CHARS;
        return {
          ...p,
          capture: {
            ...p.capture,
            draft,
            state: tooLarge
              ? { kind: 'too-large', currentChars: draft.content.length, limitChars: CAPTURE_LIMIT_CHARS }
              : { kind: 'drafting' },
          },
        };
      });
    },
    [adapter],
  );

  const runPreparation = useCallback(
    async (sourceId: string) => {
      setS((p) => ({ ...p, organizing: true, capture: { ...p.capture, preparation: 'preparing' } }));
      const result = await adapter.prepare(sourceId);
      setS((p) => ({
        ...p,
        organizing: false,
        capture: { ...p.capture, preparation: result },
        failedSourceId: result === 'failed' ? sourceId : p.failedSourceId,
        brainState:
          result === 'failed'
            ? 'failure'
            : p.brainState === 'new' || p.brainState === 'failure'
              ? p.prepared.some((x) => x.status === 'prepared')
                ? 'review'
                : 'quiet'
              : p.brainState,
        sources: p.sources.map((src) =>
          src.id === sourceId ? { ...src, status: result === 'prepared' ? 'current' : src.status } : src,
        ),
      }));
    },
    [adapter],
  );

  const save = useCallback(
    async (opts?: { allowDuplicate?: boolean }) => {
      const p0 = stateRef.current;
      setS((p) => ({ ...p, capture: { ...p.capture, state: { kind: 'saving' } } }));
      const r = await adapter.save(p0.capture.draft, p0.sources, opts);
      if (r.kind === 'write-failed') {
        setS((p) => ({ ...p, capture: { ...p.capture, state: { kind: 'write-failed', message: r.message } } }));
        return;
      }
      if (r.kind === 'duplicate') {
        setS((p) => ({ ...p, capture: { ...p.capture, state: { kind: 'duplicate', existing: r.existing } } }));
        return;
      }
      const rc = r.receipt;
      const detail: SourceDetail = {
        id: rc.sourceId,
        title: rc.title,
        type: 'note',
        project: rc.destination,
        updatedAt: rc.savedAt.slice(0, 10),
        status: 'updating',
        excerpt: rc.retainedContent.slice(0, 220),
        original: rc.retainedContent || rc.title,
        sourceIdentifier: rc.sourceIdentifier,
        versions: [{ version: 1, savedAt: rc.savedAt.slice(0, 10), note: 'First saved' }],
        understanding: [],
        usedIn: [],
      };
      setS((p) => ({
        ...p,
        sources: [detail, ...p.sources],
        capture: { ...p.capture, draft: emptyDraft(), state: { kind: 'saved', receipt: rc }, preparation: 'idle' },
      }));
      void runPreparation(rc.sourceId);
    },
    [adapter, runPreparation],
  );

  const retryPreparation = useCallback(() => {
    const id = stateRef.current.failedSourceId ?? (stateRef.current.capture.state.kind === 'saved' ? stateRef.current.capture.state.receipt.sourceId : null);
    if (id) void runPreparation(id);
    else setS((p) => ({ ...p, brainState: 'quiet' }));
  }, [runPreparation]);

  /* ---------- search ---------- */
  const setQuery = useCallback((query: string) => setS((p) => ({ ...p, search: { ...p.search, query } })), []);
  const setScope = useCallback((scope: SearchScope) => setS((p) => ({ ...p, search: { ...p.search, scope } })), []);
  const setFilters = useCallback((filters: SearchFilters) => setS((p) => ({ ...p, search: { ...p.search, filters } })), []);

  const searchKey = JSON.stringify([s.search.query, s.search.scope, s.search.filters, s.sources.length]);
  useEffect(() => {
    const { query, scope, filters } = stateRef.current.search;
    if (!query.trim()) {
      setS((p) => ({ ...p, search: { ...p.search, state: { kind: 'empty' } } }));
      return;
    }
    setS((p) => ({ ...p, search: { ...p.search, state: { kind: 'loading', query } } }));
    let cancelled = false;
    const t = window.setTimeout(async () => {
      const results = await adapter.search(query, scope, filters, stateRef.current.sources);
      if (cancelled) return;
      setS((p) => ({
        ...p,
        search: {
          ...p.search,
          state: results.length ? { kind: 'results', query, results } : { kind: 'no-results', query },
        },
      }));
    }, 180);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [searchKey, adapter]);

  /* ---------- sources ---------- */
  const updateSource = (id: string, fn: (src: SourceDetail) => SourceDetail) =>
    setS((p) => ({ ...p, sources: p.sources.map((x) => (x.id === id ? fn(x) : x)) }));

  const editUnderstanding = useCallback((sourceId: string, statementId: string, text: string) => {
    updateSource(sourceId, (src) => ({
      ...src,
      understanding: src.understanding.map((u) =>
        u.id === statementId ? { ...u, kind: 'user-correction', text, note: 'You corrected this just now' } : u,
      ),
    }));
    toast('success', 'Correction saved. The original source is unchanged.');
  }, [toast]);

  const correctSource = useCallback((sourceId: string, newText: string) => {
    let version = 0;
    updateSource(sourceId, (src) => {
      version = src.versions.length + 1;
      return {
        ...src,
        original: newText,
        excerpt: newText.slice(0, 220),
        updatedAt: FIXTURE_NOW.slice(0, 10),
        versions: [...src.versions, { version, savedAt: FIXTURE_NOW.slice(0, 10), note: 'You corrected the source' }],
        // Anything derived from an older version is now marked as changed.
        understanding: src.understanding.map((u) =>
          u.citation && u.kind !== 'withdrawn' && u.citation.version < version
            ? { ...u, kind: 'stale', note: 'The source changed after this was written. Review before using it.' }
            : u,
        ),
      };
    });
    toast('success', `Source corrected and saved as a new version.`);
  }, [toast]);

  const withdrawSource = useCallback((sourceId: string, withdraw: boolean) => {
    updateSource(sourceId, (src) => ({
      ...src,
      status: withdraw ? 'withdrawn' : 'current',
      understanding: src.understanding.map((u) =>
        withdraw ? { ...u, kind: 'withdrawn', note: 'Withdrawn with its source.' } : u,
      ),
    }));
    toast('info', withdraw ? 'Withdrawn from active use. The original is kept.' : 'Returned to active use.');
  }, [toast]);

  const deleteSource = useCallback((sourceId: string) => {
    setS((p) => ({
      ...p,
      sources: p.sources.filter((x) => x.id !== sourceId),
      prepared: p.prepared.map((it) => ({
        ...it,
        evidence: it.evidence.map((e) => (e.sourceId === sourceId ? { ...e, available: false, quote: '' } : e)),
      })),
    }));
    toast('info', 'Deleted permanently.');
  }, [toast]);

  const copyBrief = useCallback(async (src: SourceDetail) => {
    const ok = await adapter.copyText(briefMarkdown(src));
    toast(ok ? 'success' : 'attention', ok ? 'Brief copied.' : 'Your browser blocked copying. Use Download Markdown instead.');
  }, [adapter, toast]);

  const downloadSource = useCallback((src: SourceDetail) => {
    adapter.downloadMarkdown(`${slug(src.title)}.md`, briefMarkdown(src));
  }, [adapter]);

  const exportAll = useCallback(() => {
    const all = stateRef.current.sources.map(briefMarkdown).join('\n\n---\n\n');
    adapter.downloadMarkdown('bibrain-export.md', all || '# Your brain\n\nNothing saved yet.\n');
    toast('success', 'Export downloaded as Markdown.');
  }, [adapter, toast]);

  const deleteEverything = useCallback(() => {
    setS((p) => ({ ...p, sources: [], prepared: [], brainState: 'new', failedSourceId: null }));
    toast('info', 'Everything in this brain was deleted.');
  }, [toast]);

  /* ---------- prepared work ---------- */
  const setPrepared = (id: string, patch: Partial<PreparedItem>) =>
    setS((p) => {
      const prepared = p.prepared.map((x) => (x.id === id ? { ...x, ...patch } : x));
      const anyOpen = prepared.some((x) => x.status === 'prepared' || x.status === 'stale');
      return {
        ...p,
        prepared,
        brainState: p.brainState === 'review' && !anyOpen ? 'quiet' : p.brainState === 'quiet' && anyOpen ? 'review' : p.brainState,
      };
    });

  const acceptPrepared = useCallback((id: string, artifact: string) => {
    const later = stateRef.current.fixture.laterWorkAfterAccept;
    setPrepared(id, { status: 'accepted', artifact, laterWorkExists: later });
    toast(
      'success',
      'Plan kept. Saved as a new version.',
      later ? undefined : { label: 'Undo', onAction: () => undoPrepared(id) },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toast]);

  const undoPrepared = useCallback((id: string) => {
    setPrepared(id, { status: 'prepared', laterWorkExists: false });
    toast('info', 'Undone. The earlier version was saved as a new version.');
  }, [toast]);

  const snoozePrepared = useCallback((id: string) => {
    setPrepared(id, { status: 'snoozed' });
    toast('info', 'Moved to later.', { label: 'Undo', onAction: () => setPrepared(id, { status: 'prepared' }) });
  }, [toast]);

  const dismissPrepared = useCallback((id: string) => {
    setPrepared(id, { status: 'dismissed' });
    toast('info', 'Marked not useful.', { label: 'Undo', onAction: () => setPrepared(id, { status: 'prepared' }) });
  }, [toast]);

  const restorePrepared = useCallback((id: string) => setPrepared(id, { status: 'prepared' }), []);

  /* ---------- connections ---------- */
  const setKnowledge = (id: string, patch: Partial<KnowledgeSourceConnection>) =>
    setS((p) => ({ ...p, knowledge: p.knowledge.map((k) => (k.id === id ? { ...k, ...patch } : k)) }));
  const setAgent = (id: string, patch: Partial<AgentGrant>) =>
    setS((p) => ({ ...p, agents: p.agents.map((a) => (a.id === id ? { ...a, ...patch } : a)) }));

  const connectKnowledge = useCallback((id: string) => setKnowledge(id, { state: 'awaiting-authorization' }), []);
  const cancelKnowledge = useCallback((id: string) => setKnowledge(id, { state: 'not-connected' }), []);
  const disconnectKnowledge = useCallback((id: string, removeImported: boolean) => {
    setKnowledge(id, { state: 'not-connected', ...(removeImported ? { importedCount: 0 } : {}), lastSuccessfulCheck: null, freshness: 'unknown' });
    toast('info', removeImported ? 'Disconnected. Imported notes were removed.' : 'Disconnected. Imported notes were kept.');
  }, [toast]);

  const createAgentGrant = useCallback((label: string, projectIds: string[], canPropose: boolean, days: number) => {
    const projects = stateRef.current.projects.filter((x) => projectIds.includes(x.id));
    const exp = new Date(Date.parse(FIXTURE_NOW) + days * 86_400_000).toISOString().slice(0, 10);
    setS((p) => ({
      ...p,
      agents: [
        ...p.agents,
        {
          id: `ag-${Date.now()}`,
          kind: 'agent',
          label,
          readableProjects: projects,
          canPropose,
          expiresAt: exp,
          lastVerifiedAccess: null,
          state: 'awaiting-authorization',
        },
      ],
    }));
  }, []);

  const updateAgentGrant = useCallback((id: string, patch: Partial<AgentGrant>) => {
    setAgent(id, patch);
    toast('success', 'Access updated.');
  }, [toast]);

  const revokeAgent = useCallback((id: string) => {
    setAgent(id, { state: 'revoked', readableProjects: [], canPropose: false });
    toast('info', 'Access revoked.');
  }, [toast]);

  const cancelAgent = useCallback((id: string) => {
    // Never verified → the pending grant simply goes away. Previously verified → revoked.
    setS((p) => ({
      ...p,
      agents: p.agents.flatMap((a) =>
        a.id !== id ? [a] : a.lastVerifiedAccess ? [{ ...a, state: 'revoked' as const }] : [],
      ),
    }));
  }, []);

  const revokeAllAgents = useCallback(() => {
    setS((p) => ({ ...p, agents: p.agents.map((a) => ({ ...a, state: 'revoked', readableProjects: [], canPropose: false })) }));
    toast('info', 'All agent access revoked.');
  }, [toast]);

  /* ---------- settings + prototype controls ---------- */
  const updateSettings = useCallback((patch: (s: SettingsVM) => SettingsVM) => {
    setS((p) => {
      const settings = patch(p.settings);
      let brainState = p.brainState;
      if (settings.backgroundHelp.paused && !p.settings.backgroundHelp.paused) brainState = 'paused';
      if (!settings.backgroundHelp.paused && p.brainState === 'paused') brainState = p.prepared.some((x) => x.status === 'prepared') ? 'review' : 'quiet';
      return { ...p, settings, brainState };
    });
  }, []);

  const setBrainState = useCallback((brainState: BrainState) => {
    setS((p) => ({
      ...p,
      brainState,
      failedSourceId: brainState === 'failure' ? p.failedSourceId ?? p.sources[0]?.id ?? null : p.failedSourceId,
      settings: { ...p.settings, backgroundHelp: { ...p.settings.backgroundHelp, paused: brainState === 'paused' } },
    }));
  }, []);

  const setFixture = useCallback((patch: Partial<FixtureControls>) => setS((p) => ({ ...p, fixture: { ...p.fixture, ...patch } })), []);
  const setReducedMotionOverride = useCallback((v: boolean | null) => setS((p) => ({ ...p, reducedMotionOverride: v })), []);

  const backgroundHelp: BackgroundHelpState =
    s.brainState === 'offline'
      ? 'offline'
      : s.settings.backgroundHelp.paused || s.brainState === 'paused'
        ? 'paused'
        : 'on';

  return {
    state: s,
    backgroundHelp,
    toast,
    dismissToast,
    session: { startDemo, pair, signOut },
    capture: { openCapture, closeCapture, changeDraft, importFile, save, retryPreparation },
    search: { setQuery, setScope, setFilters },
    sources: { editUnderstanding, correctSource, withdrawSource, deleteSource, copyBrief, downloadSource, exportAll, deleteEverything },
    prepared: { acceptPrepared, undoPrepared, snoozePrepared, dismissPrepared, restorePrepared },
    connections: {
      connectKnowledge,
      cancelKnowledge,
      disconnectKnowledge,
      createAgentGrant,
      updateAgentGrant,
      revokeAgent,
      cancelAgent,
      revokeAllAgents,
    },
    settings: { updateSettings },
    prototype: { setBrainState, setFixture, setReducedMotionOverride },
  };
}

export type Controller = ReturnType<typeof usePrototypeController>;

function slug(t: string) {
  return t.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'note';
}

export function briefMarkdown(src: SourceDetail): string {
  const lines = [
    `# ${src.title}`,
    '',
    `- Project: ${src.project?.name ?? 'Inbox'}`,
    `- Source ID: ${src.sourceIdentifier}`,
    `- Version: ${src.versions.length}`,
    '',
    '## Original',
    '',
    src.original,
  ];
  const usable = src.understanding.filter((u) => u.kind === 'source-backed' || u.kind === 'user-correction');
  if (usable.length) {
    lines.push('', '## What BiBrain remembers', '');
    for (const u of usable) lines.push(`- ${u.text}${u.kind === 'user-correction' ? ' (your correction)' : ''}`);
  }
  return lines.join('\n');
}
