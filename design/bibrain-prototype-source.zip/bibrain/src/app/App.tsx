/**
 * App container: routes, theme, motion, and wiring between the controller
 * (state + fixture adapter) and presentational screens.
 */
import { useEffect, useRef, useState } from 'react';
import { usePrototypeController } from './controller';
import { PrototypeControls } from './PrototypeControls';
import { AppShell, type NavItem } from '../components/AppShell';
import { DemoBanner, Toasts } from '../components/Feedback';
import { Dialog } from '../components/Dialog';
import { RevisionComparison } from '../components/Prepared';
import type { SourceTab } from '../components/SourceViewer';
import { CAPTURE_LIMIT_CHARS } from '../adapters/BrainAdapter';
import { useHashRoute, useMediaQuery } from '../lib/hooks';
import { FirstUseScreen } from '../screens/FirstUseScreen';
import { TodayScreen } from '../screens/TodayScreen';
import { SaveSheet } from '../screens/SaveSheet';
import { BrainScreen } from '../screens/BrainScreen';
import { ConnectionsScreen } from '../screens/ConnectionsScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { ComponentGallery } from '../screens/ComponentGallery';

const ROUTE_TITLES = {
  today: 'Today',
  brain: 'Your brain',
  connections: 'Connections',
  settings: 'Settings & privacy',
  components: 'Component states',
} as const;

export function App() {
  const c = usePrototypeController();
  const s = c.state;
  const [route, navigate] = useHashRoute();
  const deviceReduced = useMediaQuery('(prefers-reduced-motion: reduce)');
  const reducedMotion = s.reducedMotionOverride ?? deviceReduced;
  const wide = useMediaQuery('(min-width: 1200px)');
  const [controlsOpen, setControlsOpen] = useState(false);
  const [tab, setTab] = useState<SourceTab>('original');
  const [focusVersion, setFocusVersion] = useState<number | undefined>();
  const [focusSearch, setFocusSearch] = useState(false);
  const [announcement, setAnnouncement] = useState('');
  const brainScroll = useRef(0);
  const [compareId, setCompareId] = useState<string | null>(null);

  /* Appearance */
  useEffect(() => {
    const root = document.documentElement;
    if (s.settings.appearance === 'system') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', s.settings.appearance);
  }, [s.settings.appearance]);
  useEffect(() => {
    document.documentElement.classList.toggle('reduce-motion', Boolean(s.reducedMotionOverride));
  }, [s.reducedMotionOverride]);

  /* Route announcements + focus management */
  const inApp = s.session.kind === 'demo' || s.session.kind === 'local';
  const routeKey = route.name;
  const firstRender = useRef(true);
  useEffect(() => {
    if (!inApp) {
      document.title = 'BiBrain — Open your local brain';
      return;
    }
    const title = ROUTE_TITLES[route.name];
    document.title = `${title} · BiBrain`;
    if (firstRender.current) {
      firstRender.current = false;
      window.scrollTo({ top: 0 });
      return;
    }
    setAnnouncement(title);
    const h1 = document.querySelector<HTMLElement>('main h1');
    (h1 ?? document.getElementById('main'))?.focus({ preventScroll: true });
    window.scrollTo({ top: 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeKey, inApp]);

  /* Source detail navigation (preserves query; restores scroll on phones) */
  const openSource = (id: string, version?: number) => {
    if (!(route.name === 'brain' && route.sourceId)) brainScroll.current = window.scrollY;
    setTab('original');
    setFocusVersion(version);
    c.capture.closeCapture();
    navigate({ name: 'brain', sourceId: id });
    if (wide) window.setTimeout(() => document.querySelector<HTMLElement>('.bb-panel h2')?.focus(), 30);
    else window.setTimeout(() => document.querySelector<HTMLElement>('.bb-panel h2')?.focus(), 30);
  };
  const closeSource = () => {
    navigate({ name: 'brain' });
    const y = brainScroll.current;
    window.setTimeout(() => window.scrollTo({ top: y }), 20);
  };
  const findInBrain = () => {
    c.capture.closeCapture();
    navigate({ name: 'brain' });
    setFocusSearch(true);
  };
  const openPrepared = (id: string) => {
    navigate({ name: 'today' });
    window.setTimeout(() => {
      const el = document.getElementById(`prepared-${id}`);
      el?.scrollIntoView({ block: 'center' });
      el?.querySelector<HTMLElement>('h2, h3')?.setAttribute('tabindex', '-1');
      el?.querySelector<HTMLElement>('h2, h3')?.focus();
    }, 60);
  };

  if (!inApp) {
    return (
      <FirstUseScreen
        state={s.session.kind === 'pairing' ? 'pairing' : s.session.kind === 'pairing-error' ? 'error' : 'idle'}
        errorMessage={s.session.kind === 'pairing-error' ? s.session.message : undefined}
        onOpenBrain={(code) => {
          void c.session.pair(code).then(() => navigate({ name: 'today' }));
        }}
        onTryExample={() => {
          c.session.startDemo();
          navigate({ name: 'today' });
        }}
      />
    );
  }

  const isDemo = s.session.kind === 'demo';
  const openPreparedCount = s.prepared.filter((x) => x.status === 'prepared' || x.status === 'stale').length;
  const nav: NavItem[] = [
    { id: 'today', label: 'Today', href: '#today', icon: 'today', attention: s.brainState === 'review' ? openPreparedCount : undefined },
    { id: 'brain', label: 'Your brain', href: '#brain', icon: 'brain' },
    { id: 'connections', label: 'Connections', href: '#connections', icon: 'connections' },
  ];
  const selected = route.name === 'brain' && route.sourceId ? s.sources.find((x) => x.id === route.sourceId) ?? null : null;
  const missingSourceId = route.name === 'brain' && route.sourceId && !selected ? route.sourceId : null;
  const recent = [...s.sources].filter((x) => x.status !== 'withdrawn').sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));

  return (
    <>
      <AppShell
        route={route}
        nav={nav}
        backgroundHelp={c.backgroundHelp}
        onSaveSomething={c.capture.openCapture}
        onOpenPrototypeControls={() => setControlsOpen(true)}
      >
        <div className="bb-modebar">
          <div style={{ flex: 1, minWidth: 0 }}>
            <DemoBanner mode={isDemo ? 'demo' : 'preview'} onLeave={c.session.signOut} />
          </div>
        </div>
        <div className="bb-route" key={route.name}>
          {route.name === 'today' ? (
            <TodayScreen
              brainState={s.brainState}
              organizing={s.organizing}
              reducedMotion={reducedMotion}
              prepared={s.prepared}
              recent={recent}
              backgroundHelp={c.backgroundHelp}
              failedSourceId={s.failedSourceId}
              checkingCount={Math.min(2, s.sources.length)}
              onSaveSomething={c.capture.openCapture}
              onFind={findInBrain}
              onOpenSource={openSource}
              onRetryPreparation={c.capture.retryPreparation}
              onResumeHelp={() => c.prototype.setBrainState(openPreparedCount ? 'review' : 'quiet')}
              onTryExample={isDemo ? undefined : () => c.session.startDemo()}
              preparedHandlers={{
                onAccept: c.prepared.acceptPrepared,
                onUndo: c.prepared.undoPrepared,
                onCompare: (id) => setCompareId(id),
                onSnooze: c.prepared.snoozePrepared,
                onDismiss: c.prepared.dismissPrepared,
                onRestore: c.prepared.restorePrepared,
                onPrepareAgain: () => c.toast('info', 'Preparing again isn’t available in this preview.'),
              }}
            />
          ) : null}
          {route.name === 'brain' ? (
            <BrainScreen
              isDemo={isDemo}
              offline={s.brainState === 'offline'}
              wide={wide}
              sources={s.sources}
              projects={s.projects}
              query={s.search.query}
              scope={s.search.scope}
              filters={s.search.filters}
              searchState={s.search.state}
              selected={selected}
              missingSourceId={missingSourceId}
              tab={tab}
              focusVersion={focusVersion}
              focusSearch={focusSearch}
              onFocusedSearch={() => setFocusSearch(false)}
              onQuery={c.search.setQuery}
              onScope={c.search.setScope}
              onFilters={c.search.setFilters}
              onOpenSource={openSource}
              onCloseSource={closeSource}
              onTab={setTab}
              onSaveSomething={c.capture.openCapture}
              onOpenPrepared={openPrepared}
              onEditUnderstanding={c.sources.editUnderstanding}
              onCorrectSource={c.sources.correctSource}
              onWithdraw={c.sources.withdrawSource}
              onDelete={c.sources.deleteSource}
              onCopyBrief={c.sources.copyBrief}
              onDownload={c.sources.downloadSource}
            />
          ) : null}
          {route.name === 'connections' ? (
            <ConnectionsScreen
              isDemo={isDemo}
              offline={s.brainState === 'offline'}
              knowledge={s.knowledge}
              agents={s.agents}
              projects={s.projects}
              sources={s.sources}
              onConnect={c.connections.connectKnowledge}
              onCancelKnowledge={c.connections.cancelKnowledge}
              onDisconnect={c.connections.disconnectKnowledge}
              onCreateGrant={c.connections.createAgentGrant}
              onUpdateGrant={c.connections.updateAgentGrant}
              onRevoke={c.connections.revokeAgent}
              onCancelAgent={c.connections.cancelAgent}
            />
          ) : null}
          {route.name === 'settings' ? (
            <SettingsScreen
              settings={s.settings}
              reducedMotion={reducedMotion}
              isDemo={isDemo}
              agents={s.agents}
              sourceCount={s.sources.length}
              onChange={c.settings.updateSettings}
              onExport={c.sources.exportAll}
              onDeleteEverything={c.sources.deleteEverything}
              onRevokeAll={c.connections.revokeAllAgents}
              onSignOut={c.session.signOut}
            />
          ) : null}
          {route.name === 'components' ? <ComponentGallery reducedMotion={reducedMotion} /> : null}
        </div>
      </AppShell>

      {s.capture.open ? (
        <SaveSheet
          draft={s.capture.draft}
          state={s.capture.state}
          preparation={s.capture.preparation}
          projects={s.projects}
          limitChars={CAPTURE_LIMIT_CHARS}
          onChange={c.capture.changeDraft}
          onImportFile={c.capture.importFile}
          onSave={c.capture.save}
          onClose={c.capture.closeCapture}
          onViewOriginal={(id) => openSource(id)}
          onFindInBrain={findInBrain}
          onSaveAnother={() => {
            c.capture.closeCapture();
            window.setTimeout(c.capture.openCapture, 0);
          }}
          onRetryPreparation={c.capture.retryPreparation}
        />
      ) : null}

      {compareId
        ? (() => {
            const it = s.prepared.find((x) => x.id === compareId);
            if (!it) return null;
            return (
              <Dialog title="Compare versions" description={it.title} onClose={() => setCompareId(null)}>
                <RevisionComparison
                  state="newer-edit"
                  before={it.earlierUnderstanding}
                  kept={it.artifact}
                  newer={`${it.artifact}\n4. Share the plan with the two interview partners. (demo edit made after you kept it)`}
                  onKeepCurrent={() => setCompareId(null)}
                  onRestoreEarlier={() => {
                    c.prepared.undoPrepared(it.id);
                    setCompareId(null);
                  }}
                />
              </Dialog>
            );
          })()
        : null}

      {controlsOpen ? (
        <PrototypeControls
          brainState={s.brainState}
          fixture={s.fixture}
          appearance={s.settings.appearance}
          reducedMotionOverride={s.reducedMotionOverride}
          onBrainState={c.prototype.setBrainState}
          onFixture={c.prototype.setFixture}
          onAppearance={(a) => c.settings.updateSettings((x) => ({ ...x, appearance: a }))}
          onReducedMotion={c.prototype.setReducedMotionOverride}
          onResetDemo={() => {
            c.session.startDemo();
            setControlsOpen(false);
            navigate({ name: 'today' });
          }}
          onFirstUse={() => {
            c.session.signOut();
            setControlsOpen(false);
          }}
          onClose={() => setControlsOpen(false)}
        />
      ) : null}

      <Toasts toasts={s.toasts} onDismiss={c.dismissToast} />
      <div className="visually-hidden" aria-live="polite" role="status">
        {announcement}
      </div>
    </>
  );
}
