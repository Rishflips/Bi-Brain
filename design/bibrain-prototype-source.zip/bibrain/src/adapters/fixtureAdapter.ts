/**
 * FIXTURE ADAPTER — prototype only.
 *
 * Deterministic stand-ins for BiBrain services. Delays are fixed so every
 * transition is repeatable. Nothing here contacts a network, a model
 * provider, a payment system, or an external account. Each method is listed
 * in HANDOFF.md under "Fixture behaviors that need real wiring".
 */
import type { BrainAdapter, FixtureControls, ImportResult } from './BrainAdapter';
import { ACCEPTED_IMPORT_EXTENSIONS } from './BrainAdapter';
import type { SearchResult, SourceSummary } from '../domain/types';

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Fixed clock so receipts are deterministic. */
export const FIXTURE_NOW = '2026-10-19T09:30:00';

let fixtureCounter = 200;

export function createFixtureAdapter(getControls: () => FixtureControls): BrainAdapter {
  return {
    async pair(code) {
      await wait(700);
      const clean = code.trim().toUpperCase();
      if (!clean) return { ok: false, message: 'Enter the installation code to continue.' };
      if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(clean)) {
        return { ok: false, message: 'That code does not match. Codes look like ABCD-1234-EFGH.' };
      }
      // FIXTURE: the real app verifies the code with the local installation.
      return { ok: true };
    },

    async save(draft, existing, options) {
      await wait(650);
      const outcome = getControls().nextSaveOutcome;
      if (outcome === 'write-failed') {
        return {
          kind: 'write-failed',
          message: 'BiBrain could not write this note. Your draft is still here.',
        };
      }
      if (!options?.allowDuplicate) {
        const exact = existing.find(
          (s) => draft.title.trim() && s.title.trim().toLowerCase() === draft.title.trim().toLowerCase(),
        );
        const dup = exact ?? (outcome === 'duplicate' ? existing[0] : undefined);
        if (dup) return { kind: 'duplicate', existing: dup };
      }
      fixtureCounter += 1;
      return {
        kind: 'saved',
        receipt: {
          sourceId: `local-src-${fixtureCounter}`,
          // The receipt shows what the service RETAINED (here: trimmed text).
          title: draft.title.trim() || 'Untitled note',
          retainedContent: draft.content.trim(),
          sourceIdentifier: `local-src-${String(fixtureCounter).padStart(4, '0')}`,
          destination: draft.destination,
          savedAt: FIXTURE_NOW,
        },
      };
    },

    async prepare() {
      await wait(1800);
      return getControls().preparationOutcome;
    },

    async search(query, scope, filters, corpus) {
      await wait(280);
      const words = query.toLowerCase().split(/\s+/).filter(Boolean);
      const inScope = (s: SourceSummary) =>
        scope.kind === 'everything' ||
        (scope.kind === 'inbox' && s.project === null) ||
        (scope.kind === 'project' && s.project?.id === scope.projectId);
      const inFilters = (s: SourceSummary) => {
        if (filters.types.length && !filters.types.includes(s.type)) return false;
        if (filters.updated !== 'any') {
          const days = (Date.parse(FIXTURE_NOW) - Date.parse(s.updatedAt)) / 86_400_000;
          if (filters.updated === 'week' && days > 7) return false;
          if (filters.updated === 'month' && days > 31) return false;
        }
        return true;
      };
      const results: SearchResult[] = [];
      for (const s of corpus) {
        if (!inScope(s) || !inFilters(s)) continue;
        const hay = `${s.title} ${s.excerpt}`.toLowerCase();
        if (!words.every((w) => hay.includes(w))) continue;
        results.push(makeSnippet(s, words));
      }
      return results;
    },

    async readImport(file): Promise<ImportResult> {
      const lower = file.name.toLowerCase();
      if (!ACCEPTED_IMPORT_EXTENSIONS.some((ext) => lower.endsWith(ext))) {
        return { kind: 'unsupported', fileName: file.name };
      }
      const text = await file.text();
      return { kind: 'ok', fileName: file.name, title: file.name.replace(/\.(md|txt)$/i, ''), content: text };
    },

    async copyText(text) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch {
        return false;
      }
    },

    downloadMarkdown(fileName, markdown) {
      const blob = new Blob([markdown], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },
  };
}

/** One bounded snippet (max ~140 chars) around the first matched word. Keyword match only. */
function makeSnippet(s: SourceSummary, words: string[]): SearchResult {
  const text = s.excerpt;
  const lower = text.toLowerCase();
  const first = Math.min(...words.map((w) => lower.indexOf(w)).filter((i) => i >= 0), Infinity);
  const start = Number.isFinite(first) ? Math.max(0, first - 40) : 0;
  const end = Math.min(text.length, start + 140);
  const prefix = start > 0 ? '…' : '';
  const suffix = end < text.length ? '…' : '';
  const snippet = prefix + text.slice(start, end) + suffix;
  const sl = snippet.toLowerCase();
  const highlights: [number, number][] = [];
  for (const w of words) {
    let i = sl.indexOf(w);
    while (i >= 0) {
      highlights.push([i, i + w.length]);
      i = sl.indexOf(w, i + w.length);
    }
  }
  highlights.sort((a, b) => a[0] - b[0]);
  return { source: s, snippet, highlights };
}
