/**
 * The seam between the interface and BiBrain services.
 *
 * The prototype ships ONE implementation: `fixtureAdapter` (deterministic,
 * in-memory, no network). The wired application replaces it with an adapter
 * that calls the existing BiBrain services. Visual components never import
 * an adapter — only the container in `app/App.tsx` does.
 */
import type {
  CaptureDraft,
  SavedReceiptVM,
  SearchFilters,
  SearchResult,
  SearchScope,
  SourceSummary,
} from '../domain/types';

export type PairResult = { ok: true } | { ok: false; message: string };

export type SaveResult =
  | { kind: 'saved'; receipt: SavedReceiptVM }
  | { kind: 'duplicate'; existing: SourceSummary }
  | { kind: 'write-failed'; message: string };

export type PreparationResult = 'prepared' | 'delayed' | 'failed';

export type ImportResult =
  | { kind: 'ok'; title: string; content: string; fileName: string }
  | { kind: 'unsupported'; fileName: string };

export interface BrainAdapter {
  pair(code: string): Promise<PairResult>;
  save(draft: CaptureDraft, existing: SourceSummary[], options?: { allowDuplicate?: boolean }): Promise<SaveResult>;
  prepare(sourceId: string): Promise<PreparationResult>;
  search(query: string, scope: SearchScope, filters: SearchFilters, corpus: SourceSummary[]): Promise<SearchResult[]>;
  readImport(file: File): Promise<ImportResult>;
  copyText(text: string): Promise<boolean>;
  downloadMarkdown(fileName: string, markdown: string): void;
}

/** Reviewer-controlled outcomes so every state is reachable deterministically. */
export interface FixtureControls {
  nextSaveOutcome: 'saved' | 'duplicate' | 'write-failed';
  preparationOutcome: PreparationResult;
  laterWorkAfterAccept: boolean;
}

export const CAPTURE_LIMIT_CHARS = 20_000;
export const ACCEPTED_IMPORT_EXTENSIONS = ['.txt', '.md'];
