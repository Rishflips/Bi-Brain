/**
 * DEMO DATA — synthetic content for the "Northstar launch" example workspace.
 *
 * Nothing in this file is user history, a real integration, or output from a
 * real provider. It exists so reviewers can see every state of the interface.
 * The interface labels everything that comes from here as "Demo data".
 */
import type {
  AgentGrant,
  KnowledgeSourceConnection,
  PreparedItem,
  ProjectRef,
  SourceDetail,
} from '../domain/types';

export const DEMO_WORKSPACE_NAME = 'Northstar launch';

export const northstar: ProjectRef = { id: 'northstar', name: 'Northstar launch' };

export const demoProjects: ProjectRef[] = [northstar];

export const demoSources: SourceDetail[] = [
  {
    id: 'decision-invite',
    title: 'Invite ten research partners before opening sign-ups',
    type: 'decision',
    project: northstar,
    updatedAt: '2026-10-14',
    status: 'current',
    excerpt:
      'We will invite ten research partners first and open sign-ups only after their first week of use.',
    sourceIdentifier: 'demo-src-0142',
    original: [
      'Decision',
      '',
      'We will invite ten research partners first and open sign-ups only after their first week of use.',
      '',
      'Why: the interviews showed that small teams want a guided start. Ten partners is a number we can support personally.',
      '',
      'Owner: founder. Partners are invited one by one, not through an automated email.',
    ].join('\n'),
    versions: [
      { version: 1, savedAt: '2026-10-09', note: 'First saved' },
      { version: 2, savedAt: '2026-10-14', note: 'You added who sends the invites' },
    ],
    understanding: [
      {
        id: 'u1',
        kind: 'source-backed',
        text: 'Ten research partners are invited before sign-ups open.',
        citation: {
          sourceId: 'decision-invite',
          version: 2,
          quote: 'We will invite ten research partners first and open sign-ups only after their first week of use.',
        },
      },
      {
        id: 'u2',
        kind: 'user-correction',
        text: 'Partners are invited personally by the founder, not by automated email.',
        note: 'You corrected this on Oct 14',
        citation: {
          sourceId: 'decision-invite',
          version: 2,
          quote: 'Partners are invited one by one, not through an automated email.',
        },
      },
      {
        id: 'u3',
        kind: 'hypothesis',
        text: 'Sign-ups might open about a week after the first partner starts.',
        note: 'Not stated directly. Treat as a guess until you confirm it.',
      },
      {
        id: 'u4',
        kind: 'updating',
        text: 'Checking how this decision relates to the second interview note.',
      },
      {
        id: 'u5',
        kind: 'stale',
        text: 'The partner list is final.',
        note: 'The source changed after this was written. Review before using it.',
        citation: { sourceId: 'decision-invite', version: 1, quote: 'Partner list: final.' },
      },
      {
        id: 'u6',
        kind: 'withdrawn',
        text: 'Sign-ups open at the same time as partner invites.',
        note: 'You withdrew this from active use on Oct 12.',
      },
    ],
    usedIn: [{ id: 'prep-compare', title: 'Compare the saved launch decision with two interview notes', kind: 'prepared' }],
  },
  {
    id: 'note-themes',
    title: 'Private beta interview themes',
    type: 'note',
    project: northstar,
    updatedAt: '2026-10-16',
    status: 'current',
    excerpt:
      'Three themes kept coming up: people want a guided start, they worry about losing context between tools, and they want to see where an answer came from.',
    sourceIdentifier: 'demo-src-0151',
    original: [
      'Private beta interview themes',
      '',
      '1. People want a guided start, not a blank page.',
      '2. They worry about losing context when they switch between tools.',
      '3. They want to see where an answer came from before they trust it.',
      '',
      'Quote worth keeping: "I don\'t want to explain my project again every Monday."',
    ].join('\n'),
    versions: [{ version: 1, savedAt: '2026-10-16', note: 'First saved' }],
    understanding: [
      {
        id: 't1',
        kind: 'source-backed',
        text: 'Interviewees want a guided start rather than a blank page.',
        citation: { sourceId: 'note-themes', version: 1, quote: 'People want a guided start, not a blank page.' },
      },
      {
        id: 't2',
        kind: 'source-backed',
        text: 'Seeing where an answer came from matters for trust.',
        citation: {
          sourceId: 'note-themes',
          version: 1,
          quote: 'They want to see where an answer came from before they trust it.',
        },
      },
    ],
    usedIn: [{ id: 'prep-themes', title: 'Summarize interview themes for the launch brief', kind: 'prepared' }],
  },
  {
    id: 'note-interview-1',
    title: 'Interview note — research partner A',
    type: 'note',
    project: northstar,
    updatedAt: '2026-10-15',
    status: 'current',
    excerpt: 'Partner A would wait for an invite but asked for a waiting list so their teammates are not forgotten.',
    sourceIdentifier: 'demo-src-0147',
    original: [
      'Interview note — research partner A (synthetic)',
      '',
      'Happy to wait for an invite.',
      'Asked for a waiting list so their two teammates are not forgotten.',
      'Would use it mostly on Monday planning.',
    ].join('\n'),
    versions: [{ version: 1, savedAt: '2026-10-15', note: 'First saved' }],
    understanding: [
      {
        id: 'a1',
        kind: 'source-backed',
        text: 'Partner A asked for a waiting list for teammates.',
        citation: {
          sourceId: 'note-interview-1',
          version: 1,
          quote: 'Asked for a waiting list so their two teammates are not forgotten.',
        },
      },
    ],
    usedIn: [{ id: 'prep-compare', title: 'Compare the saved launch decision with two interview notes', kind: 'prepared' }],
  },
  {
    id: 'note-interview-2',
    title: 'Interview note — research partner B',
    type: 'note',
    project: northstar,
    updatedAt: '2026-10-17',
    status: 'updating',
    excerpt: 'Partner B said they would lose interest if sign-ups stayed closed for more than two weeks.',
    sourceIdentifier: 'demo-src-0155',
    original: [
      'Interview note — research partner B (synthetic)',
      '',
      'Would lose interest if sign-ups stayed closed for more than two weeks.',
      'Liked the idea of a short guided first session.',
    ].join('\n'),
    versions: [{ version: 1, savedAt: '2026-10-17', note: 'First saved' }],
    understanding: [
      {
        id: 'b1',
        kind: 'source-backed',
        text: 'Partner B may lose interest if sign-ups stay closed beyond two weeks.',
        citation: {
          sourceId: 'note-interview-2',
          version: 1,
          quote: 'Would lose interest if sign-ups stayed closed for more than two weeks.',
        },
      },
      { id: 'b2', kind: 'updating', text: 'Putting this note next to the launch decision.' },
    ],
    usedIn: [{ id: 'prep-compare', title: 'Compare the saved launch decision with two interview notes', kind: 'prepared' }],
  },
  {
    id: 'goal-beta',
    title: 'Prepare the private beta launch',
    type: 'goal',
    project: northstar,
    updatedAt: '2026-10-08',
    status: 'current',
    excerpt: 'Get ten research partners using Northstar with a guided first session before sign-ups open.',
    sourceIdentifier: 'demo-src-0120',
    original:
      'Goal: Prepare the private beta launch\n\nGet ten research partners using Northstar with a guided first session before sign-ups open.',
    versions: [{ version: 1, savedAt: '2026-10-08', note: 'First saved' }],
    understanding: [
      {
        id: 'g1',
        kind: 'source-backed',
        text: 'The beta goal is ten partners with a guided first session.',
        citation: {
          sourceId: 'goal-beta',
          version: 1,
          quote: 'Get ten research partners using Northstar with a guided first session before sign-ups open.',
        },
      },
    ],
    usedIn: [],
  },
  {
    id: 'question-promise',
    title: 'Which onboarding promise is clearest?',
    type: 'question',
    project: northstar,
    updatedAt: '2026-10-11',
    status: 'stale',
    excerpt: 'Two candidate promises. Neither has been tested with partners yet.',
    sourceIdentifier: 'demo-src-0131',
    original:
      'Open question: Which onboarding promise is clearest?\n\nA) "Never explain your project twice."\nB) "Your work, ready for any tool."\n\nNeither has been tested with partners yet.',
    versions: [
      { version: 1, savedAt: '2026-10-10', note: 'First saved' },
      { version: 2, savedAt: '2026-10-11', note: 'You replaced option B' },
    ],
    understanding: [
      {
        id: 'q1',
        kind: 'stale',
        text: 'Option B is "Your notes, everywhere."',
        note: 'The source changed after this was written.',
        citation: { sourceId: 'question-promise', version: 1, quote: 'B) "Your notes, everywhere."' },
      },
    ],
    usedIn: [{ id: 'prep-promises', title: 'Draft three onboarding promises to test', kind: 'prepared' }],
  },
  {
    id: 'inbox-checklist',
    title: 'Rough idea: a welcome checklist',
    type: 'note',
    project: null,
    updatedAt: '2026-10-18',
    status: 'current',
    excerpt: 'A five-step welcome checklist for the first partner session. Not sorted into a project yet.',
    sourceIdentifier: 'demo-src-0160',
    original:
      'Rough idea: a welcome checklist\n\nA five-step welcome checklist for the first partner session. Not sorted into a project yet.',
    versions: [{ version: 1, savedAt: '2026-10-18', note: 'First saved' }],
    understanding: [],
    usedIn: [],
  },
  {
    id: 'inbox-old-plan',
    title: 'Earlier launch plan (withdrawn)',
    type: 'note',
    project: null,
    updatedAt: '2026-10-02',
    status: 'withdrawn',
    excerpt: 'Open sign-ups on day one. Replaced by the research-partner decision.',
    sourceIdentifier: 'demo-src-0098',
    original: 'Earlier launch plan\n\nOpen sign-ups on day one.',
    versions: [{ version: 1, savedAt: '2026-10-02', note: 'First saved' }],
    understanding: [],
    usedIn: [],
  },
];

export const demoPrepared: PreparedItem[] = [
  {
    id: 'prep-compare',
    project: northstar,
    goal: 'Prepare the private beta launch',
    title: 'Compare the saved launch decision with two interview notes',
    whyNow: 'Two interview notes saved after the decision mention waiting and timing.',
    status: 'prepared',
    earlierUnderstanding: 'Invite ten research partners first. Open sign-ups after their first week of use.',
    suggestedChange:
      'Keep the ten-partner invite. Add a short waiting list so interested teammates are not lost, and set a two-week limit before sign-ups open.',
    evidence: [
      {
        sourceId: 'decision-invite',
        sourceTitle: 'Invite ten research partners before opening sign-ups',
        version: 2,
        date: '2026-10-14',
        quote: 'We will invite ten research partners first and open sign-ups only after their first week of use.',
        available: true,
      },
      {
        sourceId: 'note-interview-1',
        sourceTitle: 'Interview note — research partner A',
        version: 1,
        date: '2026-10-15',
        quote: 'Asked for a waiting list so their two teammates are not forgotten.',
        available: true,
      },
      {
        sourceId: 'note-interview-2',
        sourceTitle: 'Interview note — research partner B',
        version: 1,
        date: '2026-10-17',
        quote: 'Would lose interest if sign-ups stayed closed for more than two weeks.',
        available: true,
      },
    ],
    unknowns: [
      { kind: 'unknown', text: 'Whether ten partners covers both team sizes mentioned in the interviews.' },
      { kind: 'hypothesis', text: 'A waiting list may reduce drop-off. Two notes are not enough to confirm it.' },
    ],
    artifact: [
      'Launch plan — private beta',
      '',
      '1. Invite ten research partners personally.',
      '2. Open a short waiting list for their teammates.',
      '3. Open sign-ups no later than two weeks after the first invite.',
    ].join('\n'),
  },
  {
    id: 'prep-promises',
    project: northstar,
    goal: 'Prepare the private beta launch',
    title: 'Draft three onboarding promises to test',
    whyNow: 'The open question about the promise changed on Oct 11.',
    status: 'prepared',
    earlierUnderstanding: 'Two candidate promises, neither tested.',
    suggestedChange: 'Test three short promises with the first partners and keep the one they repeat back.',
    evidence: [
      {
        sourceId: 'question-promise',
        sourceTitle: 'Which onboarding promise is clearest?',
        version: 2,
        date: '2026-10-11',
        quote: 'Neither has been tested with partners yet.',
        available: true,
      },
      {
        sourceId: 'note-themes',
        sourceTitle: 'Private beta interview themes',
        version: 1,
        date: '2026-10-16',
        quote: '"I don\'t want to explain my project again every Monday."',
        available: true,
      },
    ],
    unknowns: [{ kind: 'unknown', text: 'Which promise partners will remember a week later.' }],
    artifact: [
      'Promises to test',
      '',
      'A) Never explain your project twice.',
      'B) Your work, ready for any tool.',
      'C) Pick up on Monday exactly where you stopped.',
    ].join('\n'),
  },
  {
    id: 'prep-themes',
    project: northstar,
    goal: 'Prepare the private beta launch',
    title: 'Summarize interview themes for the launch brief',
    whyNow: 'The themes note is newer than the launch brief.',
    status: 'stale',
    earlierUnderstanding: 'The launch brief lists two themes.',
    suggestedChange: 'Add the third theme: people want to see where an answer came from.',
    evidence: [
      {
        sourceId: 'note-themes',
        sourceTitle: 'Private beta interview themes',
        version: 1,
        date: '2026-10-16',
        quote: 'They want to see where an answer came from before they trust it.',
        available: true,
      },
      {
        sourceId: 'brief-removed',
        sourceTitle: 'Launch brief draft',
        version: 1,
        date: '2026-10-05',
        quote: '',
        available: false,
      },
    ],
    unknowns: [],
    artifact: 'Launch brief — themes\n\n1. Guided start\n2. Keep context between tools\n3. Show where answers came from',
  },
];

/** Connections in the demo workspace. Every row is synthetic; no real service was contacted. */
export const demoKnowledgeSources: KnowledgeSourceConnection[] = [
  {
    id: 'ks-folder',
    kind: 'knowledge',
    name: 'Launch notes folder',
    sourceType: 'Folder on this computer',
    scope: 'Northstar/launch',
    lastSuccessfulCheck: '2026-10-18',
    freshness: 'fresh',
    state: 'connected',
    importedCount: 6,
  },
  {
    id: 'ks-docs',
    kind: 'knowledge',
    name: 'Shared documents',
    sourceType: 'Document workspace',
    scope: 'Research folder only',
    lastSuccessfulCheck: '2026-10-10',
    freshness: 'behind',
    state: 'needs-attention',
    importedCount: 3,
  },
  {
    id: 'ks-email',
    kind: 'knowledge',
    name: 'Email',
    sourceType: 'Mailbox',
    scope: 'Not chosen yet',
    lastSuccessfulCheck: null,
    freshness: 'unknown',
    state: 'not-connected',
    importedCount: 0,
  },
];

export const demoAgents: AgentGrant[] = [
  {
    id: 'ag-coding',
    kind: 'agent',
    label: 'Coding agent',
    readableProjects: [northstar],
    canPropose: true,
    expiresAt: '2026-11-18',
    lastVerifiedAccess: '2026-10-18',
    state: 'connected',
  },
  {
    id: 'ag-writing',
    kind: 'agent',
    label: 'Writing assistant',
    readableProjects: [northstar],
    canPropose: false,
    expiresAt: '2026-10-25',
    lastVerifiedAccess: null,
    state: 'checking',
  },
  {
    id: 'ag-old',
    kind: 'agent',
    label: 'Old research helper',
    readableProjects: [],
    canPropose: false,
    expiresAt: null,
    lastVerifiedAccess: '2026-09-30',
    state: 'revoked',
  },
];
