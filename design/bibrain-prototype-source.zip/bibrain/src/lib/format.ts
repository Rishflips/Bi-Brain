/** Deterministic, timezone-safe date formatting for fixture ISO strings. */
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatDate(iso: string | null | undefined, withYear = false): string {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return `${MONTHS[m - 1]} ${d}${withYear ? `, ${y}` : ''}`;
}

export function formatDateTime(iso: string): string {
  const date = formatDate(iso, true);
  const time = iso.slice(11, 16);
  if (!time) return date;
  const [h, min] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${date}, ${h12}:${String(min).padStart(2, '0')} ${ampm}`;
}

export const typeLabel = {
  note: 'Note',
  decision: 'Decision',
  goal: 'Goal',
  question: 'Open question',
  import: 'Imported file',
} as const;
