import { useEffect, useState } from 'react';
import type { Route } from '../domain/types';

export function useMediaQuery(query: string): boolean {
  const get = () => (typeof window !== 'undefined' ? window.matchMedia(query).matches : false);
  const [matches, setMatches] = useState(get);
  useEffect(() => {
    const mql = window.matchMedia(query);
    const on = () => setMatches(mql.matches);
    on();
    mql.addEventListener('change', on);
    return () => mql.removeEventListener('change', on);
  }, [query]);
  return matches;
}

/** Routes: /#today, /#brain, /#brain/source/<id>, /#connections, /#settings, /#components */
export function parseRoute(hash: string): Route {
  const h = hash.replace(/^#\/?/, '');
  const [head, sub, id] = h.split('/');
  switch (head) {
    case 'brain':
      return sub === 'source' && id ? { name: 'brain', sourceId: decodeURIComponent(id) } : { name: 'brain' };
    case 'connections':
      return { name: 'connections' };
    case 'settings':
      return { name: 'settings' };
    case 'components':
      return { name: 'components' };
    default:
      return { name: 'today' };
  }
}

export function routeHash(r: Route): string {
  if (r.name === 'brain' && r.sourceId) return `#brain/source/${encodeURIComponent(r.sourceId)}`;
  return `#${r.name}`;
}

export function useHashRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(() => parseRoute(window.location.hash));
  useEffect(() => {
    const on = () => setRoute(parseRoute(window.location.hash));
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  const navigate = (r: Route) => {
    const next = routeHash(r);
    if (window.location.hash !== next) window.location.hash = next;
    else setRoute(r);
  };
  return [route, navigate];
}
