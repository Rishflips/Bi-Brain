/** SearchField + SourceRow. Keyword matching only — never presented as an answer. */
import { forwardRef, useId } from 'react';
import { Icon } from './Icon';
import { IconButton } from './Button';
import { StatusPill } from './StatusPill';
import type { SearchResult, SourceStatus, SourceSummary } from '../domain/types';
import { formatDate, typeLabel } from '../lib/format';

export type SearchFieldState = 'empty' | 'active' | 'loading' | 'results' | 'no-results' | 'offline';

export interface SearchFieldProps {
  value: string;
  state: SearchFieldState;
  resultCount?: number;
  onChange: (value: string) => void;
  onClear: () => void;
}

export const SearchField = forwardRef<HTMLInputElement, SearchFieldProps>(function SearchField(
  { value, state, resultCount, onChange, onClear },
  ref,
) {
  const id = useId();
  const status =
    state === 'loading'
      ? 'Searching…'
      : state === 'results'
        ? `${resultCount} ${resultCount === 1 ? 'note matches' : 'notes match'} these words`
        : state === 'no-results'
          ? 'No matching notes.'
          : state === 'offline'
            ? 'Offline — searching what’s on this device.'
            : '';
  return (
    <div data-ui="brain-search" data-state={state}>
      <form role="search" onSubmit={(e) => e.preventDefault()} className="bb-search">
        <label htmlFor={id} className="visually-hidden">
          Find in your brain
        </label>
        <span className="bb-search__icon">
          <Icon name="search" size={22} />
        </span>
        <input
          ref={ref}
          id={id}
          type="search"
          className="bb-search__input"
          placeholder="Find in your brain"
          value={value}
          autoComplete="off"
          onChange={(e) => onChange(e.target.value)}
          aria-describedby={`${id}-status`}
        />
        {value ? (
          <span className="bb-search__clear">
            <IconButton icon="x" label="Clear search" onClick={onClear} />
          </span>
        ) : null}
      </form>
      <p id={`${id}-status`} className="bb-search__status t-meta" role="status" aria-live="polite">
        {state === 'offline' ? (
          <span className="bb-row" style={{ gap: 6 }}>
            <Icon name="offline" size={16} /> {status}
          </span>
        ) : (
          status
        )}
      </p>
    </div>
  );
});

const statusPill: Record<SourceStatus, JSX.Element | null> = {
  current: null,
  updating: <StatusPill status="updating" label="Updating" />,
  stale: <StatusPill status="stale" label="Source changed" />,
  withdrawn: <StatusPill status="paused" icon="minus" label="Withdrawn" />,
};

export interface SourceRowProps {
  source: SourceSummary;
  result?: SearchResult;
  selected?: boolean;
  onOpen: (id: string) => void;
}

export function SourceRow({ source, result, selected, onOpen }: SourceRowProps) {
  const snippet = result ? <Highlighted text={result.snippet} ranges={result.highlights} /> : source.excerpt;
  return (
    <button
      type="button"
      className={`bb-sourcerow${source.status === 'withdrawn' ? ' bb-sourcerow--withdrawn' : ''}`}
      aria-current={selected ? 'true' : undefined}
      onClick={() => onOpen(source.id)}
      data-status={source.status}
    >
      <span className="bb-sourcerow__top">
        <span className="bb-sourcerow__title">{source.title}</span>
        {statusPill[source.status]}
      </span>
      <span className="bb-sourcerow__meta">
        <span>{typeLabel[source.type]}</span>
        <span>{source.project?.name ?? 'Inbox'}</span>
        <span>
          Updated <span className="bb-num">{formatDate(source.updatedAt)}</span>
        </span>
      </span>
      <span className="bb-sourcerow__snippet">{snippet}</span>
    </button>
  );
}

function Highlighted({ text, ranges }: { text: string; ranges: [number, number][] }) {
  const out: (string | JSX.Element)[] = [];
  let cursor = 0;
  ranges.forEach(([s, e], i) => {
    if (s < cursor) return;
    out.push(text.slice(cursor, s));
    out.push(<mark key={i}>{text.slice(s, e)}</mark>);
    cursor = e;
  });
  out.push(text.slice(cursor));
  return <>{out}</>;
}
