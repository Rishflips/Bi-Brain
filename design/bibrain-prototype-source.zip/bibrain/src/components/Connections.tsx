/** ConnectionRow + PermissionPreview. "Connected" is shown only when the wired app verified a round trip. */
import { useId } from 'react';
import { Button } from './Button';
import { Icon } from './Icon';
import { StatusPill, type PillStatus } from './StatusPill';
import type { AgentGrant, ConnectionState, KnowledgeSourceConnection, PermissionPreviewVariant, ProjectRef } from '../domain/types';
import { formatDate } from '../lib/format';

export const connectionMeta: Record<ConnectionState, { label: string; pill: PillStatus; icon: string; help: string }> = {
  'not-connected': { label: 'Not connected', pill: 'neutral', icon: 'minus', help: 'Nothing is shared.' },
  'awaiting-authorization': {
    label: 'Awaiting authorization',
    pill: 'attention',
    icon: 'clock',
    help: 'Waiting for you to approve access in the other app.',
  },
  checking: { label: 'Checking', pill: 'updating', icon: 'refresh', help: 'Confirming access works. Not connected yet.' },
  connected: { label: 'Connected', pill: 'ready', icon: 'check-circle', help: 'Access was verified.' },
  'needs-attention': {
    label: 'Needs attention',
    pill: 'attention',
    icon: 'alert',
    help: 'The last check failed. Imported notes are kept.',
  },
  revoked: { label: 'Revoked', pill: 'paused', icon: 'lock', help: 'Access was removed. It can’t read anything now.' },
};

export function ConnectionStatus({ state }: { state: ConnectionState }) {
  const m = connectionMeta[state];
  return <StatusPill status={m.pill} icon={m.icon} label={m.label} />;
}

export interface KnowledgeRowProps {
  conn: KnowledgeSourceConnection;
  onConnect: (id: string) => void;
  onCancel: (id: string) => void;
  onReviewImport: (id: string) => void;
  onDisconnect: (id: string) => void;
}

export function KnowledgeSourceRow({ conn, onConnect, onCancel, onReviewImport, onDisconnect }: KnowledgeRowProps) {
  const m = connectionMeta[conn.state];
  return (
    <li className="bb-connrow" data-ui="connection-row" data-kind="knowledge" data-state={conn.state}>
      <div className="bb-stack" style={{ gap: 4, minWidth: 0 }}>
        <div className="bb-row" style={{ gap: 10 }}>
          <span className="bb-trust__icon" aria-hidden="true">
            <Icon name={conn.sourceType.startsWith('Folder') ? 'folder' : conn.sourceType === 'Mailbox' ? 'inbox' : 'file'} />
          </span>
          <div style={{ minWidth: 0 }}>
            <p className="bb-connrow__name">{conn.name}</p>
            <p className="t-meta">{conn.sourceType}</p>
          </div>
        </div>
      </div>
      <div className="bb-connrow__facts">
        <ConnectionStatus state={conn.state} />
        <span>Scope: {conn.scope}</span>
        <span>
          Last successful check: <span className="bb-num">{conn.lastSuccessfulCheck ? formatDate(conn.lastSuccessfulCheck, true) : 'never'}</span>
        </span>
        <span>
          {conn.freshness === 'fresh' ? 'Up to date' : conn.freshness === 'behind' ? 'Behind — changes may be missing' : 'Freshness unknown'}
          {conn.importedCount ? (
            <>
              {' '}
              · <span className="bb-num">{conn.importedCount}</span> notes imported
            </>
          ) : null}
        </span>
        <span className="visually-hidden">{m.help}</span>
      </div>
      <div className="bb-connrow__actions">
        {conn.state === 'not-connected' || conn.state === 'revoked' ? (
          <Button size="sm" variant="primary" icon="plus" onClick={() => onConnect(conn.id)}>
            Connect
          </Button>
        ) : null}
        {conn.state === 'awaiting-authorization' || conn.state === 'checking' ? (
          <Button size="sm" onClick={() => onCancel(conn.id)}>
            Cancel
          </Button>
        ) : null}
        {conn.importedCount > 0 ? (
          <Button size="sm" icon="eye" onClick={() => onReviewImport(conn.id)}>
            Review import
          </Button>
        ) : null}
        {conn.state === 'connected' || conn.state === 'needs-attention' ? (
          <Button size="sm" variant="destructive" onClick={() => onDisconnect(conn.id)}>
            Disconnect
          </Button>
        ) : null}
      </div>
    </li>
  );
}

export interface AgentRowProps {
  grant: AgentGrant;
  onReviewAccess: (id: string) => void;
  onRevoke: (id: string) => void;
  onCancel: (id: string) => void;
}

export function AgentRow({ grant, onReviewAccess, onRevoke, onCancel }: AgentRowProps) {
  return (
    <li className="bb-connrow" data-ui="connection-row" data-kind="agent" data-state={grant.state}>
      <div className="bb-row" style={{ gap: 10, minWidth: 0 }}>
        <span className="bb-trust__icon" aria-hidden="true">
          <Icon name="agent" />
        </span>
        <div style={{ minWidth: 0 }}>
          <p className="bb-connrow__name">{grant.label}</p>
          <p className="t-meta">Custom label</p>
        </div>
      </div>
      <div className="bb-connrow__facts">
        <ConnectionStatus state={grant.state} />
        <span>
          Can read: {grant.readableProjects.length ? grant.readableProjects.map((p) => p.name).join(', ') : 'nothing'}
        </span>
        <span>{grant.canPropose ? 'Can propose new memories for your review' : 'Cannot propose memories'}</span>
        <span>
          Expires: <span className="bb-num">{grant.expiresAt ? formatDate(grant.expiresAt, true) : '—'}</span> · Last verified:{' '}
          <span className="bb-num">{grant.lastVerifiedAccess ? formatDate(grant.lastVerifiedAccess, true) : 'not yet'}</span>
        </span>
      </div>
      <div className="bb-connrow__actions">
        {grant.state !== 'revoked' ? (
          <Button size="sm" icon="eye" onClick={() => onReviewAccess(grant.id)}>
            Review access
          </Button>
        ) : null}
        {grant.state === 'awaiting-authorization' || grant.state === 'checking' ? (
          <Button size="sm" onClick={() => onCancel(grant.id)}>
            Cancel
          </Button>
        ) : null}
        {grant.state === 'connected' || grant.state === 'needs-attention' ? (
          <Button size="sm" variant="destructive" icon="lock" onClick={() => onRevoke(grant.id)}>
            Revoke
          </Button>
        ) : null}
      </div>
    </li>
  );
}

/* ------------------------------------------------------------------ */

export interface PermissionDraft {
  label: string;
  projectIds: string[];
  canPropose: boolean;
  expiresInDays: 7 | 30 | 90;
}

export interface PermissionPreviewProps {
  variant: PermissionPreviewVariant;
  draft: PermissionDraft;
  projects: ProjectRef[];
  editable: boolean;
  onChange?: (d: PermissionDraft) => void;
}

export function permissionVariant(d: PermissionDraft, revoked = false): PermissionPreviewVariant {
  if (revoked) return 'revoked';
  if (d.expiresInDays === 7) return 'expiring';
  return d.canPropose ? 'propose-enabled' : 'read-only';
}

export function PermissionPreview({ variant, draft, projects, editable, onChange }: PermissionPreviewProps) {
  const id = useId();
  const chosen = projects.filter((p) => draft.projectIds.includes(p.id));
  const set = (patch: Partial<PermissionDraft>) => onChange?.({ ...draft, ...patch });
  return (
    <div className="bb-perm" data-variant={variant}>
      {editable ? (
        <>
          <div className="bb-field-group">
            <label className="bb-label" htmlFor={`${id}-label`}>
              Agent name
            </label>
            <input
              id={`${id}-label`}
              className="bb-input"
              value={draft.label}
              placeholder="e.g. My coding agent"
              onChange={(e) => set({ label: e.target.value })}
            />
          </div>
          <fieldset className="bb-field-group" style={{ border: 0, padding: 0, margin: 0 }}>
            <legend className="bb-label" style={{ marginBottom: 8 }}>
              Projects it can read
            </legend>
            {projects.map((p) => (
              <label key={p.id} className="bb-row" style={{ minHeight: 44 }}>
                <input
                  type="checkbox"
                  style={{ width: 20, height: 20 }}
                  checked={draft.projectIds.includes(p.id)}
                  onChange={(e) =>
                    set({
                      projectIds: e.target.checked
                        ? [...draft.projectIds, p.id]
                        : draft.projectIds.filter((x) => x !== p.id),
                    })
                  }
                />
                {p.name}
              </label>
            ))}
            <p className="bb-help">Inbox is never shared unless you move a note into a project.</p>
          </fieldset>
          <label className="bb-row" style={{ minHeight: 44 }}>
            <input
              type="checkbox"
              style={{ width: 20, height: 20 }}
              checked={draft.canPropose}
              onChange={(e) => set({ canPropose: e.target.checked })}
            />
            Let it propose new memories (you review each one)
          </label>
          <div className="bb-field-group">
            <label className="bb-label" htmlFor={`${id}-exp`}>
              Access ends after
            </label>
            <select
              id={`${id}-exp`}
              className="bb-select"
              value={draft.expiresInDays}
              onChange={(e) => set({ expiresInDays: Number(e.target.value) as 7 | 30 | 90 })}
            >
              <option value={7}>7 days</option>
              <option value={30}>30 days</option>
              <option value={90}>90 days</option>
            </select>
          </div>
        </>
      ) : null}

      <h3 className="t-label">Before you allow it</h3>
      {variant === 'revoked' ? (
        <p className="t-muted">This access was revoked. The agent can’t read or propose anything.</p>
      ) : (
        <div className="bb-perm__grid">
          <div className="bb-perm__box">
            <span className="bb-row" style={{ gap: 6 }}>
              <Icon name="eye" size={18} /> <strong>Can read</strong>
            </span>
            <ul>
              {chosen.length ? chosen.map((p) => <li key={p.id}>Notes in {p.name}</li>) : <li>Nothing yet — choose a project</li>}
            </ul>
          </div>
          <div className="bb-perm__box">
            <span className="bb-row" style={{ gap: 6 }}>
              <Icon name="edit" size={18} /> <strong>Can propose</strong>
            </span>
            <ul>
              {draft.canPropose ? (
                <li>New memories, held for your review</li>
              ) : (
                <li>Nothing — read only</li>
              )}
            </ul>
          </div>
          <div className="bb-perm__box">
            <span className="bb-row" style={{ gap: 6 }}>
              <Icon name="lock" size={18} /> <strong>Stays private</strong>
            </span>
            <ul>
              <li>Inbox and other projects</li>
              <li>Settings and spending</li>
              <li>It can’t delete or send anything</li>
            </ul>
          </div>
        </div>
      )}
      {variant === 'expiring' ? (
        <p className="t-meta">
          <Icon name="clock" size={14} /> Short access: ends in <span className="bb-num">7</span> days.
        </p>
      ) : null}
    </div>
  );
}
