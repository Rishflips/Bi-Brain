/**
 * LivingField — BiBrain's state surface.
 *
 * The orbits, nodes and glows are DECORATIVE (aria-hidden). They never map to
 * memories, agents or relationships. The only meaningful content is the
 * state label/title/sentence, rendered as text by the caller or below.
 * Motion: opacity/transform only, ≥2.4s cycles, and none for quiet,
 * paused, offline, failed, or reduced motion.
 */
import { officialEmblemSrc } from './BrandLockup';
import type { FieldState } from '../domain/types';

export const fieldCopy: Record<FieldState, { label: string; title: string; sentence: string }> = {
  ready: { label: 'Ready', title: 'Your brain is ready', sentence: 'Everything you save stays available to the agents you choose.' },
  organizing: { label: 'Organizing', title: 'Putting this in place', sentence: 'Your note is already saved. BiBrain is linking it to the right project.' },
  current: { label: 'Keeping current', title: 'Checking what changed', sentence: 'Looking at sources that changed since you last visited.' },
  review: { label: 'Review', title: 'Something is ready for you', sentence: 'Prepared work is waiting. Nothing changes until you decide.' },
  quiet: { label: 'Caught up', title: 'Nothing needs your attention', sentence: 'Your saved work is ready when you are.' },
  paused: { label: 'Paused', title: 'Background help is paused', sentence: 'Saving and search still work. Nothing is prepared while paused.' },
  offline: { label: 'Offline', title: 'Your brain is available on this device', sentence: 'Saved notes and search work here. Preparing resumes when you reconnect.' },
  failed: { label: 'Needs a retry', title: 'Your note is safe', sentence: 'Preparation stopped. Nothing you saved was lost.' },
};

// Six to twelve nodes at most; fixed positions on the four orbits.
const nodes: { cx: number; cy: number; r: number; gold?: boolean }[] = [
  { cx: 50, cy: 7, r: 1.6, gold: true },
  { cx: 90, cy: 40, r: 1.2 },
  { cx: 14, cy: 70, r: 1.4 },
  { cx: 78, cy: 86, r: 1.6, gold: true },
  { cx: 22, cy: 22, r: 1.1 },
  { cx: 96, cy: 62, r: 1.2 },
  { cx: 6, cy: 46, r: 1 },
  { cx: 60, cy: 95, r: 1.1 },
];

export interface LivingFieldProps {
  state: FieldState;
  reducedMotion?: boolean;
  /** Show the label/title/sentence below the field. Today renders them itself in the hero. */
  withCaption?: boolean;
  compact?: boolean;
}

export function LivingField({ state, reducedMotion, withCaption, compact }: LivingFieldProps) {
  const copy = fieldCopy[state];
  return (
    <div className="bb-stack" style={{ alignItems: 'center', gap: 12 }}>
      <div
        className={`bb-field${reducedMotion ? ' reduce-motion' : ''}`}
        data-state={state}
        data-ui="living-field"
        style={compact ? { maxWidth: 180 } : undefined}
      >
        <div className="bb-field__layer bb-field__layer--decor" aria-hidden="true">
          <div className="bb-field__glow bb-field__glow--a" />
          <div className="bb-field__glow bb-field__glow--b" />
          <div className="bb-field__glow bb-field__glow--c" />
          <svg className="bb-field__orbits" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
            <ellipse className="bb-field__orbit" cx="50" cy="50" rx="44" ry="43" />
            <ellipse className="bb-field__orbit" cx="50" cy="50" rx="36" ry="30" transform="rotate(-24 50 50)" />
            <ellipse className="bb-field__orbit" cx="50" cy="50" rx="46" ry="22" transform="rotate(32 50 50)" />
            <ellipse className="bb-field__orbit" cx="50" cy="50" rx="28" ry="40" transform="rotate(12 50 50)" />
            {nodes.map((n, i) => (
              <circle
                key={i}
                className={`bb-field__node${n.gold ? ' bb-field__node--gold' : ''}`}
                cx={n.cx}
                cy={n.cy}
                r={n.r}
              />
            ))}
          </svg>
          <div className="bb-field__arc">
            <svg viewBox="0 0 100 100">
              <path
                d="M50 2 A48 48 0 0 1 92 26"
                fill="none"
                stroke="var(--brand-gold)"
                strokeWidth="1.6"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <div className="bb-field__ring" />
        </div>
        <div className="bb-field__center" aria-hidden="true">
          {/* Official emblem on a white plate, cropped nondestructively. */}
          <span className="bb-crop" style={{ width: '72%', aspectRatio: '1.2 / 1' }}>
            <img
              src={officialEmblemSrc}
              alt=""
              draggable={false}
              style={{ width: `${100 / 0.72}%`, left: `${(-0.14 / 0.72) * 100}%`, top: `${(-0.19 / 0.6) * 100}%` }}
            />
          </span>
        </div>
      </div>
      {withCaption ? (
        <div style={{ textAlign: 'center' }}>
          <p className="t-label">{copy.title}</p>
          <p className="t-meta">{copy.label}</p>
        </div>
      ) : null}
    </div>
  );
}

/** Maps Today's brain state + transient save activity onto a field treatment. */
export function fieldStateFor(brain: import('../domain/types').BrainState, organizing: boolean): FieldState {
  if (brain === 'offline') return 'offline';
  if (brain === 'paused') return 'paused';
  if (organizing) return 'organizing';
  switch (brain) {
    case 'new':
      return 'ready';
    case 'quiet':
      return 'quiet';
    case 'active':
      return 'current';
    case 'review':
      return 'review';
    case 'failure':
      return 'failed';
  }
}
