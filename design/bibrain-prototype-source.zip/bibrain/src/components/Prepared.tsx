/** PreparedCard, EvidenceList, RevisionComparison — proposals, never instructions. */
import { useId, useState } from 'react';
import { Button } from './Button';
import { Icon } from './Icon';
import { StatusPill } from './StatusPill';
import { InlineNotice } from './Feedback';
import type { EvidenceExcerpt, EvidenceState, PreparedItem, RevisionState } from '../domain/types';
import { formatDate } from '../lib/format';

export type PreparedView = 'collapsed' | 'expanded' | 'editing';

export interface PreparedCardProps {
  item: PreparedItem;
  initialView?: PreparedView;
  /** The edited artifact text, if the person changed it before keeping. */
  onAccept: (id: string, artifact: string) => void;
  onUndo: (id: string) => void;
  onCompare: (id: string) => void;
  onSnooze: (id: string) => void;
  onDismiss: (id: string) => void;
  onRestore: (id: string) => void;
  onOpenSource: (sourceId: string, version?: number) => void;
  onPrepareAgain: (id: string) => void;
  headingLevel?: 'h2' | 'h3';
}

export function evidenceState(evidence: EvidenceExcerpt[]): EvidenceState {
  if (!evidence.length) return 'unavailable';
  const missing = evidence.filter((e) => !e.available).length;
  if (missing === 0) return 'complete';
  if (missing === evidence.length) return 'unavailable';
  return evidence.some((e) => e.sourceId.includes('removed')) ? 'source-removed' : 'partial';
}

export function PreparedCard({
  item,
  initialView = 'collapsed',
  onAccept,
  onUndo,
  onCompare,
  onSnooze,
  onDismiss,
  onRestore,
  onOpenSource,
  onPrepareAgain,
  headingLevel = 'h3',
}: PreparedCardProps) {
  const [view, setView] = useState<PreparedView>(initialView);
  const [artifact, setArtifact] = useState(item.artifact);
  const base = useId();
  const H = headingLevel;
  const ev = evidenceState(item.evidence);
  const isOpen = view !== 'collapsed' && (item.status === 'prepared' || item.status === 'stale');

  if (item.status === 'accepted' || item.status === 'snoozed' || item.status === 'dismissed') {
    const copy = {
      accepted: { pill: <StatusPill status="success" label="Kept" />, text: 'You kept this plan. A new version was saved.' },
      snoozed: { pill: <StatusPill status="paused" icon="snooze" label="Later" />, text: 'Back tomorrow morning. Nothing was changed.' },
      dismissed: { pill: <StatusPill status="paused" icon="thumbsdown" label="Not useful" />, text: 'Hidden. Nothing was changed.' },
    }[item.status];
    return (
      <article className="bb-prepared" data-ui="prepared-review" data-status={item.status} aria-labelledby={`${base}-t`}>
        <div className="bb-prepared__summary">
          <div className="bb-prepared__context">
            <span>{item.project.name}</span>
            <span aria-hidden="true">·</span>
            <span>{item.goal}</span>
          </div>
          <div className="bb-row" style={{ justifyContent: 'space-between' }}>
            <H id={`${base}-t`} className="t-card">
              {item.title}
            </H>
            {copy.pill}
          </div>
          <p className="t-muted">{copy.text}</p>
          <div className="bb-actions">
            {item.status === 'accepted' ? (
              item.laterWorkExists ? (
                <>
                  <Button size="sm" icon="layers" onClick={() => onCompare(item.id)}>
                    Compare versions
                  </Button>
                  <span className="t-meta" style={{ alignSelf: 'center' }}>
                    Newer work depends on this, so direct undo is off.
                  </span>
                </>
              ) : (
                <Button size="sm" icon="undo" onClick={() => onUndo(item.id)}>
                  Undo
                </Button>
              )
            ) : (
              <Button size="sm" icon="undo" onClick={() => onRestore(item.id)}>
                Undo
              </Button>
            )}
          </div>
        </div>
      </article>
    );
  }

  return (
    <article
      className={`bb-prepared bb-prepared--${item.status}${isOpen ? ' bb-prepared--expanded' : ''}`}
      data-ui="prepared-review"
      data-status={item.status}
      data-view={view}
      aria-labelledby={`${base}-t`}
    >
      <div className="bb-prepared__summary">
        <div className="bb-prepared__context">
          {item.status === 'stale' ? <StatusPill status="stale" label="Source changed" /> : <StatusPill status="prepared" />}
          <span>{item.project.name}</span>
          <span aria-hidden="true">·</span>
          <span>Goal: {item.goal}</span>
        </div>
        <H id={`${base}-t`} className="t-card">
          {item.title}
        </H>
        <p className="t-muted">{item.whyNow}</p>
        <p className="t-meta">
          <Icon name="file" size={14} /> Based on <span className="bb-num">{item.evidence.length}</span>{' '}
          {item.evidence.length === 1 ? 'source' : 'sources'}
          {ev !== 'complete' ? ' · one is no longer available' : ''}
        </p>
        {!isOpen ? (
          <div className="bb-actions">
            <Button
              variant="primary"
              size="sm"
              icon="eye"
              aria-expanded={false}
              aria-controls={`${base}-review`}
              onClick={() => setView('expanded')}
            >
              Review
            </Button>
            <Button size="sm" icon="snooze" onClick={() => onSnooze(item.id)}>
              Later
            </Button>
            <Button size="sm" variant="ghost" icon="thumbsdown" onClick={() => onDismiss(item.id)}>
              Not useful
            </Button>
          </div>
        ) : null}
      </div>

      {isOpen ? (
        <div className="bb-prepared__review" id={`${base}-review`}>
          {item.status === 'stale' ? (
            <InlineNotice
              tone="attention"
              title="A source changed after this was prepared."
              actions={
                <Button size="sm" icon="refresh" onClick={() => onPrepareAgain(item.id)}>
                  Prepare again
                </Button>
              }
            >
              Review the evidence below. Keeping is off until it is prepared again.
            </InlineNotice>
          ) : null}

          <Step n={1} title="Earlier understanding">
            <p className="t-muted">{item.earlierUnderstanding}</p>
          </Step>
          <Step n={2} title="Suggested change">
            <div className="bb-compare">
              <div className="bb-compare__col">
                <p className="t-meta" style={{ marginBottom: 6 }}>
                  Before
                </p>
                {item.earlierUnderstanding}
              </div>
              <div className="bb-compare__col bb-compare__col--new">
                <p className="t-meta" style={{ marginBottom: 6, color: 'var(--gold-text)' }}>
                  Suggested (not applied)
                </p>
                {item.suggestedChange}
              </div>
            </div>
          </Step>
          <Step n={3} title="Evidence">
            <EvidenceList evidence={item.evidence} onOpenSource={onOpenSource} />
          </Step>
          {item.unknowns.length ? (
            <Step n={4} title="Unknowns and hypotheses">
              <ul className="bb-unknowns">
                {item.unknowns.map((u, i) => (
                  <li key={i}>
                    <StatusPill
                      status={u.kind === 'hypothesis' ? 'attention' : 'neutral'}
                      icon={u.kind === 'hypothesis' ? 'hypothesis' : 'info'}
                      label={u.kind === 'hypothesis' ? 'Hypothesis' : 'Unknown'}
                    />
                    <span>{u.text}</span>
                  </li>
                ))}
              </ul>
            </Step>
          ) : null}
          <Step n={item.unknowns.length ? 5 : 4} title="Prepared plan">
            <div className="bb-artifact">
              {view === 'editing' ? (
                <>
                  <label htmlFor={`${base}-art`} className="visually-hidden">
                    Edit the prepared plan
                  </label>
                  <textarea
                    id={`${base}-art`}
                    className="bb-textarea"
                    value={artifact}
                    onChange={(e) => setArtifact(e.target.value)}
                    autoFocus
                  />
                </>
              ) : (
                <div className="bb-artifact__view">{artifact}</div>
              )}
            </div>
            <p className="t-meta">Prepared, not applied. Nothing changes until you keep it.</p>
          </Step>

          <div className="bb-actions">
            <Button
              variant="primary"
              icon="check"
              disabled={item.status === 'stale'}
              aria-describedby={item.status === 'stale' ? `${base}-stale` : undefined}
              onClick={() => onAccept(item.id, artifact)}
            >
              Keep this plan
            </Button>
            {view === 'editing' ? (
              <Button
                icon="x"
                onClick={() => {
                  setArtifact(item.artifact);
                  setView('expanded');
                }}
              >
                Discard edits
              </Button>
            ) : (
              <Button icon="edit" onClick={() => setView('editing')}>
                Edit
              </Button>
            )}
            <Button icon="snooze" onClick={() => onSnooze(item.id)}>
              Later
            </Button>
            <Button variant="ghost" icon="thumbsdown" onClick={() => onDismiss(item.id)}>
              Not useful
            </Button>
            <Button variant="ghost" icon="chevron-up" onClick={() => setView('collapsed')} aria-expanded={true}>
              Close review
            </Button>
          </div>
          {item.status === 'stale' ? (
            <p id={`${base}-stale`} className="bb-help">
              Keeping is off because a source changed. Prepare again first.
            </p>
          ) : null}
        </div>
      ) : null}
    </article>
  );
}

function Step({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="bb-step">
      <span className="bb-step__n bb-num" aria-hidden="true">
        {n}
      </span>
      <div className="bb-step__body">
        <h4 className="t-label">{title}</h4>
        {children}
      </div>
    </section>
  );
}

export function EvidenceList({
  evidence,
  onOpenSource,
}: {
  evidence: EvidenceExcerpt[];
  onOpenSource: (sourceId: string, version?: number) => void;
}) {
  const state = evidenceState(evidence);
  return (
    <div className="bb-stack" style={{ gap: 10 }} data-evidence={state}>
      {state === 'partial' || state === 'source-removed' ? (
        <p className="t-meta">
          <Icon name="alert" size={14} /> Some evidence is no longer available.
        </p>
      ) : null}
      {state === 'unavailable' ? (
        <InlineNotice tone="attention" title="Evidence is unavailable.">
          The sources behind this were removed or cannot be opened. Don’t rely on it until it is prepared again.
        </InlineNotice>
      ) : null}
      <ul className="bb-evidence">
        {evidence.map((e, i) => (
          <li key={i} data-available={e.available}>
            <div className="bb-evidence__head">
              <span style={{ fontWeight: 600, color: 'var(--text)' }}>{e.sourceTitle}</span>
              <span className="bb-num">
                v{e.version} · {formatDate(e.date, true)}
              </span>
            </div>
            {e.available ? (
              <>
                <blockquote className="bb-quote">“{e.quote}”</blockquote>
                <div>
                  <button type="button" className="bb-linkbtn" onClick={() => onOpenSource(e.sourceId, e.version)}>
                    See source <Icon name="arrow-right" size={16} />
                  </button>
                </div>
              </>
            ) : (
              <p className="t-meta">
                <Icon name="minus" size={14} /> Source removed. The excerpt is no longer available.
              </p>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export interface RevisionComparisonProps {
  state: RevisionState;
  before: string;
  kept: string;
  newer?: string;
  onRestoreEarlier: () => void;
  onKeepCurrent: () => void;
}

export function RevisionComparison({ state, before, kept, newer, onRestoreEarlier, onKeepCurrent }: RevisionComparisonProps) {
  return (
    <div className="bb-stack" data-revision={state}>
      {state === 'clean' ? (
        <p className="t-muted">Nothing changed after you kept this plan. Undo saves the earlier version as a new version.</p>
      ) : state === 'newer-edit' ? (
        <InlineNotice tone="info" title="Newer work exists.">
          Something was edited after you kept this plan. Restoring the earlier version saves it as a new version — nothing
          is erased.
        </InlineNotice>
      ) : (
        <InlineNotice tone="attention" title="Two edits changed the same plan.">
          Choose which one to keep. The other stays in History.
        </InlineNotice>
      )}
      <div className="bb-compare" style={{ gridTemplateColumns: newer ? 'repeat(auto-fit, minmax(200px, 1fr))' : undefined }}>
        <div className="bb-compare__col">
          <p className="t-meta" style={{ marginBottom: 6 }}>
            Before you kept it
          </p>
          {before}
        </div>
        <div className="bb-compare__col bb-compare__col--new">
          <p className="t-meta" style={{ marginBottom: 6 }}>
            Kept plan
          </p>
          {kept}
        </div>
        {newer ? (
          <div className="bb-compare__col">
            <p className="t-meta" style={{ marginBottom: 6 }}>
              Newer edit
            </p>
            {newer}
          </div>
        ) : null}
      </div>
      <div className="bb-actions">
        <Button variant="primary" onClick={onKeepCurrent}>
          {state === 'conflict' ? 'Keep newer edit' : 'Keep current version'}
        </Button>
        <Button icon="undo" onClick={onRestoreEarlier}>
          Restore earlier version
        </Button>
      </div>
    </div>
  );
}
