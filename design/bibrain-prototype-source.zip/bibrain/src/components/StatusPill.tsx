import { Icon } from './Icon';

export type PillStatus =
  | 'ready'
  | 'updating'
  | 'prepared'
  | 'stale'
  | 'paused'
  | 'offline'
  | 'failed'
  | 'success'
  | 'attention'
  | 'neutral'
  | 'demo';

const defaults: Record<PillStatus, { icon: string; label: string }> = {
  ready: { icon: 'check-circle', label: 'Ready' },
  updating: { icon: 'refresh', label: 'Updating' },
  prepared: { icon: 'layers', label: 'Prepared' },
  stale: { icon: 'clock', label: 'Source changed' },
  paused: { icon: 'pause', label: 'Paused' },
  offline: { icon: 'offline', label: 'Offline' },
  failed: { icon: 'alert-circle', label: 'Could not prepare' },
  success: { icon: 'check-circle', label: 'Saved' },
  attention: { icon: 'alert', label: 'Needs review' },
  neutral: { icon: 'info', label: '' },
  demo: { icon: 'info', label: 'Demo data' },
};

/** Status always carries an icon AND text — never color alone. */
export function StatusPill({ status, label, icon }: { status: PillStatus; label?: string; icon?: string }) {
  const d = defaults[status];
  return (
    <span className={`bb-pill bb-pill--${status}`}>
      <Icon name={icon ?? d.icon} size={14} />
      {label ?? d.label}
    </span>
  );
}
