/** AppShell — desktop rail (≥1024), tablet header (800–1023), phone compact top region (<800). All in document flow. */
import type { ReactNode } from 'react';
import { BrandLockup } from './BrandLockup';
import { Button, IconButton } from './Button';
import { Icon } from './Icon';
import type { BackgroundHelpState, Route } from '../domain/types';

export type NavId = 'today' | 'brain' | 'connections';

export interface NavItem {
  id: NavId;
  label: string;
  href: string;
  icon: string;
  attention?: number;
  disabled?: boolean;
}

export function PrimaryNavigation({ items, current, compact }: { items: NavItem[]; current: NavId | null; compact?: boolean }) {
  return (
    <nav aria-label="Primary" data-ui="primary-navigation">
      <ul className="bb-nav">
        {items.map((it) => (
          <li key={it.id}>
            <a
              className="bb-nav__link"
              href={it.href}
              aria-current={current === it.id ? 'page' : undefined}
              aria-disabled={it.disabled || undefined}
            >
              <Icon name={it.icon} size={compact ? 20 : 20} />
              <span>{it.label}</span>
              {it.attention ? (
                <span className="bb-nav__badge bb-num" aria-label={`${it.attention} ready for review`}>
                  {it.attention}
                </span>
              ) : null}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}

const helpCopy: Record<BackgroundHelpState, { title: string; body: string }> = {
  on: { title: 'Background help is on', body: 'Remembering and preparing for your goals.' },
  paused: { title: 'Background help is paused', body: 'Saving and search still work.' },
  'quiet-hours': { title: 'Quiet hours', body: 'Nothing new until morning.' },
  offline: { title: 'Offline', body: 'Working from this device.' },
};

export function BackgroundHelpStatus({ state }: { state: BackgroundHelpState }) {
  const c = helpCopy[state];
  return (
    <div className={`bb-helpstatus bb-helpstatus--${state}`} data-ui="background-help">
      <span className="bb-helpstatus__dot" aria-hidden="true" />
      <div>
        <p style={{ fontWeight: 600 }}>{c.title}</p>
        <p className="t-muted">{c.body}</p>
      </div>
    </div>
  );
}

export interface AppShellProps {
  route: Route;
  nav: NavItem[];
  backgroundHelp: BackgroundHelpState;
  onSaveSomething: () => void;
  onOpenPrototypeControls: () => void;
  children: ReactNode;
}

export function AppShell({ route, nav, backgroundHelp, onSaveSomething, onOpenPrototypeControls, children }: AppShellProps) {
  const current: NavId | null =
    route.name === 'today' || route.name === 'brain' || route.name === 'connections' ? route.name : null;
  return (
    <>
      <a className="bb-skip" href="#main">
        Skip to content
      </a>
      <div className="bb-shell">
        {/* Desktop rail */}
        <aside className="bb-rail" aria-label="BiBrain">
          <a className="bb-rail__brand" href="#today">
            <BrandLockup variant="emblem" width={40} alt="" />
            <span className="bb-rail__name">BiBrain</span>
          </a>
          <PrimaryNavigation items={nav} current={current} />
          <Button variant="gold" icon="plus" block onClick={onSaveSomething} data-ui="save-something">
            Save something
          </Button>
          <div className="bb-rail__spacer" />
          <div className="bb-rail__footer">
            <BackgroundHelpStatus state={backgroundHelp} />
            <a
              className="bb-nav__link"
              href="#settings"
              aria-current={route.name === 'settings' ? 'page' : undefined}
            >
              <Icon name="settings" />
              <span>Settings &amp; privacy</span>
            </a>
            <button type="button" className="bb-nav__link" style={{ border: 0, background: 'none', cursor: 'pointer', width: '100%' }} onClick={onOpenPrototypeControls}>
              <Icon name="sliders" />
              <span>Prototype controls</span>
            </button>
          </div>
        </aside>

        {/* Tablet + phone top region (in flow, never overlays content) */}
        <header className="bb-topbar">
          <a className="bb-topbar__brand" href="#today">
            <BrandLockup variant="compact" width={28} alt="" />
            <span className="bb-rail__name">BiBrain</span>
          </a>
          <PrimaryNavigation items={nav} current={current} compact />
          <div className="bb-topbar__actions">
            <Button variant="gold" icon="plus" onClick={onSaveSomething} aria-label="Save something" data-ui="save-something">
              <span className="bb-topbar__savelabel">Save something</span>
            </Button>
            <a href="#settings" className="bb-iconbtn" aria-label="Settings & privacy" aria-current={route.name === 'settings' ? 'page' : undefined}>
              <Icon name="settings" />
            </a>
            <IconButton icon="sliders" label="Prototype controls" onClick={onOpenPrototypeControls} />
          </div>
        </header>

        <main id="main" className="bb-main" tabIndex={-1}>
          <div className="bb-container">{children}</div>
        </main>
      </div>
    </>
  );
}
