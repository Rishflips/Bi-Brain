import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Icon } from './Icon';

export type ButtonVariant = 'primary' | 'gold' | 'secondary' | 'ghost' | 'destructive' | 'destructive-solid';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: 'md' | 'sm';
  icon?: string;
  iconAfter?: string;
  loading?: boolean;
  /** Text read to assistive tech + shown while loading, e.g. "Saving…" */
  loadingLabel?: string;
  block?: boolean;
  children?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({
  variant = 'secondary',
  size = 'md',
  icon,
  iconAfter,
  loading,
  loadingLabel,
  block,
  className,
  children,
  disabled,
  type = 'button',
  ...rest
}, ref) {
  const cls = [
    'bb-btn',
    variant !== 'secondary' && `bb-btn--${variant}`,
    size === 'sm' && 'bb-btn--sm',
    block && 'bb-btn--block',
    className,
  ]
    .filter(Boolean)
    .join(' ');
  return (
    <button ref={ref} type={type} className={cls} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <span className="bb-spinner" aria-hidden="true" /> : icon ? <Icon name={icon} size={18} /> : null}
      <span>{loading && loadingLabel ? loadingLabel : children}</span>
      {iconAfter && !loading ? <Icon name={iconAfter} size={18} /> : null}
    </button>
  );
});

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon: string;
  label: string;
  selected?: boolean;
  destructive?: boolean;
}

export function IconButton({ icon, label, selected, destructive, className, type = 'button', ...rest }: IconButtonProps) {
  return (
    <button
      type={type}
      className={['bb-iconbtn', destructive && 'bb-iconbtn--destructive', className].filter(Boolean).join(' ')}
      aria-label={label}
      title={label}
      aria-pressed={selected === undefined ? undefined : selected}
      {...rest}
    >
      <Icon name={icon} size={20} />
    </button>
  );
}
