/** SourceViewer — Original (default), Understanding, History, Used in. */
import { useId, useRef, useState, type KeyboardEvent } from 'react';
import { Button, IconButton } from './Button';
import { Icon } from './Icon';
import { StatusPill } from './StatusPill';
import { InlineNotice } from './Feedback';
import type { SourceDetail, UnderstandingKind, UnderstandingStatement } from '../domain/types';
import { formatDate, typeLabel } from '../lib/format';

export type SourceTab = 'original' | 'understanding' | 'history' | 'used-in';

const TABS: { id: SourceTab; label: string }[] = [
  { id: 'original', label: 'Original' },
  { id: 'understanding', label: 'Understanding' },
  { id: 'history', label: 'History' },
  { id: 'used-in', label: 'Used in' },
];

export interface SourceViewerProps {
  source: SourceDetail;
  tab: SourceTab;
  onTabChange: (tab: SourceTab) => void;
  onClose: () => void;
  closeLabel: string;
  onSeeSource: (sourceId: string, version: number) => void;
  onEditUnderstanding: (statementId: string, text: string) => void;
  onCorrectSource: () => void;
  onWithdraw: () => void;
  onRestore: () => void;
  onDelete: () => void;
  onCopyBrief: () => void;
  onDownloadMarkdown: () => void;
  onOpenPrepared: (id: string) => void;
  /** Version requested through a citation (highlights it in History). */
  focusVersion?: number;
  /** Show the Demo data label on synthetic content. */
  isDemo?: boolean;
}

export function SourceViewer(props: SourceViewerProps) {
  const { source, tab, onTabChange } = props;
  const base = useId();
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const idx = TABS.findIndex((t) => t.id === tab);
    let next = idx;
    if (e.key === 'ArrowRight') next = (idx + 1) % TABS.length;
    else if (e.key === 'ArrowLeft') next = (idx - 1 + TABS.length) % TABS.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = TABS.length - 1;
    else return;
    e.preventDefault();
    onTabChange(TABS[next].id);
    tabRefs.current[next]?.focus();
  };
  const latest = source.versions[source.versions.length - 1];

  return (
    <article className="bb-viewer" aria-labelledby={`${base}-title`} data-ui="source-viewer">
      <div className="bb-viewer__head">
        <div className="bb-row" style={{ justifyContent: 'space-between', flexWrap: 'nowrap', alignItems: 'flex-start' }}>
          <Button variant="ghost" size="sm" icon="arrow-left" onClick={props.onClose}>
            {props.closeLabel}
          </Button>
          {props.isDemo ? <StatusPill status="demo" /> : null}
        </div>
        <h2 id={`${base}-title`} className="t-section" tabIndex={-1}>
          {source.title}
        </h2>
        <div className="bb-sourcerow__meta" style={{ marginTop: 0 }}>
          <span>{typeLabel[source.type]}</span>
          <span>{source.project?.name ?? 'Inbox'}</span>
          <span>
            Version <span className="bb-num">{latest.version}</span> · <span className="bb-num">{formatDate(latest.savedAt, true)}</span>
          </span>
          {source.status !== 'current' ? (
            <StatusPill
              status={source.status === 'updating' ? 'updating' : source.status === 'stale' ? 'stale' : 'paused'}
              icon={source.status === 'withdrawn' ? 'minus' : undefined}
              label={source.status === 'updating' ? 'Updating' : source.status === 'stale' ? 'Source changed' : 'Withdrawn'}
            />
          ) : null}
        </div>
      </div>

      <div className="bb-tabs" role="tablist" aria-label="Source sections" onKeyDown={onKey}>
        {TABS.map((t, i) => (
          <button
            key={t.id}
            ref={(el) => (tabRefs.current[i] = el)}
            role="tab"
            id={`${base}-tab-${t.id}`}
            aria-controls={`${base}-panel-${t.id}`}
            aria-selected={tab === t.id}
            tabIndex={tab === t.id ? 0 : -1}
            className="bb-tab"
            onClick={() => onTabChange(t.id)}
          >
            {t.label}
            {t.id === 'understanding' ? <span className="t-meta bb-num"> {source.understanding.length}</span> : null}
          </button>
        ))}
      </div>

      <div
        className="bb-tabpanel"
        role="tabpanel"
        id={`${base}-panel-${tab}`}
        aria-labelledby={`${base}-tab-${tab}`}
        tabIndex={0}
      >
        {tab === 'original' ? <OriginalPanel {...props} /> : null}
        {tab === 'understanding' ? <UnderstandingPanel {...props} /> : null}
        {tab === 'history' ? <HistoryPanel {...props} /> : null}
        {tab === 'used-in' ? <UsedInPanel {...props} /> : null}
      </div>
    </article>
  );
}

function OriginalPanel({ source, onCorrectSource, onWithdraw, onRestore, onDelete, onCopyBrief, onDownloadMarkdown }: SourceViewerProps) {
  return (
    <div className="bb-stack" style={{ gap: 20 }}>
      {source.status === 'withdrawn' ? (
        <InlineNotice tone="info" title="Withdrawn from active use." actions={<Button size="sm" onClick={onRestore}>Return to active use</Button>}>
          Agents do not receive this note. The original is kept so you can still read it.
        </InlineNotice>
      ) : null}
      <div className="bb-original" tabIndex={0} aria-label="Original text">
        {source.original}
      </div>
      <p className="t-meta">
        Source ID <span className="bb-num">{source.sourceIdentifier}</span> · This is the exact text BiBrain keeps.
      </p>
      <div className="bb-moremenu">
        <Button size="sm" icon="copy" onClick={onCopyBrief}>
          Copy brief
        </Button>
        <Button size="sm" icon="download" onClick={onDownloadMarkdown}>
          Download Markdown
        </Button>
        <Button size="sm" icon="edit" onClick={onCorrectSource}>
          Correct source
        </Button>
        {source.status !== 'withdrawn' ? (
          <Button size="sm" icon="minus" onClick={onWithdraw}>
            Withdraw from active use
          </Button>
        ) : null}
        <Button size="sm" variant="destructive" icon="trash" onClick={onDelete}>
          Delete permanently
        </Button>
      </div>
    </div>
  );
}

const kindMeta: Record<UnderstandingKind, { label: string; icon: string; pill: Parameters<typeof StatusPill>[0]['status'] }> = {
  'source-backed': { label: 'From the source', icon: 'file', pill: 'ready' },
  'user-correction': { label: 'Your correction', icon: 'user', pill: 'neutral' },
  hypothesis: { label: 'Hypothesis', icon: 'hypothesis', pill: 'attention' },
  updating: { label: 'Updating', icon: 'refresh', pill: 'updating' },
  stale: { label: 'Source changed', icon: 'clock', pill: 'stale' },
  withdrawn: { label: 'Withdrawn', icon: 'minus', pill: 'paused' },
};

function UnderstandingPanel({ source, onSeeSource, onEditUnderstanding }: SourceViewerProps) {
  if (!source.understanding.length) {
    return (
      <p className="t-muted">
        BiBrain hasn’t written anything about this note yet. The original is saved and searchable.
      </p>
    );
  }
  return (
    <div className="bb-stack">
      <h3 className="t-card">What BiBrain remembers</h3>
      <p className="t-meta">Each line shows where it came from. Hypotheses and changed sources are marked.</p>
      <ul className="bb-list bb-understanding">
        {source.understanding.map((s) => (
          <Statement key={s.id} s={s} onSeeSource={onSeeSource} onEdit={onEditUnderstanding} />
        ))}
      </ul>
    </div>
  );
}

function Statement({
  s,
  onSeeSource,
  onEdit,
}: {
  s: UnderstandingStatement;
  onSeeSource: SourceViewerProps['onSeeSource'];
  onEdit: SourceViewerProps['onEditUnderstanding'];
}) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(s.text);
  const id = useId();
  const meta = kindMeta[s.kind];
  const editable = s.kind !== 'withdrawn' && s.kind !== 'updating';
  return (
    <li className={`bb-statement bb-statement--${s.kind}`} data-kind={s.kind}>
      <div className="bb-row" style={{ justifyContent: 'space-between' }}>
        <StatusPill status={meta.pill} icon={meta.icon} label={meta.label} />
        {editable && !editing ? (
          <IconButton icon="edit" label={`Edit understanding: ${s.text}`} onClick={() => setEditing(true)} />
        ) : null}
      </div>
      {editing ? (
        <form
          className="bb-stack"
          style={{ gap: 8 }}
          onSubmit={(e) => {
            e.preventDefault();
            onEdit(s.id, text);
            setEditing(false);
          }}
        >
          <label htmlFor={id} className="bb-label">
            Edit understanding
          </label>
          <textarea id={id} className="bb-textarea" style={{ minHeight: 80 }} value={text} onChange={(e) => setText(e.target.value)} autoFocus />
          <p className="bb-help">Your edit is saved as a correction. The original source stays unchanged.</p>
          <div className="bb-actions">
            <Button type="submit" variant="primary" size="sm">
              Save correction
            </Button>
            <Button
              size="sm"
              onClick={() => {
                setText(s.text);
                setEditing(false);
              }}
            >
              Cancel
            </Button>
          </div>
        </form>
      ) : (
        <p className="bb-statement__text">{s.text}</p>
      )}
      {s.note ? <p className="t-meta">{s.note}</p> : null}
      {s.citation ? (
        <div className="bb-stack" style={{ gap: 6 }}>
          <blockquote className="bb-quote">“{s.citation.quote}”</blockquote>
          <div>
            <button type="button" className="bb-linkbtn" onClick={() => onSeeSource(s.citation!.sourceId, s.citation!.version)}>
              See source <span className="t-meta bb-num">(version {s.citation.version})</span>
              <Icon name="arrow-right" size={16} />
            </button>
          </div>
        </div>
      ) : s.kind === 'source-backed' ? (
        <p className="t-meta">Source unavailable.</p>
      ) : null}
    </li>
  );
}

function HistoryPanel({ source, focusVersion }: SourceViewerProps) {
  const versions = [...source.versions].reverse();
  return (
    <div className="bb-stack">
      <h3 className="t-card">History</h3>
      <ol className="bb-timeline">
        {versions.map((v) => (
          <li key={v.version} aria-current={focusVersion === v.version ? 'true' : undefined}>
            <span className="bb-timeline__dot" aria-hidden="true" />
            <div>
              <p className="t-label">
                Version <span className="bb-num">{v.version}</span>
                {focusVersion === v.version ? <span className="t-meta"> · cited version</span> : null}
              </p>
              <p className="t-meta">
                <span className="bb-num">{formatDate(v.savedAt, true)}</span> · {v.note}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function UsedInPanel({ source, onOpenPrepared }: SourceViewerProps) {
  if (!source.usedIn.length) {
    return <p className="t-muted">Nothing depends on this note yet.</p>;
  }
  return (
    <div className="bb-stack">
      <h3 className="t-card">Used in</h3>
      <p className="t-meta">If you change or withdraw this note, these may need another look.</p>
      <ul className="bb-list bb-stack" style={{ gap: 8 }}>
        {source.usedIn.map((u) => (
          <li key={u.id} className="bb-statement">
            <span className="t-meta">{u.kind === 'prepared' ? 'Prepared work' : 'Brief'}</span>
            <button type="button" className="bb-linkbtn" onClick={() => onOpenPrepared(u.id)}>
              {u.title}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
