/** InlineNotice, EmptyState, Skeleton, DemoBanner, Toasts. */
import type { ReactNode } from 'react';
import { Icon } from './Icon';
import { BrandLockup } from './BrandLockup';
import type { NoticeTone, Toast } from '../domain/types';

const toneIcon: Record<NoticeTone, string> = {
  info: 'info',
  attention: 'alert',
  failure: 'alert-circle',
  success: 'check-circle',
  offline: 'offline',
};

export function InlineNotice({
  tone,
  title,
  children,
  actions,
  icon,
  live,
}: {
  tone: NoticeTone;
  title: ReactNode;
  children?: ReactNode;
  actions?: ReactNode;
  icon?: string;
  /** Only for meaningful changes (saved, failed, connected, revoked). */
  live?: boolean;
}) {
  return (
    <div className={`bb-notice bb-notice--${tone}`} role={live ? (tone === 'failure' ? 'alert' : 'status') : undefined}>
      <span className="bb-notice__icon">
        <Icon name={icon ?? toneIcon[tone]} size={22} />
      </span>
      <p className="bb-notice__title">{title}</p>
      {children ? <div className="bb-notice__body">{children}</div> : null}
      {actions ? <div className="bb-notice__actions">{actions}</div> : null}
    </div>
  );
}

export type EmptyVariant = 'new-brain' | 'quiet' | 'no-results' | 'no-connections';

export function EmptyState({
  variant,
  title,
  body,
  actions,
}: {
  variant: EmptyVariant;
  title: string;
  body: string;
  actions?: ReactNode;
}) {
  return (
    <div className="bb-empty" data-variant={variant}>
      {variant === 'new-brain' || variant === 'quiet' ? (
        <BrandLockup variant="emblem" width={72} alt="" />
      ) : (
        <span className="bb-trust__icon" aria-hidden="true">
          <Icon name={variant === 'no-results' ? 'search' : 'connections'} />
        </span>
      )}
      <h3 className="t-card">{title}</h3>
      <p className="t-muted measure">{body}</p>
      {actions ? <div className="bb-actions">{actions}</div> : null}
    </div>
  );
}

export type SkeletonVariant = 'text' | 'row' | 'card' | 'hero';

export function Skeleton({ variant, label = 'Loading' }: { variant: SkeletonVariant; label?: string }) {
  const content =
    variant === 'text' ? (
      <div className="bb-stack" style={{ gap: 8 }}>
        <div className="bb-skel" style={{ height: 14, width: '90%' }} />
        <div className="bb-skel" style={{ height: 14, width: '70%' }} />
      </div>
    ) : variant === 'row' ? (
      <div className="bb-stack" style={{ gap: 8, padding: '16px 20px' }}>
        <div className="bb-skel" style={{ height: 18, width: '55%' }} />
        <div className="bb-skel" style={{ height: 12, width: '35%' }} />
        <div className="bb-skel" style={{ height: 14, width: '85%' }} />
      </div>
    ) : variant === 'card' ? (
      <div className="bb-card bb-stack">
        <div className="bb-skel" style={{ height: 12, width: '30%' }} />
        <div className="bb-skel" style={{ height: 20, width: '75%' }} />
        <div className="bb-skel" style={{ height: 14, width: '60%' }} />
      </div>
    ) : (
      <div className="bb-skel" style={{ height: 320, borderRadius: 28 }} />
    );
  return (
    <div role="status" aria-label={label}>
      {content}
      <span className="visually-hidden">{label}</span>
    </div>
  );
}

export function DemoBanner({ mode, onLeave }: { mode: 'demo' | 'preview'; onLeave: () => void }) {
  return (
    <div className="bb-banner" role="note">
      <Icon name="info" size={18} />
      {mode === 'demo' ? (
        <span>
          <strong>Demo data.</strong> “Northstar launch” is a synthetic example. Nothing here is real or saved to a
          brain.
        </span>
      ) : (
        <span>
          <strong>Preview.</strong> Not connected to a real brain. What you save stays in this tab only.
        </span>
      )}
      <span className="bb-modebar__spacer" />
      <button type="button" className="bb-linkbtn" onClick={onLeave}>
        {mode === 'demo' ? 'Leave example' : 'Close preview'}
      </button>
    </div>
  );
}

export function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="bb-toasts" aria-live="polite" aria-atomic="false">
      {toasts.map((t) => (
        <div key={t.id} className="bb-toast">
          <Icon name={toneIcon[t.tone]} size={18} />
          <span style={{ flex: 1 }}>{t.text}</span>
          {t.action ? (
            <button
              type="button"
              className="bb-btn"
              onClick={() => {
                t.action?.onAction();
                onDismiss(t.id);
              }}
            >
              {t.action.label}
            </button>
          ) : null}
          <button
            type="button"
            className="bb-iconbtn"
            style={{ color: 'inherit', width: 36, height: 36 }}
            aria-label="Dismiss"
            onClick={() => onDismiss(t.id)}
          >
            <Icon name="x" size={18} />
          </button>
        </div>
      ))}
    </div>
  );
}
