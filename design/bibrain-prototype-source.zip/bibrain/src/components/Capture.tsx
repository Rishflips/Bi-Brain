/** SaveComposer + SavedReceipt. Presentational: all mutations arrive as callbacks. */
import { useId, useRef } from 'react';
import { Button } from './Button';
import { Icon } from './Icon';
import { InlineNotice } from './Feedback';
import { StatusPill } from './StatusPill';
import type {
  CaptureDraft,
  CaptureState,
  PreparationState,
  ProjectRef,
  SavedReceiptVM,
  SourceSummary,
} from '../domain/types';
import { formatDate, formatDateTime } from '../lib/format';

export interface SaveComposerProps {
  draft: CaptureDraft;
  state: CaptureState;
  projects: ProjectRef[];
  limitChars: number;
  /** When set, the composer is disabled and this explains why. */
  disabledReason?: string;
  onChange: (draft: CaptureDraft) => void;
  onImportFile: (file: File) => void;
  onSave: (opts?: { allowDuplicate?: boolean }) => void;
  onCancel: () => void;
  onOpenExisting?: (id: string) => void;
  autoFocus?: boolean;
}

export function SaveComposer({
  draft,
  state,
  projects,
  limitChars,
  disabledReason,
  onChange,
  onImportFile,
  onSave,
  onCancel,
  onOpenExisting,
  autoFocus,
}: SaveComposerProps) {
  const id = useId();
  const fileRef = useRef<HTMLInputElement>(null);
  const saving = state.kind === 'saving';
  const disabled = Boolean(disabledReason) || saving;
  const chars = draft.content.length;
  const tooLarge = chars > limitChars;
  const isEmpty = !draft.title.trim() && !draft.content.trim();
  const canSave = !disabled && !isEmpty && !tooLarge;
  const hintId = `${id}-hint`;

  return (
    <form
      className="bb-composer"
      data-ui="save-composer"
      data-state={state.kind}
      onSubmit={(e) => {
        e.preventDefault();
        if (canSave) onSave();
      }}
      aria-busy={saving || undefined}
    >
      {disabledReason ? (
        <InlineNotice tone="info" title="Saving is unavailable right now">
          {disabledReason}
        </InlineNotice>
      ) : null}

      <div className="bb-field-group">
        <label className="bb-label" htmlFor={`${id}-title`}>
          Title
        </label>
        <input
          id={`${id}-title`}
          className="bb-input bb-textarea--title"
          value={draft.title}
          placeholder="Give it a name you’ll recognize"
          disabled={disabled}
          autoFocus={autoFocus}
          onChange={(e) => onChange({ ...draft, title: e.target.value })}
        />
      </div>

      <div className="bb-field-group">
        <label className="bb-label" htmlFor={`${id}-content`}>
          What do you want to remember?
        </label>
        <textarea
          id={`${id}-content`}
          className="bb-textarea"
          value={draft.content}
          placeholder="Paste a note, a decision, meeting notes, or anything you want your agents to know."
          disabled={disabled}
          aria-invalid={tooLarge || undefined}
          aria-describedby={hintId}
          rows={7}
          onChange={(e) => onChange({ ...draft, content: e.target.value })}
        />
        <div className="bb-composer__meta">
          <p id={hintId} className="bb-help">
            Plain text or Markdown, up to <span className="bb-num">{limitChars.toLocaleString('en-US')}</span>{' '}
            characters. You can also import a .txt or .md file.
          </p>
          <span className={`bb-help bb-num`} style={tooLarge ? { color: 'var(--failure)', fontWeight: 600 } : undefined}>
            {chars.toLocaleString('en-US')} / {limitChars.toLocaleString('en-US')}
          </span>
        </div>
      </div>

      <div className="bb-row" style={{ alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div className="bb-field-group" style={{ minWidth: 200, flex: '1 1 220px' }}>
          <label className="bb-label" htmlFor={`${id}-dest`}>
            Save to
          </label>
          <select
            id={`${id}-dest`}
            className="bb-select"
            value={draft.destination?.id ?? 'inbox'}
            disabled={disabled}
            onChange={(e) => {
              const p = projects.find((x) => x.id === e.target.value) ?? null;
              onChange({ ...draft, destination: p });
            }}
          >
            <option value="inbox">Inbox</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
        <span className="bb-btn bb-filebtn" aria-disabled={disabled || undefined}>
          <Icon name="upload" size={18} />
          <span>{draft.importedFileName ? `Imported ${draft.importedFileName}` : 'Import .txt or .md'}</span>
          <input
            ref={fileRef}
            type="file"
            accept=".txt,.md,text/plain,text/markdown"
            disabled={disabled}
            aria-label="Import a .txt or .md file"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onImportFile(f);
              if (fileRef.current) fileRef.current.value = '';
            }}
          />
        </span>
      </div>

      {/* State notices — the full draft is always retained above. */}
      {tooLarge || state.kind === 'too-large' ? (
        <InlineNotice tone="attention" title="This is too long to save as one note.">
          It has <span className="bb-num">{chars.toLocaleString('en-US')}</span> characters. The limit is{' '}
          <span className="bb-num">{limitChars.toLocaleString('en-US')}</span>. Split it into two notes, or shorten
          it.
        </InlineNotice>
      ) : null}
      {state.kind === 'unsupported-file' ? (
        <InlineNotice tone="attention" title={`“${state.fileName}” wasn’t added.`} live>
          BiBrain can import .txt and .md files here. Your draft has not changed.
        </InlineNotice>
      ) : null}
      {state.kind === 'write-failed' ? (
        <InlineNotice
          tone="failure"
          title="Not saved yet."
          live
          actions={
            <Button variant="primary" size="sm" icon="refresh" onClick={() => onSave()}>
              Try again
            </Button>
          }
        >
          {state.message}
        </InlineNotice>
      ) : null}
      {state.kind === 'duplicate' ? (
        <InlineNotice
          tone="info"
          title="This looks like something you already saved."
          live
          actions={
            <>
              {onOpenExisting ? (
                <Button size="sm" icon="eye" onClick={() => onOpenExisting(state.existing.id)}>
                  View existing
                </Button>
              ) : null}
              <Button size="sm" variant="primary" onClick={() => onSave({ allowDuplicate: true })}>
                Save anyway
              </Button>
            </>
          }
        >
          “{state.existing.title}” · {state.existing.project?.name ?? 'Inbox'} · updated{' '}
          <span className="bb-num">{formatDate(state.existing.updatedAt)}</span>
        </InlineNotice>
      ) : null}

      <div className="bb-composer__footer">
        <Button onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button
          type="submit"
          variant="gold"
          icon="plus"
          loading={saving}
          loadingLabel="Saving…"
          disabled={!canSave}
          aria-describedby={isEmpty ? `${id}-empty` : undefined}
          data-ui="save-submit"
        >
          Save to my brain
        </Button>
      </div>
      {isEmpty && !disabled ? (
        <p id={`${id}-empty`} className="bb-help" style={{ textAlign: 'right', marginTop: -8 }}>
          Add a title or some text to save.
        </p>
      ) : null}
      <p className="visually-hidden" role="status" aria-live="polite">
        {saving ? 'Saving…' : ''}
      </p>
    </form>
  );
}

/* ------------------------------------------------------------------ */

export type ReceiptVariant = 'saved' | 'duplicate';

export interface SavedReceiptProps {
  variant: ReceiptVariant;
  receipt?: SavedReceiptVM;
  existing?: SourceSummary;
  preparation: PreparationState;
  onViewOriginal: (sourceId: string) => void;
  onFindInBrain: () => void;
  onSaveAnother: () => void;
  onDismiss: () => void;
  onRetryPreparation?: () => void;
  headingRef?: React.Ref<HTMLHeadingElement>;
}

export function SavedReceipt({
  variant,
  receipt,
  existing,
  preparation,
  onViewOriginal,
  onFindInBrain,
  onSaveAnother,
  onDismiss,
  onRetryPreparation,
  headingRef,
}: SavedReceiptProps) {
  const sourceId = receipt?.sourceId ?? existing?.id ?? '';
  return (
    <section className="bb-receipt" data-ui="saved-receipt" data-variant={variant} aria-labelledby="receipt-title">
      <div className="bb-receipt__head">
        <span className="bb-receipt__check" aria-hidden="true">
          <Icon name={variant === 'saved' ? 'check' : 'layers'} size={20} />
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 id="receipt-title" className="t-card" ref={headingRef} tabIndex={-1}>
            {variant === 'saved' ? 'Saved to your brain' : 'Already in your brain'}
          </h2>
          <p className="t-meta">
            {variant === 'saved' && receipt ? (
              <>
                <span className="bb-num">{formatDateTime(receipt.savedAt)}</span> · {receipt.destination?.name ?? 'Inbox'}
              </>
            ) : existing ? (
              <>Nothing new was saved. This matches an existing note.</>
            ) : null}
          </p>
        </div>
        <StatusPill status="success" label={variant === 'saved' ? 'Saved' : 'Kept existing'} />
      </div>

      <div className="bb-receipt__body">
        {variant === 'saved' && receipt ? (
          <>
            <div>
              <p className="t-label">{receipt.title}</p>
              {receipt.retainedContent ? (
                <div className="bb-receipt__content" tabIndex={0} aria-label="Saved text">
                  {receipt.retainedContent}
                </div>
              ) : (
                <p className="t-meta">No body text — title only.</p>
              )}
            </div>
            <dl className="bb-dl">
              <dt>Saved to</dt>
              <dd>{receipt.destination?.name ?? 'Inbox'}</dd>
              <dt>Source ID</dt>
              <dd className="bb-num">{receipt.sourceIdentifier}</dd>
            </dl>
          </>
        ) : existing ? (
          <div>
            <p className="t-label">{existing.title}</p>
            <p className="t-meta">
              {existing.project?.name ?? 'Inbox'} · updated <span className="bb-num">{formatDate(existing.updatedAt)}</span>
            </p>
          </div>
        ) : null}

        {/* Preparation is visually separate: it can never reverse the saved state above. */}
        {variant === 'saved' ? <PreparationStatus state={preparation} onRetry={onRetryPreparation} /> : null}

        <div className="bb-actions">
          <Button variant="primary" icon="file" onClick={() => onViewOriginal(sourceId)}>
            View original
          </Button>
          <Button icon="search" onClick={onFindInBrain}>
            Find in Your brain
          </Button>
          <Button icon="plus" onClick={onSaveAnother}>
            Save another
          </Button>
          <Button variant="ghost" onClick={onDismiss}>
            Dismiss
          </Button>
        </div>
      </div>
    </section>
  );
}

export function PreparationStatus({ state, onRetry }: { state: PreparationState; onRetry?: () => void }) {
  if (state === 'idle') return null;
  const map = {
    preparing: { icon: 'refresh', text: 'Putting this in place so your agents can use it. You can keep working.' },
    prepared: { icon: 'check-circle', text: 'Ready to use with your agents.' },
    delayed: { icon: 'clock', text: 'Putting this in place is taking longer than usual. Your note is saved and you can search for it now.' },
    failed: { icon: 'alert-circle', text: 'BiBrain could not prepare this note. Your note is still saved.' },
  } as const;
  const m = map[state];
  return (
    <div className="bb-receipt__prep" role="status" aria-live="polite" data-preparation={state}>
      <Icon name={m.icon} size={18} />
      <div className="bb-stack" style={{ gap: 8, flex: 1 }}>
        <span>
          <strong style={{ fontWeight: 620 }}>Preparation: </strong>
          {m.text}
        </span>
        {state === 'failed' && onRetry ? (
          <div>
            <Button size="sm" icon="refresh" onClick={onRetry}>
              Retry preparation
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  );
}
