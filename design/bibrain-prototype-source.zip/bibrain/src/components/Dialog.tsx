/**
 * Dialog — modal on desktop, full-height sheet below 800px.
 * Focus trap, initial focus, Escape to close, and focus return are built in.
 */
import { useEffect, useId, useRef, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { IconButton, Button } from './Button';
import { InlineNotice } from './Feedback';

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

export interface DialogProps {
  title: ReactNode;
  description?: ReactNode;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'side';
  initialFocusRef?: RefObject<HTMLElement>;
  /** Prevent closing (e.g. while a save is in flight). */
  dismissible?: boolean;
  dataUi?: string;
}

export function Dialog({
  title,
  description,
  onClose,
  children,
  footer,
  size = 'md',
  initialFocusRef,
  dismissible = true,
  dataUi,
}: DialogProps) {
  const ref = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const descId = useId();
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const dismissRef = useRef(dismissible);
  dismissRef.current = dismissible;

  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    const node = ref.current;
    const target = initialFocusRef?.current ?? node?.querySelector<HTMLElement>(FOCUSABLE);
    target?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissRef.current) {
        e.stopPropagation();
        closeRef.current();
      }
      if (e.key === 'Tab' && node) {
        const items = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
          (el) => el.offsetParent !== null,
        );
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    node?.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      node?.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
      previouslyFocused?.focus?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return createPortal(
    <div
      className="bb-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && dismissible) onClose();
      }}
    >
      <div
        ref={ref}
        className={`bb-dialog ${size === 'sm' ? 'bb-dialog--sm' : size === 'side' ? 'bb-dialog--side' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descId : undefined}
        data-ui={dataUi}
      >
        <div className="bb-dialog__head">
          <div className="bb-stack" style={{ gap: 6 }}>
            <h2 id={titleId} className="t-section">
              {title}
            </h2>
            {description ? (
              <p id={descId} className="t-muted">
                {description}
              </p>
            ) : null}
          </div>
          <IconButton icon="x" label="Close" onClick={onClose} disabled={!dismissible} />
        </div>
        <div className="bb-dialog__body">{children}</div>
        {footer ? <div className="bb-dialog__foot">{footer}</div> : null}
      </div>
    </div>,
    document.body,
  );
}

export type ConfirmVariant = 'ordinary' | 'destructive' | 'permanent';

export interface ConfirmDialogProps {
  variant: ConfirmVariant;
  title: string;
  /** What happens, in plain words. */
  body: ReactNode;
  /** Required for destructive + permanent: scope, backups, delivered copies, reversibility. */
  consequences?: { label: string; text: string }[];
  confirmLabel: string;
  cancelLabel?: string;
  /** For permanent deletion: the phrase the person types to confirm. */
  confirmPhrase?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDialog({
  variant,
  title,
  body,
  consequences,
  confirmLabel,
  cancelLabel = 'Cancel',
  confirmPhrase,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const cancelRef = useRef<HTMLButtonElement>(null);
  const [typed, setTyped] = useState('');
  const phraseOk = !confirmPhrase || typed.trim().toLowerCase() === confirmPhrase.toLowerCase();
  const inputId = useId();
  return (
    <Dialog
      title={title}
      onClose={onCancel}
      size="sm"
      initialFocusRef={cancelRef as RefObject<HTMLElement>}
      footer={
        <>
          <Button ref={cancelRef} onClick={onCancel}>
            {cancelLabel}
          </Button>
          <Button
            variant={variant === 'ordinary' ? 'primary' : 'destructive-solid'}
            onClick={onConfirm}
            disabled={!phraseOk}
            aria-describedby={!phraseOk ? `${inputId}-hint` : undefined}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="t-muted">{body}</div>
      {consequences?.length ? (
        <dl className="bb-dl">
          {consequences.map((c) => (
            <div key={c.label} style={{ display: 'contents' }}>
              <dt>{c.label}</dt>
              <dd>{c.text}</dd>
            </div>
          ))}
        </dl>
      ) : null}
      {variant === 'permanent' && confirmPhrase ? (
        <>
          <InlineNotice tone="failure" title="This cannot be undone.">
            BiBrain cannot restore it after you confirm.
          </InlineNotice>
          <div className="bb-field-group">
            <label className="bb-label" htmlFor={inputId}>
              Type “{confirmPhrase}” to confirm
            </label>
            <input id={inputId} className="bb-input" value={typed} onChange={(e) => setTyped(e.target.value)} />
            {!phraseOk ? (
              <p id={`${inputId}-hint`} className="bb-help">
                The delete button turns on when the text matches.
              </p>
            ) : null}
          </div>
        </>
      ) : null}
    </Dialog>
  );
}
