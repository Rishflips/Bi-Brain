/**
 * BrandLockup — renders the OFFICIAL supplied PNGs only.
 *
 * The source files are never modified. Cropping of the built-in white canvas
 * happens through a nondestructive overflow wrapper using the crop bounds in
 * design.md. Because the PNGs are opaque, the mark always sits on a white plate.
 */
import lockupSrc from '../assets/brand/bibrain-lockup.png';
import emblemSrc from '../assets/brand/bibrain-emblem.png';

// Crop bounds from the brief (fractions of the source image).
const LOCKUP = { w: 1672, h: 941, x0: 0.07, x1: 0.93, y0: 0.29, y1: 0.69 };
const EMBLEM = { w: 1254, h: 1254, x0: 0.14, x1: 0.86, y0: 0.19, y1: 0.79 };

type Crop = typeof LOCKUP;

function Cropped({ src, crop, width, alt }: { src: string; crop: Crop; width: number; alt: string }) {
  const visW = (crop.x1 - crop.x0) * crop.w;
  const visH = (crop.y1 - crop.y0) * crop.h;
  const height = (width * visH) / visW;
  const imgW = width / (crop.x1 - crop.x0);
  const imgH = (imgW * crop.h) / crop.w;
  return (
    <span className="bb-crop" style={{ width, height }} role="img" aria-label={alt}>
      <img
        src={src}
        alt=""
        draggable={false}
        style={{ width: imgW, height: imgH, left: -crop.x0 * imgW, top: -crop.y0 * imgH }}
      />
    </span>
  );
}

export type BrandLockupVariant = 'horizontal' | 'emblem' | 'compact';

export interface BrandLockupProps {
  variant: BrandLockupVariant;
  /** Visible mark width in px. Minimums: lockup 176 (240 on first use), emblem 40 / compact 28. */
  width?: number;
  /** Adds the white plate + clear area. Always on; kept explicit so the gallery can show it. */
  plate?: boolean;
  /** Accessible name; pass "" when adjacent text already names BiBrain. */
  alt?: string;
}

export function BrandLockup({ variant, width, plate = true, alt = 'BiBrain' }: BrandLockupProps) {
  const isLockup = variant === 'horizontal';
  const w = width ?? (isLockup ? 176 : variant === 'compact' ? 28 : 40);
  const mark = (
    <Cropped src={isLockup ? lockupSrc : emblemSrc} crop={isLockup ? LOCKUP : EMBLEM} width={w} alt={alt} />
  );
  if (!plate) return mark;
  // Clear area ≈ one inner-lobe width of the emblem (~20% of the emblem's visible width).
  const pad = isLockup ? Math.round(w * 0.06) : Math.max(4, Math.round(w * 0.2));
  return (
    <span
      className="bb-logo-plate"
      style={{ padding: pad, borderRadius: isLockup ? 16 : Math.max(8, Math.round(w * 0.3)) }}
      data-variant={variant}
    >
      {mark}
    </span>
  );
}

/** Raw official emblem (full square) for places like the living-field center plate. */
export const officialEmblemSrc = emblemSrc;
export const officialLockupSrc = lockupSrc;
