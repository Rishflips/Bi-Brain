import { Button } from '../components/Button';
import { Icon } from '../components/Icon';
import { EmptyState, InlineNotice } from '../components/Feedback';
import { LivingField, fieldCopy, fieldStateFor } from '../components/LivingField';
import { PreparedCard, type PreparedCardProps } from '../components/Prepared';
import { SourceRow } from '../components/Search';
import { BackgroundHelpStatus } from '../components/AppShell';
import type { BackgroundHelpState, BrainState, PreparedItem, SourceSummary } from '../domain/types';

export interface TodayScreenProps {
  brainState: BrainState;
  organizing: boolean;
  reducedMotion: boolean;
  prepared: PreparedItem[];
  recent: SourceSummary[];
  backgroundHelp: BackgroundHelpState;
  failedSourceId: string | null;
  checkingCount: number;
  onSaveSomething: () => void;
  onFind: () => void;
  onOpenSource: (id: string, version?: number) => void;
  onRetryPreparation: () => void;
  onResumeHelp: () => void;
  onTryExample?: () => void;
  preparedHandlers: Omit<PreparedCardProps, 'item' | 'initialView' | 'onOpenSource' | 'headingLevel'>;
}

export function TodayScreen(p: TodayScreenProps) {
  const field = fieldStateFor(p.brainState, p.organizing);
  const copy = fieldCopy[field];
  const isNew = p.brainState === 'new';
  // Prepared work stays visible in review; resolved items keep their Undo in place.
  const visiblePrepared = p.brainState === 'review' || p.brainState === 'quiet' || p.brainState === 'active'
    ? p.prepared.filter((x) => p.brainState === 'review' || x.status !== 'prepared')
    : [];
  const top = visiblePrepared[0];
  const more = visiblePrepared.slice(1, 3);

  return (
    <div className="bb-stack" style={{ gap: 0 }}>
      <section className="bb-hero" aria-labelledby="today-h">
        <div className="bb-hero__copy">
          <p className="t-eyebrow">Today</p>
          <h1 id="today-h" className="t-page" tabIndex={-1}>
            {isNew ? 'Start with one thing worth keeping.' : 'Pick up where you left off.'}
          </h1>
          <p className="t-body-lg t-muted measure">
            {isNew
              ? 'Save a note, a decision, or a plan. BiBrain keeps it ready for any agent you choose.'
              : 'Your saved work stays ready, even when the agent changes.'}
          </p>
          <div className="bb-hero__state" data-field-state={field}>
            <span className="t-meta" style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
              <Icon name={stateIcon[field]} size={16} />
              {copy.label}
            </span>
            <p className="t-label" style={{ fontSize: 17 }}>
              {copy.title}
            </p>
            <p className="t-muted" style={{ fontSize: 15 }}>
              {copy.sentence}
            </p>
          </div>
          <div className="bb-actions">
            <Button variant="gold" icon="plus" onClick={p.onSaveSomething} data-ui="save-something">
              Save something
            </Button>
            <Button icon="search" onClick={p.onFind}>
              Find in your brain
            </Button>
          </div>
        </div>
        <LivingField state={field} reducedMotion={p.reducedMotion} />
      </section>

      {/* 1. Compact save entry */}
      <div style={{ marginTop: 32 }}>
        <button type="button" className="bb-quicksave" onClick={p.onSaveSomething}>
          <span className="bb-trust__icon" aria-hidden="true">
            <Icon name="plus" />
          </span>
          <span className="bb-quicksave__text">What do you want to remember next?</span>
          <span className="t-meta" aria-hidden="true">
            Save something
          </span>
        </button>
      </div>

      {/* State notices lead with what remains safe */}
      {p.brainState === 'failure' ? (
        <div style={{ marginTop: 24 }}>
          <InlineNotice
            tone="attention"
            icon="shield"
            title="Your note is saved."
            live
            actions={
              <>
                <Button variant="primary" size="sm" icon="refresh" onClick={p.onRetryPreparation}>
                  Retry preparation
                </Button>
                {p.failedSourceId ? (
                  <Button size="sm" icon="file" onClick={() => p.onOpenSource(p.failedSourceId!)}>
                    View original
                  </Button>
                ) : null}
              </>
            }
          >
            BiBrain could not prepare the brief. You can retry or open the original.
          </InlineNotice>
        </div>
      ) : null}
      {p.brainState === 'paused' ? (
        <div style={{ marginTop: 24 }}>
          <InlineNotice
            tone="info"
            icon="pause"
            title="Background help is paused."
            actions={
              <Button size="sm" icon="play" onClick={p.onResumeHelp}>
                Resume background help
              </Button>
            }
          >
            Saving and search still work. Nothing new is prepared until you resume.
          </InlineNotice>
        </div>
      ) : null}
      {p.brainState === 'offline' ? (
        <div style={{ marginTop: 24 }}>
          <InlineNotice tone="offline" title="You’re offline." live>
            Your brain is available on this device. Saving and search work here. Preparing and connections resume when
            you’re back online.
          </InlineNotice>
        </div>
      ) : null}
      {p.brainState === 'active' ? (
        <div style={{ marginTop: 24 }}>
          <InlineNotice tone="info" icon="refresh" title="Checking what changed.">
            Looking at <span className="bb-num">{p.checkingCount}</span> sources that changed since your last visit.
            You don’t need to wait.
          </InlineNotice>
        </div>
      ) : null}

      {/* 2. Highest-value prepared item */}
      {top ? (
        <section className="bb-section" aria-labelledby="prep-h" style={{ marginTop: 40 }}>
          <div className="bb-section__head">
            <h2 id="prep-h" className="t-section">
              Ready for you
            </h2>
            <span className="t-meta">Prepared, not applied — you decide.</span>
          </div>
          <div id={`prepared-${top.id}`}>
            <PreparedCard key={top.id} item={top} onOpenSource={p.onOpenSource} {...p.preparedHandlers} />
          </div>
        </section>
      ) : null}

      {/* Quiet + new */}
      {p.brainState === 'quiet' && !p.prepared.some((x) => x.status === 'prepared') ? (
        <div style={{ marginTop: 40 }}>
          <EmptyState
            variant="quiet"
            title="Nothing needs your attention."
            body="Your saved work is ready when you are."
            actions={
              <>
                <Button variant="gold" icon="plus" onClick={p.onSaveSomething}>
                  Save something
                </Button>
                <Button icon="search" onClick={p.onFind}>
                  Find in your brain
                </Button>
              </>
            }
          />
        </div>
      ) : null}
      {isNew ? (
        <div style={{ marginTop: 40 }}>
          <EmptyState
            variant="new-brain"
            title="Save your first note."
            body="Start with something you’d otherwise explain again to an agent: a decision, a plan, or notes from a call."
            actions={
              <>
                <Button variant="gold" icon="plus" onClick={p.onSaveSomething}>
                  Save something
                </Button>
                {p.onTryExample ? (
                  <Button icon="eye" onClick={p.onTryExample}>
                    Try an example instead
                  </Button>
                ) : null}
              </>
            }
          />
        </div>
      ) : null}

      {/* 3. Pick up where you left off */}
      {p.recent.length ? (
        <section className="bb-section" aria-labelledby="pickup-h">
          <div className="bb-section__head">
            <h2 id="pickup-h" className="t-section">
              Pick up where you left off
            </h2>
            <Button variant="ghost" size="sm" iconAfter="arrow-right" onClick={p.onFind}>
              Your brain
            </Button>
          </div>
          <ul className="bb-list bb-sourcelist">
            {p.recent.slice(0, 3).map((src) => (
              <li key={src.id}>
                <SourceRow source={src} onOpen={(id) => p.onOpenSource(id)} />
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {/* 4. More prepared work (max two) */}
      {more.length ? (
        <section className="bb-section" aria-labelledby="more-h">
          <div className="bb-section__head">
            <h2 id="more-h" className="t-section">
              More prepared work
            </h2>
          </div>
          <div className="bb-stack">
            {more.map((it) => (
              <div key={it.id} id={`prepared-${it.id}`}>
                <PreparedCard item={it} onOpenSource={p.onOpenSource} {...p.preparedHandlers} />
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {/* 5. Background-help status */}
      <section className="bb-section" aria-label="Background help">
        <BackgroundHelpStatus state={p.backgroundHelp} />
      </section>
    </div>
  );
}

const stateIcon: Record<string, string> = {
  ready: 'check-circle',
  organizing: 'refresh',
  current: 'refresh',
  review: 'layers',
  quiet: 'check-circle',
  paused: 'pause',
  offline: 'offline',
  failed: 'shield',
};
