/** Component variants and state examples (brief deliverable 3 + token sheet). All content is demo data. */
import type { ReactNode } from 'react';
import { BrandLockup } from '../components/BrandLockup';
import { Button, IconButton } from '../components/Button';
import { StatusPill } from '../components/StatusPill';
import { LivingField } from '../components/LivingField';
import { SaveComposer, SavedReceipt } from '../components/Capture';
import { SearchField, SourceRow } from '../components/Search';
import { EvidenceList, PreparedCard, RevisionComparison } from '../components/Prepared';
import { AgentRow, KnowledgeSourceRow, PermissionPreview } from '../components/Connections';
import { EmptyState, InlineNotice, Skeleton } from '../components/Feedback';
import { PrimaryNavigation } from '../components/AppShell';
import { demoAgents, demoKnowledgeSources, demoPrepared, demoSources, northstar } from '../fixtures/demoWorkspace';
import type { ConnectionState, FieldState } from '../domain/types';

const noop = () => {};
const draft = { title: 'Private beta interview themes', content: 'People want a guided start…', destination: northstar };
const receipt = {
  sourceId: 'demo-src-0151',
  title: 'Private beta interview themes',
  retainedContent: 'People want a guided start, not a blank page.',
  sourceIdentifier: 'demo-src-0151',
  destination: northstar,
  savedAt: '2026-10-19T09:30:00',
};
const preparedHandlers = {
  onAccept: noop,
  onUndo: noop,
  onCompare: noop,
  onSnooze: noop,
  onDismiss: noop,
  onRestore: noop,
  onOpenSource: noop,
  onPrepareAgain: noop,
};

export function ComponentGallery({ reducedMotion }: { reducedMotion: boolean }) {
  const fields: FieldState[] = ['ready', 'organizing', 'current', 'review', 'quiet', 'paused', 'offline', 'failed'];
  const states: ConnectionState[] = ['not-connected', 'awaiting-authorization', 'checking', 'connected', 'needs-attention', 'revoked'];
  return (
    <div className="bb-stack" style={{ gap: 48 }}>
      <header className="bb-stack" style={{ gap: 8 }}>
        <div className="bb-row" style={{ justifyContent: 'space-between' }}>
          <h1 className="t-page" tabIndex={-1}>
            Component states
          </h1>
          <StatusPill status="demo" />
        </div>
        <p className="t-muted measure">Reviewer reference: every component variant with demo data. Not part of the product navigation.</p>
      </header>

      <Block title="Tokens — color">
        <div className="bb-gallery-grid">
          {[
            ['canvas', '--canvas'],
            ['canvasWarm', '--canvas-warm'],
            ['surface', '--surface'],
            ['surfaceMuted', '--surface-muted'],
            ['text', '--text'],
            ['textMuted', '--text-muted'],
            ['border', '--border'],
            ['primary', '--primary'],
            ['signal', '--signal'],
            ['signalSoft', '--signal-soft'],
            ['focus', '--focus'],
            ['success', '--success'],
            ['info', '--info'],
            ['attention', '--attention'],
            ['failure', '--failure'],
            ['offline', '--offline'],
          ].map(([n, v]) => (
            <div key={n} className="bb-swatch">
              <div className="bb-swatch__chip" style={{ background: `var(${v})`, borderBottom: '1px solid var(--border)' }} />
              <div className="bb-swatch__label">
                <span>{n}</span>
                <code className="t-meta">{v}</code>
              </div>
            </div>
          ))}
        </div>
      </Block>

      <Block title="Tokens — type">
        <div className="bb-stack">
          <p className="t-display">Display 64/42</p>
          <p className="t-page">Page title 44/34</p>
          <p className="t-section">Section title 28/24</p>
          <p className="t-card">Card title 20/19</p>
          <p className="t-body-lg">Body large 18/17</p>
          <p>Body 16</p>
          <p className="t-label">Label 14</p>
          <p className="t-meta">Metadata 13</p>
        </div>
      </Block>

      <Block title="BrandLockup">
        <div className="bb-row" style={{ gap: 24, alignItems: 'center' }}>
          <Spec label="horizontal · 240">
            <BrandLockup variant="horizontal" width={240} />
          </Spec>
          <Spec label="horizontal · 176">
            <BrandLockup variant="horizontal" width={176} />
          </Spec>
          <Spec label="emblem · 72">
            <BrandLockup variant="emblem" width={72} />
          </Spec>
          <Spec label="emblem · 40">
            <BrandLockup variant="emblem" width={40} />
          </Spec>
          <Spec label="compact · 28">
            <BrandLockup variant="compact" width={28} />
          </Spec>
        </div>
      </Block>

      <Block title="Button / IconButton">
        <div className="bb-actions">
          <Button variant="primary">Primary</Button>
          <Button variant="gold" icon="plus">
            Gold emphasis
          </Button>
          <Button>Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="destructive" icon="trash">
            Destructive
          </Button>
          <Button variant="primary" loading loadingLabel="Saving…">
            Save
          </Button>
          <Button disabled>Disabled</Button>
          <IconButton icon="edit" label="Edit (default)" />
          <IconButton icon="layers" label="Selected" selected />
          <IconButton icon="trash" label="Delete" destructive />
          <IconButton icon="copy" label="Disabled" disabled />
        </div>
      </Block>

      <Block title="StatusPill">
        <div className="bb-actions">
          <StatusPill status="ready" />
          <StatusPill status="updating" />
          <StatusPill status="prepared" />
          <StatusPill status="stale" />
          <StatusPill status="paused" />
          <StatusPill status="offline" />
          <StatusPill status="failed" />
          <StatusPill status="demo" />
        </div>
      </Block>

      <Block title="PrimaryNavigation">
        <div style={{ maxWidth: 240 }}>
          <PrimaryNavigation
            current="today"
            items={[
              { id: 'today', label: 'Today', href: '#components', icon: 'today' },
              { id: 'brain', label: 'Your brain', href: '#components', icon: 'brain', attention: 2 },
              { id: 'connections', label: 'Connections', href: '#components', icon: 'connections', disabled: true },
            ]}
          />
          <p className="t-meta" style={{ marginTop: 8 }}>Selected · attention · disabled</p>
        </div>
      </Block>

      <Block title="LivingField">
        <div className="bb-gallery-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(min(200px, 100%), 1fr))' }}>
          {fields.map((f) => (
            <div key={f} className="bb-specimen">
              <span className="bb-specimen__label">{f}</span>
              <LivingField state={f} reducedMotion={reducedMotion} withCaption compact />
            </div>
          ))}
        </div>
      </Block>

      <Block title="SaveComposer">
        <div className="bb-gallery-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(min(320px, 100%), 1fr))' }}>
          <Spec label="empty">
            <SaveComposer draft={{ title: '', content: '', destination: null }} state={{ kind: 'empty' }} projects={[northstar]} limitChars={20000} onChange={noop} onImportFile={noop} onSave={noop} onCancel={noop} />
          </Spec>
          <Spec label="saving">
            <SaveComposer draft={draft} state={{ kind: 'saving' }} projects={[northstar]} limitChars={20000} onChange={noop} onImportFile={noop} onSave={noop} onCancel={noop} />
          </Spec>
          <Spec label="error · write failed">
            <SaveComposer draft={draft} state={{ kind: 'write-failed', message: 'BiBrain could not write this note. Your draft is still here.' }} projects={[northstar]} limitChars={20000} onChange={noop} onImportFile={noop} onSave={noop} onCancel={noop} />
          </Spec>
          <Spec label="disabled">
            <SaveComposer draft={draft} state={{ kind: 'drafting' }} disabledReason="BiBrain is finishing an update on this computer. Try again in a moment." projects={[northstar]} limitChars={20000} onChange={noop} onImportFile={noop} onSave={noop} onCancel={noop} />
          </Spec>
        </div>
      </Block>

      <Block title="SavedReceipt">
        <div className="bb-gallery-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(min(340px, 100%), 1fr))' }}>
          <SavedReceipt variant="saved" receipt={receipt} preparation="prepared" onViewOriginal={noop} onFindInBrain={noop} onSaveAnother={noop} onDismiss={noop} />
          <SavedReceipt variant="saved" receipt={receipt} preparation="preparing" onViewOriginal={noop} onFindInBrain={noop} onSaveAnother={noop} onDismiss={noop} />
          <SavedReceipt variant="saved" receipt={receipt} preparation="failed" onViewOriginal={noop} onFindInBrain={noop} onSaveAnother={noop} onDismiss={noop} onRetryPreparation={noop} />
          <SavedReceipt variant="duplicate" existing={demoSources[1]} preparation="idle" onViewOriginal={noop} onFindInBrain={noop} onSaveAnother={noop} onDismiss={noop} />
        </div>
      </Block>

      <Block title="SearchField">
        <div className="bb-stack">
          <SearchField value="" state="empty" onChange={noop} onClear={noop} />
          <SearchField value="launch" state="loading" onChange={noop} onClear={noop} />
          <SearchField value="launch" state="results" resultCount={3} onChange={noop} onClear={noop} />
          <SearchField value="pricing" state="no-results" onChange={noop} onClear={noop} />
          <SearchField value="partner" state="offline" onChange={noop} onClear={noop} />
        </div>
      </Block>

      <Block title="SourceRow">
        <ul className="bb-list bb-sourcelist">
          <li><SourceRow source={demoSources[0]} onOpen={noop} /></li>
          <li><SourceRow source={demoSources[3]} onOpen={noop} /></li>
          <li><SourceRow source={demoSources[5]} onOpen={noop} /></li>
          <li><SourceRow source={demoSources[7]} onOpen={noop} /></li>
          <li><SourceRow source={demoSources[1]} selected onOpen={noop} /></li>
        </ul>
      </Block>

      <Block title="PreparedCard">
        <div className="bb-stack">
          <PreparedCard item={demoPrepared[1]} {...preparedHandlers} />
          <PreparedCard item={demoPrepared[0]} initialView="expanded" {...preparedHandlers} />
          <PreparedCard item={demoPrepared[1]} initialView="editing" {...preparedHandlers} />
          <PreparedCard item={{ ...demoPrepared[0], status: 'accepted' }} {...preparedHandlers} />
          <PreparedCard item={{ ...demoPrepared[0], status: 'accepted', laterWorkExists: true }} {...preparedHandlers} />
          <PreparedCard item={{ ...demoPrepared[1], status: 'snoozed' }} {...preparedHandlers} />
          <PreparedCard item={demoPrepared[2]} initialView="expanded" {...preparedHandlers} />
        </div>
      </Block>

      <Block title="EvidenceList">
        <div className="bb-gallery-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(min(320px, 100%), 1fr))' }}>
          <Spec label="complete"><EvidenceList evidence={demoPrepared[0].evidence.slice(0, 2)} onOpenSource={noop} /></Spec>
          <Spec label="partial"><EvidenceList evidence={[demoPrepared[0].evidence[0], { ...demoPrepared[0].evidence[1], available: false }]} onOpenSource={noop} /></Spec>
          <Spec label="source removed"><EvidenceList evidence={demoPrepared[2].evidence} onOpenSource={noop} /></Spec>
          <Spec label="unavailable"><EvidenceList evidence={[{ ...demoPrepared[2].evidence[1] }]} onOpenSource={noop} /></Spec>
        </div>
      </Block>

      <Block title="RevisionComparison">
        <div className="bb-stack">
          <Spec label="clean"><RevisionComparison state="clean" before={demoPrepared[0].earlierUnderstanding} kept={demoPrepared[0].artifact} onKeepCurrent={noop} onRestoreEarlier={noop} /></Spec>
          <Spec label="newer edit present"><RevisionComparison state="newer-edit" before={demoPrepared[0].earlierUnderstanding} kept={demoPrepared[0].artifact} newer={'Launch plan — private beta\n\n1. Invite twelve research partners.'} onKeepCurrent={noop} onRestoreEarlier={noop} /></Spec>
          <Spec label="conflict"><RevisionComparison state="conflict" before={demoPrepared[0].earlierUnderstanding} kept={demoPrepared[0].artifact} newer={'Open sign-ups after one week.'} onKeepCurrent={noop} onRestoreEarlier={noop} /></Spec>
        </div>
      </Block>

      <Block title="ConnectionRow — all six states">
        <ul className="bb-list bb-connlist">
          {states.map((st) => (
            <KnowledgeSourceRow key={st} conn={{ ...demoKnowledgeSources[0], id: st, state: st }} onConnect={noop} onCancel={noop} onReviewImport={noop} onDisconnect={noop} />
          ))}
          <AgentRow grant={demoAgents[0]} onReviewAccess={noop} onRevoke={noop} onCancel={noop} />
        </ul>
      </Block>

      <Block title="PermissionPreview">
        <div className="bb-stack">
          {(['read-only', 'propose-enabled', 'expiring', 'revoked'] as const).map((v) => (
            <Spec key={v} label={v}>
              <PermissionPreview
                variant={v}
                editable={false}
                projects={[northstar]}
                draft={{ label: 'Coding agent', projectIds: ['northstar'], canPropose: v === 'propose-enabled', expiresInDays: v === 'expiring' ? 7 : 30 }}
              />
            </Spec>
          ))}
        </div>
      </Block>

      <Block title="EmptyState">
        <div className="bb-gallery-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(min(300px, 100%), 1fr))' }}>
          <EmptyState variant="new-brain" title="Save your first note." body="Start with something you’d otherwise explain again." />
          <EmptyState variant="quiet" title="Nothing needs your attention." body="Your saved work is ready when you are." />
          <EmptyState variant="no-results" title="No matching notes." body="Try a different word or save something new." />
          <EmptyState variant="no-connections" title="No agents can read your brain yet." body="You’ll see exactly what each can read first." />
        </div>
      </Block>

      <Block title="InlineNotice">
        <div className="bb-stack">
          <InlineNotice tone="info" title="Information">Checking what changed.</InlineNotice>
          <InlineNotice tone="attention" title="Attention">A source changed after this was prepared.</InlineNotice>
          <InlineNotice tone="failure" title="Failure">Not saved yet. Your draft is still here.</InlineNotice>
          <InlineNotice tone="success" title="Success">Saved to your brain.</InlineNotice>
        </div>
      </Block>

      <Block title="Skeleton">
        <div className="bb-gallery-grid">
          <Spec label="text"><Skeleton variant="text" /></Spec>
          <Spec label="row"><Skeleton variant="row" /></Spec>
          <Spec label="card"><Skeleton variant="card" /></Spec>
          <Spec label="hero"><Skeleton variant="hero" /></Spec>
        </div>
      </Block>
      <p className="t-meta">ConfirmDialog (ordinary, destructive, permanent deletion) opens from Your brain → a note → Withdraw / Delete permanently, and from Settings → Delete everything.</p>
    </div>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="bb-stack" aria-label={title}>
      <h2 className="t-section">{title}</h2>
      {children}
    </section>
  );
}

function Spec({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="bb-specimen">
      <span className="bb-specimen__label">{label}</span>
      {children}
    </div>
  );
}
