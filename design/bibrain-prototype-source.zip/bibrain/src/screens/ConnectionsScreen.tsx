import { useState } from 'react';
import { Button } from '../components/Button';
import { ConfirmDialog, Dialog } from '../components/Dialog';
import { EmptyState, InlineNotice } from '../components/Feedback';
import { AgentRow, KnowledgeSourceRow, PermissionPreview, permissionVariant, type PermissionDraft } from '../components/Connections';
import { StatusPill } from '../components/StatusPill';
import type { AgentGrant, KnowledgeSourceConnection, ProjectRef, SourceDetail } from '../domain/types';
import { formatDate } from '../lib/format';

export interface ConnectionsScreenProps {
  isDemo: boolean;
  offline: boolean;
  knowledge: KnowledgeSourceConnection[];
  agents: AgentGrant[];
  projects: ProjectRef[];
  sources: SourceDetail[];
  onConnect: (id: string) => void;
  onCancelKnowledge: (id: string) => void;
  onDisconnect: (id: string, removeImported: boolean) => void;
  onCreateGrant: (label: string, projectIds: string[], canPropose: boolean, days: number) => void;
  onUpdateGrant: (id: string, patch: Partial<AgentGrant>) => void;
  onRevoke: (id: string) => void;
  onCancelAgent: (id: string) => void;
}

type Modal =
  | { kind: 'add-agent' }
  | { kind: 'review-access'; id: string }
  | { kind: 'revoke'; id: string }
  | { kind: 'disconnect'; id: string }
  | { kind: 'review-import'; id: string };

export function ConnectionsScreen(p: ConnectionsScreenProps) {
  const [modal, setModal] = useState<Modal | null>(null);
  const awaiting = p.knowledge.some((k) => k.state === 'awaiting-authorization') || p.agents.some((a) => a.state === 'awaiting-authorization');

  return (
    <div className="bb-stack" style={{ gap: 32 }}>
      <header className="bb-stack" style={{ gap: 8 }}>
        <div className="bb-row" style={{ justifyContent: 'space-between' }}>
          <h1 className="t-page" tabIndex={-1}>
            Connections
          </h1>
          {p.isDemo ? <StatusPill status="demo" /> : null}
        </div>
        <p className="t-muted measure t-body-lg">
          Choose what BiBrain can learn from, and which agents can use your brain. Nothing is shared until you allow it.
        </p>
      </header>

      {p.isDemo ? (
        <InlineNotice tone="info" title="These connections are demo data.">
          They show how each state looks. No real app or agent was contacted.
        </InlineNotice>
      ) : null}
      {p.offline ? (
        <InlineNotice tone="offline" title="You’re offline.">
          Connections can’t be checked right now. Their last known status is shown.
        </InlineNotice>
      ) : null}
      {awaiting ? (
        <InlineNotice tone="attention" icon="clock" title="Waiting for approval." live>
          In the real app you approve access in the other app, then BiBrain checks it before showing Connected. This
          preview can’t open the other app, so it stays here until you cancel.
        </InlineNotice>
      ) : null}

      <section aria-labelledby="ks-h" className="bb-stack">
        <div className="bb-section__head" style={{ marginBottom: 0 }}>
          <div>
            <h2 id="ks-h" className="t-section">
              Knowledge sources
            </h2>
            <p className="t-muted">Places BiBrain can import notes from. Importing never gives an agent access.</p>
          </div>
        </div>
        <ul className="bb-list bb-connlist">
          {p.knowledge.map((k) => (
            <KnowledgeSourceRow
              key={k.id}
              conn={k}
              onConnect={p.onConnect}
              onCancel={p.onCancelKnowledge}
              onReviewImport={(id) => setModal({ kind: 'review-import', id })}
              onDisconnect={(id) => setModal({ kind: 'disconnect', id })}
            />
          ))}
        </ul>
      </section>

      <section aria-labelledby="ag-h" className="bb-stack">
        <div className="bb-section__head" style={{ marginBottom: 0 }}>
          <div>
            <h2 id="ag-h" className="t-section">
              Agents
            </h2>
            <p className="t-muted">Agents you allow to read chosen projects. Each one gets its own limited access.</p>
          </div>
          <Button variant="primary" icon="plus" onClick={() => setModal({ kind: 'add-agent' })} disabled={!p.projects.length}
            aria-describedby={!p.projects.length ? 'ag-noproj' : undefined}>
            Use with an agent
          </Button>
        </div>
        {!p.projects.length ? (
          <p id="ag-noproj" className="bb-help">
            Agents read projects. Save a note into a project first, then come back to share it.
          </p>
        ) : null}
        {p.agents.length ? (
          <ul className="bb-list bb-connlist">
            {p.agents.map((a) => (
              <AgentRow
                key={a.id}
                grant={a}
                onReviewAccess={(id) => setModal({ kind: 'review-access', id })}
                onRevoke={(id) => setModal({ kind: 'revoke', id })}
                onCancel={p.onCancelAgent}
              />
            ))}
          </ul>
        ) : (
          <EmptyState
            variant="no-connections"
            title="No agents can read your brain yet."
            body="When you add one, you’ll see exactly what it can read and propose before anything is shared."
          />
        )}
      </section>

      {modal?.kind === 'add-agent' ? (
        <GrantDialog
          title="Use with an agent"
          projects={p.projects}
          initial={{ label: '', projectIds: [], canPropose: false, expiresInDays: 30 }}
          confirmLabel="Create access"
          footnote="Preview: no access is created. The agent shows as “Awaiting authorization” until the real app verifies it."
          onCancel={() => setModal(null)}
          onConfirm={(d) => {
            p.onCreateGrant(d.label.trim(), d.projectIds, d.canPropose, d.expiresInDays);
            setModal(null);
          }}
        />
      ) : null}
      {modal?.kind === 'review-access'
        ? (() => {
            const g = p.agents.find((a) => a.id === modal.id)!;
            return (
              <GrantDialog
                title={`Review access — ${g.label}`}
                projects={p.projects}
                initial={{
                  label: g.label,
                  projectIds: g.readableProjects.map((x) => x.id),
                  canPropose: g.canPropose,
                  expiresInDays: 30,
                }}
                confirmLabel="Save changes"
                footnote={`Expires ${formatDate(g.expiresAt, true)} · Last verified ${g.lastVerifiedAccess ? formatDate(g.lastVerifiedAccess, true) : 'not yet'}`}
                onCancel={() => setModal(null)}
                onRevoke={g.state === 'connected' || g.state === 'needs-attention' ? () => setModal({ kind: 'revoke', id: g.id }) : undefined}
                onConfirm={(d) => {
                  p.onUpdateGrant(g.id, {
                    label: d.label.trim(),
                    readableProjects: p.projects.filter((x) => d.projectIds.includes(x.id)),
                    canPropose: d.canPropose,
                  });
                  setModal(null);
                }}
              />
            );
          })()
        : null}
      {modal?.kind === 'revoke'
        ? (() => {
            const g = p.agents.find((a) => a.id === modal.id)!;
            return (
              <ConfirmDialog
                variant="destructive"
                title={`Revoke access for ${g.label}?`}
                body="It stops reading and proposing right away."
                consequences={[
                  { label: 'Scope', text: g.readableProjects.map((x) => x.name).join(', ') || 'Its current access' },
                  { label: 'Delivered copies', text: 'Anything it already received stays with that agent.' },
                  { label: 'Your notes', text: 'Nothing in your brain is deleted.' },
                  { label: 'Reversible', text: 'You can create new access later.' },
                ]}
                confirmLabel="Revoke access"
                onCancel={() => setModal(null)}
                onConfirm={() => {
                  p.onRevoke(g.id);
                  setModal(null);
                }}
              />
            );
          })()
        : null}
      {modal?.kind === 'disconnect'
        ? (() => {
            const k = p.knowledge.find((x) => x.id === modal.id)!;
            return <DisconnectDialog conn={k} onCancel={() => setModal(null)} onConfirm={(remove) => { p.onDisconnect(k.id, remove); setModal(null); }} />;
          })()
        : null}
      {modal?.kind === 'review-import'
        ? (() => {
            const k = p.knowledge.find((x) => x.id === modal.id)!;
            const items = p.sources.filter((s) => s.project).slice(0, k.importedCount);
            return (
              <Dialog title={`Review import — ${k.name}`} description={`Scope: ${k.scope}`} onClose={() => setModal(null)} footer={<Button variant="primary" onClick={() => setModal(null)}>Done</Button>}>
                {p.isDemo ? <StatusPill status="demo" /> : null}
                <p className="t-muted">
                  <span className="bb-num">{k.importedCount}</span> notes came from here. Last successful check:{' '}
                  <span className="bb-num">{formatDate(k.lastSuccessfulCheck, true)}</span>.
                </p>
                <ul className="bb-list bb-sourcelist">
                  {items.map((s) => (
                    <li key={s.id} style={{ padding: '10px 0' }}>
                      <p className="t-label">{s.title}</p>
                      <p className="t-meta">{s.project?.name ?? 'Inbox'}</p>
                    </li>
                  ))}
                </ul>
                {k.state === 'needs-attention' ? (
                  <InlineNotice tone="attention" title="The last check failed.">
                    Notes already imported are kept. New changes may be missing until it is checked again.
                  </InlineNotice>
                ) : null}
              </Dialog>
            );
          })()
        : null}
    </div>
  );
}

function GrantDialog({
  title,
  projects,
  initial,
  confirmLabel,
  footnote,
  onCancel,
  onConfirm,
  onRevoke,
}: {
  title: string;
  projects: ProjectRef[];
  initial: PermissionDraft;
  confirmLabel: string;
  footnote: string;
  onCancel: () => void;
  onConfirm: (d: PermissionDraft) => void;
  onRevoke?: () => void;
}) {
  const [d, setD] = useState<PermissionDraft>(initial);
  const valid = d.label.trim() && d.projectIds.length > 0;
  return (
    <Dialog
      title={title}
      description="Pick exactly what it can use. There is no “allow everything”."
      onClose={onCancel}
      size="side"
      dataUi="permission-preview"
      footer={
        <>
          {onRevoke ? (
            <Button variant="destructive" icon="lock" onClick={onRevoke}>
              Revoke
            </Button>
          ) : null}
          <Button onClick={onCancel}>Cancel</Button>
          <Button variant="primary" disabled={!valid} onClick={() => onConfirm(d)} aria-describedby={!valid ? 'grant-hint' : undefined}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      <PermissionPreview variant={permissionVariant(d)} draft={d} projects={projects} editable onChange={setD} />
      {!valid ? (
        <p id="grant-hint" className="bb-help">
          Add a name and choose at least one project.
        </p>
      ) : null}
      <p className="t-meta">{footnote}</p>
    </Dialog>
  );
}

function DisconnectDialog({
  conn,
  onCancel,
  onConfirm,
}: {
  conn: KnowledgeSourceConnection;
  onCancel: () => void;
  onConfirm: (removeImported: boolean) => void;
}) {
  const [remove, setRemove] = useState(false);
  return (
    <Dialog
      title={`Disconnect ${conn.name}?`}
      description="BiBrain stops checking it for changes."
      size="sm"
      onClose={onCancel}
      footer={
        <>
          <Button onClick={onCancel}>Cancel</Button>
          <Button variant="destructive-solid" onClick={() => onConfirm(remove)}>
            Disconnect
          </Button>
        </>
      }
    >
      <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="bb-stack">
        <legend className="bb-label" style={{ marginBottom: 8 }}>
          What about the <span className="bb-num">{conn.importedCount}</span> notes already imported?
        </legend>
        <label className="bb-row" style={{ minHeight: 44, alignItems: 'flex-start' }}>
          <input type="radio" name="retain" style={{ width: 20, height: 20, marginTop: 2 }} checked={!remove} onChange={() => setRemove(false)} />
          <span>
            <strong style={{ fontWeight: 600 }}>Keep them in my brain</strong>
            <br />
            <span className="t-meta">They stay searchable. You can delete them later.</span>
          </span>
        </label>
        <label className="bb-row" style={{ minHeight: 44, alignItems: 'flex-start' }}>
          <input type="radio" name="retain" style={{ width: 20, height: 20, marginTop: 2 }} checked={remove} onChange={() => setRemove(true)} />
          <span>
            <strong style={{ fontWeight: 600 }}>Remove them too</strong>
            <br />
            <span className="t-meta">The originals in {conn.name} are not touched.</span>
          </span>
        </label>
      </fieldset>
    </Dialog>
  );
}
