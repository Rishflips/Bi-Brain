import { useEffect, useRef, useState } from 'react';
import { Button } from '../components/Button';
import { ConfirmDialog, Dialog } from '../components/Dialog';
import { EmptyState, InlineNotice, Skeleton } from '../components/Feedback';
import { SearchField, SourceRow, type SearchFieldState } from '../components/Search';
import { SourceViewer, type SourceTab } from '../components/SourceViewer';
import { StatusPill } from '../components/StatusPill';
import { Icon } from '../components/Icon';
import type { ProjectRef, SearchFilters, SearchScope, SearchState, SourceDetail, SourceType } from '../domain/types';
import { typeLabel } from '../lib/format';

export interface BrainScreenProps {
  isDemo: boolean;
  offline: boolean;
  wide: boolean;
  sources: SourceDetail[];
  projects: ProjectRef[];
  query: string;
  scope: SearchScope;
  filters: SearchFilters;
  searchState: SearchState;
  selected: SourceDetail | null;
  missingSourceId: string | null;
  tab: SourceTab;
  focusVersion?: number;
  focusSearch: boolean;
  onFocusedSearch: () => void;
  onQuery: (q: string) => void;
  onScope: (s: SearchScope) => void;
  onFilters: (f: SearchFilters) => void;
  onOpenSource: (id: string, version?: number) => void;
  onCloseSource: () => void;
  onTab: (t: SourceTab) => void;
  onSaveSomething: () => void;
  onOpenPrepared: (id: string) => void;
  onEditUnderstanding: (sourceId: string, statementId: string, text: string) => void;
  onCorrectSource: (sourceId: string, text: string) => void;
  onWithdraw: (sourceId: string, withdraw: boolean) => void;
  onDelete: (sourceId: string) => void;
  onCopyBrief: (src: SourceDetail) => void;
  onDownload: (src: SourceDetail) => void;
}

const ALL_TYPES: SourceType[] = ['note', 'decision', 'goal', 'question'];

export function BrainScreen(p: BrainScreenProps) {
  const searchRef = useRef<HTMLInputElement>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [dialog, setDialog] = useState<null | 'correct' | 'withdraw' | 'delete'>(null);

  useEffect(() => {
    if (p.focusSearch) {
      searchRef.current?.focus();
      p.onFocusedSearch();
    }
  }, [p.focusSearch, p]);

  const inScope = (s: SourceDetail) =>
    p.scope.kind === 'everything' ||
    (p.scope.kind === 'inbox' && s.project === null) ||
    (p.scope.kind === 'project' && s.project?.id === p.scope.projectId);

  const fieldState: SearchFieldState = p.offline
    ? 'offline'
    : p.searchState.kind === 'empty'
      ? p.query
        ? 'active'
        : 'empty'
      : p.searchState.kind;

  const filterCount = p.filters.types.length + (p.filters.updated !== 'any' ? 1 : 0);
  const recent = [...p.sources].filter(inScope).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  const showDetailOnly = Boolean(p.selected || p.missingSourceId) && !p.wide;

  const viewer = p.selected ? (
    <SourceViewer
      key={p.selected.id}
      source={p.selected}
      tab={p.tab}
      onTabChange={p.onTab}
      onClose={p.onCloseSource}
      closeLabel={p.wide ? 'Close' : 'Back to Your brain'}
      onSeeSource={(id, v) => p.onOpenSource(id, v)}
      onEditUnderstanding={(sid, text) => p.onEditUnderstanding(p.selected!.id, sid, text)}
      onCorrectSource={() => setDialog('correct')}
      onWithdraw={() => setDialog('withdraw')}
      onRestore={() => p.onWithdraw(p.selected!.id, false)}
      onDelete={() => setDialog('delete')}
      onCopyBrief={() => p.onCopyBrief(p.selected!)}
      onDownloadMarkdown={() => p.onDownload(p.selected!)}
      onOpenPrepared={p.onOpenPrepared}
      focusVersion={p.focusVersion}
      isDemo={p.isDemo}
    />
  ) : p.missingSourceId ? (
    <div className="bb-tabpanel">
      <InlineNotice
        tone="attention"
        title="This source isn’t available."
        actions={<Button size="sm" icon="arrow-left" onClick={p.onCloseSource}>Back to Your brain</Button>}
      >
        It may have been deleted. Anything that cited it now shows the evidence as unavailable.
      </InlineNotice>
    </div>
  ) : null;

  const citationNotice =
    p.selected && p.focusVersion && p.focusVersion < p.selected.versions.length ? (
      <div style={{ padding: '0 24px' }}>
        <InlineNotice tone="info" title={`Cited from version ${p.focusVersion}.`}>
          The text below is the current version ({p.selected.versions.length}). The cited version is marked in History.
        </InlineNotice>
      </div>
    ) : null;

  return (
    <>
      {showDetailOnly ? (
        <div className="bb-panel" style={{ position: 'static', maxHeight: 'none' }}>
          {viewer}
          {citationNotice}
        </div>
      ) : (
        <div className={`bb-brain-layout${(p.selected || p.missingSourceId) && p.wide ? ' bb-brain-layout--split' : ''}`}>
          <div className="bb-stack" style={{ gap: 24, minWidth: 0 }}>
            <header className="bb-stack" style={{ gap: 8 }}>
              <div className="bb-row" style={{ justifyContent: 'space-between' }}>
                <h1 className="t-page" tabIndex={-1} id="brain-h">
                  Your brain
                </h1>
                {p.isDemo ? <StatusPill status="demo" /> : null}
              </div>
              <p className="t-muted">
                <span className="bb-num">{p.sources.length}</span> {p.sources.length === 1 ? 'note' : 'notes'} ·{' '}
                <span className="bb-num">{p.projects.length}</span> {p.projects.length === 1 ? 'project' : 'projects'}
              </p>
            </header>

            {p.sources.length === 0 ? (
              <EmptyState
                variant="new-brain"
                title="Nothing saved yet."
                body="Notes you save show up here, ready to find and to share with the agents you choose."
                actions={
                  <Button variant="gold" icon="plus" onClick={p.onSaveSomething}>
                    Save something
                  </Button>
                }
              />
            ) : (
              <>
                <SearchField
                  ref={searchRef}
                  value={p.query}
                  state={fieldState}
                  resultCount={p.searchState.kind === 'results' ? p.searchState.results.length : 0}
                  onChange={p.onQuery}
                  onClear={() => {
                    p.onQuery('');
                    searchRef.current?.focus();
                  }}
                />
                <div className="bb-row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div className="bb-chips" role="group" aria-label="Where to look">
                    <ScopeChip label="Everything" active={p.scope.kind === 'everything'} onClick={() => p.onScope({ kind: 'everything' })} />
                    <ScopeChip label="Inbox" active={p.scope.kind === 'inbox'} onClick={() => p.onScope({ kind: 'inbox' })} />
                    {p.projects.map((pr) => (
                      <ScopeChip
                        key={pr.id}
                        label={pr.name}
                        active={p.scope.kind === 'project' && p.scope.projectId === pr.id}
                        onClick={() => p.onScope({ kind: 'project', projectId: pr.id })}
                      />
                    ))}
                  </div>
                  <Button size="sm" icon="filter" onClick={() => setFiltersOpen(true)} aria-haspopup="dialog">
                    Filters{filterCount ? ` (${filterCount})` : ''}
                  </Button>
                </div>

                <section aria-labelledby="results-h">
                  <h2 id="results-h" className="t-label t-muted" style={{ marginBottom: 8 }}>
                    {p.query ? 'Matching notes' : 'Recent'}
                  </h2>
                  {p.searchState.kind === 'loading' ? (
                    <div className="bb-stack" style={{ gap: 4 }}>
                      <Skeleton variant="row" label="Searching" />
                      <Skeleton variant="row" label="Searching" />
                    </div>
                  ) : p.searchState.kind === 'no-results' ? (
                    <EmptyState
                      variant="no-results"
                      title="No matching notes."
                      body="Try a different word or save something new."
                      actions={
                        <>
                          <Button onClick={() => p.onQuery('')}>Clear search</Button>
                          <Button variant="gold" icon="plus" onClick={p.onSaveSomething}>
                            Save something
                          </Button>
                        </>
                      }
                    />
                  ) : p.searchState.kind === 'results' ? (
                    <ul className="bb-list bb-sourcelist">
                      {p.searchState.results.map((r) => (
                        <li key={r.source.id}>
                          <SourceRow source={r.source} result={r} selected={p.selected?.id === r.source.id} onOpen={(id) => p.onOpenSource(id)} />
                        </li>
                      ))}
                    </ul>
                  ) : recent.length ? (
                    <ul className="bb-list bb-sourcelist">
                      {recent.map((s) => (
                        <li key={s.id}>
                          <SourceRow source={s} selected={p.selected?.id === s.id} onOpen={(id) => p.onOpenSource(id)} />
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="t-muted">Nothing here yet.</p>
                  )}
                </section>

                <section aria-labelledby="projects-h" className="bb-section" style={{ marginTop: 24 }}>
                  <div className="bb-section__head">
                    <h2 id="projects-h" className="t-section">
                      Projects
                    </h2>
                  </div>
                  <div className="bb-projects">
                    <button type="button" className="bb-project" onClick={() => p.onScope({ kind: 'inbox' })}>
                      <Icon name="inbox" />
                      <span className="t-card">Inbox</span>
                      <span className="t-meta">
                        <span className="bb-num">{p.sources.filter((s) => !s.project).length}</span> notes not sorted yet
                      </span>
                    </button>
                    {p.projects.map((pr) => (
                      <button key={pr.id} type="button" className="bb-project" onClick={() => p.onScope({ kind: 'project', projectId: pr.id })}>
                        <Icon name="folder" />
                        <span className="t-card">{pr.name}</span>
                        <span className="t-meta">
                          <span className="bb-num">{p.sources.filter((s) => s.project?.id === pr.id).length}</span> notes
                          {p.isDemo ? ' · Demo data' : ''}
                        </span>
                      </button>
                    ))}
                  </div>
                </section>
              </>
            )}
          </div>
          {(p.selected || p.missingSourceId) && p.wide ? (
            <aside className="bb-panel" aria-label="Source detail">
              {viewer}
              {citationNotice}
            </aside>
          ) : null}
        </div>
      )}

      {filtersOpen ? (
        <FiltersSheet filters={p.filters} onApply={(f) => { p.onFilters(f); setFiltersOpen(false); }} onClose={() => setFiltersOpen(false)} />
      ) : null}

      {dialog === 'correct' && p.selected ? (
        <CorrectSourceDialog
          source={p.selected}
          onCancel={() => setDialog(null)}
          onSave={(text) => {
            p.onCorrectSource(p.selected!.id, text);
            setDialog(null);
          }}
        />
      ) : null}
      {dialog === 'withdraw' && p.selected ? (
        <ConfirmDialog
          variant="destructive"
          title="Withdraw from active use?"
          body="BiBrain stops using this note and what it remembers from it."
          consequences={[
            { label: 'Scope', text: 'This note and its understanding. Other notes are not affected.' },
            { label: 'Kept', text: 'The original and its history stay here so you can read them.' },
            { label: 'Delivered copies', text: 'Agents that already received it keep their copy.' },
            { label: 'Reversible', text: 'Yes. Return it to active use at any time.' },
          ]}
          confirmLabel="Withdraw"
          onCancel={() => setDialog(null)}
          onConfirm={() => {
            p.onWithdraw(p.selected!.id, true);
            setDialog(null);
          }}
        />
      ) : null}
      {dialog === 'delete' && p.selected ? (
        <ConfirmDialog
          variant="permanent"
          title="Delete permanently?"
          body={`“${p.selected.title}” will be removed from your brain.`}
          consequences={[
            {
              label: 'Scope',
              text: `This note, its ${p.selected.versions.length} ${p.selected.versions.length === 1 ? 'version' : 'versions'}, and what BiBrain remembers from it.`,
            },
            { label: 'Backups', text: 'Copies in backups you made yourself are not touched. Delete those separately.' },
            { label: 'Delivered copies', text: 'Agents that already received it keep their copy.' },
            { label: 'Used in', text: p.selected.usedIn.length ? `${p.selected.usedIn.length} prepared item(s) will show this evidence as unavailable.` : 'Nothing depends on it.' },
            { label: 'Reversible', text: 'No. Withdraw instead if you might need it later.' },
          ]}
          confirmLabel="Delete permanently"
          confirmPhrase="delete"
          onCancel={() => setDialog(null)}
          onConfirm={() => {
            const id = p.selected!.id;
            setDialog(null);
            p.onCloseSource();
            p.onDelete(id);
          }}
        />
      ) : null}
    </>
  );
}

function ScopeChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button type="button" className="bb-chip" aria-pressed={active} onClick={onClick}>
      {active ? <Icon name="check" size={16} /> : null}
      {label}
    </button>
  );
}

function FiltersSheet({
  filters,
  onApply,
  onClose,
}: {
  filters: SearchFilters;
  onApply: (f: SearchFilters) => void;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState<SearchFilters>(filters);
  return (
    <Dialog
      title="Filters"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <Button onClick={() => setDraft({ types: [], updated: 'any' })}>Clear filters</Button>
          <Button variant="primary" onClick={() => onApply(draft)}>
            Show notes
          </Button>
        </>
      }
    >
      <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="bb-stack">
        <legend className="bb-label" style={{ marginBottom: 8 }}>
          Type
        </legend>
        {ALL_TYPES.map((t) => (
          <label key={t} className="bb-row" style={{ minHeight: 44 }}>
            <input
              type="checkbox"
              style={{ width: 20, height: 20 }}
              checked={draft.types.includes(t)}
              onChange={(e) =>
                setDraft({ ...draft, types: e.target.checked ? [...draft.types, t] : draft.types.filter((x) => x !== t) })
              }
            />
            {typeLabel[t]}
          </label>
        ))}
      </fieldset>
      <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="bb-stack">
        <legend className="bb-label" style={{ marginBottom: 8 }}>
          Updated
        </legend>
        {(
          [
            ['any', 'Any time'],
            ['week', 'In the last week'],
            ['month', 'In the last month'],
          ] as const
        ).map(([v, l]) => (
          <label key={v} className="bb-row" style={{ minHeight: 44 }}>
            <input
              type="radio"
              name="updated"
              style={{ width: 20, height: 20 }}
              checked={draft.updated === v}
              onChange={() => setDraft({ ...draft, updated: v })}
            />
            {l}
          </label>
        ))}
      </fieldset>
    </Dialog>
  );
}

function CorrectSourceDialog({
  source,
  onCancel,
  onSave,
}: {
  source: SourceDetail;
  onCancel: () => void;
  onSave: (text: string) => void;
}) {
  const [text, setText] = useState(source.original);
  return (
    <Dialog
      title="Correct source"
      description="Your correction is saved as a new version. Earlier versions stay in History."
      onClose={onCancel}
      footer={
        <>
          <Button onClick={onCancel}>Cancel</Button>
          <Button variant="primary" disabled={!text.trim() || text === source.original} onClick={() => onSave(text)}>
            Save as new version
          </Button>
        </>
      }
    >
      <label className="bb-label" htmlFor="correct-src">
        Source text
      </label>
      <textarea id="correct-src" className="bb-textarea" style={{ minHeight: 240 }} value={text} onChange={(e) => setText(e.target.value)} />
      <p className="bb-help">Anything BiBrain remembered from the older version will be marked “Source changed” for review.</p>
    </Dialog>
  );
}
