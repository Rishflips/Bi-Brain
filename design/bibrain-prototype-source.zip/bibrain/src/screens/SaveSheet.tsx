import { useEffect, useRef } from 'react';
import { Dialog } from '../components/Dialog';
import { SaveComposer, SavedReceipt } from '../components/Capture';
import type { CaptureDraft, CaptureState, PreparationState, ProjectRef } from '../domain/types';

export interface SaveSheetProps {
  draft: CaptureDraft;
  state: CaptureState;
  preparation: PreparationState;
  projects: ProjectRef[];
  limitChars: number;
  onChange: (d: CaptureDraft) => void;
  onImportFile: (f: File) => void;
  onSave: (opts?: { allowDuplicate?: boolean }) => void;
  onClose: () => void;
  onViewOriginal: (id: string) => void;
  onFindInBrain: () => void;
  onSaveAnother: () => void;
  onRetryPreparation: () => void;
}

/** Modal on desktop, full-height sheet on phones (handled by Dialog CSS). */
export function SaveSheet(p: SaveSheetProps) {
  const receiptHeading = useRef<HTMLHeadingElement>(null);
  const saved = p.state.kind === 'saved';
  useEffect(() => {
    if (saved) receiptHeading.current?.focus();
  }, [saved]);

  return (
    <Dialog
      title="Save something"
      description={saved ? undefined : 'It stays in your brain, ready for any agent you connect.'}
      onClose={p.onClose}
      dismissible={p.state.kind !== 'saving'}
      dataUi="save-something-dialog"
    >
      {saved && p.state.kind === 'saved' ? (
        <SavedReceipt
          variant="saved"
          receipt={p.state.receipt}
          preparation={p.preparation}
          headingRef={receiptHeading}
          onViewOriginal={p.onViewOriginal}
          onFindInBrain={p.onFindInBrain}
          onSaveAnother={p.onSaveAnother}
          onDismiss={p.onClose}
          onRetryPreparation={p.onRetryPreparation}
        />
      ) : (
        <SaveComposer
          draft={p.draft}
          state={p.state}
          projects={p.projects}
          limitChars={p.limitChars}
          onChange={p.onChange}
          onImportFile={p.onImportFile}
          onSave={p.onSave}
          onCancel={p.onClose}
          onOpenExisting={p.onViewOriginal}
          autoFocus
        />
      )}
    </Dialog>
  );
}
