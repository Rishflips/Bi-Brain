import { useId, useState, type ReactNode } from 'react';
import { Button } from '../components/Button';
import { ConfirmDialog } from '../components/Dialog';
import { InlineNotice } from '../components/Feedback';
import { Icon } from '../components/Icon';
import { StatusPill } from '../components/StatusPill';
import type { AgentGrant, Appearance, SettingsVM } from '../domain/types';

export interface SettingsScreenProps {
  settings: SettingsVM;
  reducedMotion: boolean;
  isDemo: boolean;
  agents: AgentGrant[];
  sourceCount: number;
  onChange: (fn: (s: SettingsVM) => SettingsVM) => void;
  onExport: () => void;
  onDeleteEverything: () => void;
  onRevokeAll: () => void;
  onSignOut: () => void;
}

const GROUPS = [
  ['appearance', 'Appearance'],
  ['background', 'Background help'],
  ['spending', 'Processing & spending'],
  ['plan', 'Plan'],
  ['privacy', 'Privacy & data'],
  ['security', 'Security'],
] as const;

export function SettingsScreen(p: SettingsScreenProps) {
  const [confirm, setConfirm] = useState<null | 'delete-all' | 'revoke-all'>(null);
  const bh = p.settings.backgroundHelp;
  const sp = p.settings.spending;
  const setBH = (patch: Partial<SettingsVM['backgroundHelp']>) =>
    p.onChange((s) => ({ ...s, backgroundHelp: { ...s.backgroundHelp, ...patch } }));
  const setSP = (patch: Partial<SettingsVM['spending']>) => p.onChange((s) => ({ ...s, spending: { ...s.spending, ...patch } }));
  const activeAgents = p.agents.filter((a) => a.state !== 'revoked');

  return (
    <div className="bb-stack" style={{ gap: 32 }}>
      <header className="bb-stack" style={{ gap: 8 }}>
        <h1 className="t-page" tabIndex={-1}>
          Settings &amp; privacy
        </h1>
        <p className="t-muted t-body-lg measure">How BiBrain looks, when it helps, and what it keeps.</p>
      </header>

      <div className="bb-settings">
        <nav className="bb-settings__toc" aria-label="Settings sections">
          {GROUPS.map(([id, label]) => (
            <a key={id} href={`#settings`} onClick={(e) => { e.preventDefault(); document.getElementById(`set-${id}`)?.scrollIntoView({ block: 'start' }); document.getElementById(`set-${id}-h`)?.focus(); }}>
              {label}
            </a>
          ))}
        </nav>

        <div className="bb-stack" style={{ gap: 32, minWidth: 0 }}>
          <Group id="appearance" title="Appearance">
            <fieldset style={{ border: 0, padding: 0, margin: 0 }} className="bb-stack" >
              <legend className="bb-label" style={{ marginBottom: 8 }}>Theme</legend>
              <div className="bb-segmented">
                {(
                  [
                    ['light', 'Light', 'sun'],
                    ['dark', 'Dark', 'moon'],
                    ['system', 'System', 'monitor'],
                  ] as [Appearance, string, string][]
                ).map(([v, l, icon]) => (
                  <label key={v}>
                    <input
                      type="radio"
                      name="appearance"
                      value={v}
                      checked={p.settings.appearance === v}
                      onChange={() => p.onChange((s) => ({ ...s, appearance: v }))}
                    />
                    <span>
                      <Icon name={icon} size={18} />
                      {l}
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
            <Row title="Reduced motion" body="Follows your device setting. When it’s on, BiBrain stops breathing and moving effects and shows status as text.">
              <StatusPill status="neutral" icon={p.reducedMotion ? 'pause' : 'play'} label={p.reducedMotion ? 'On' : 'Off'} />
            </Row>
          </Group>

          <Group id="background" title="Background help">
            <Row title="Remember" body={bh.paused ? 'Off while background help is paused.' : 'Connect new notes to the right project and goal.'}>
              <Switch label="Remember" checked={bh.remember} onChange={(v) => setBH({ remember: v })} disabled={bh.paused} />
            </Row>
            <Row title="Prepare" body={bh.paused ? 'Off while background help is paused.' : 'Get work ready for your goals for you to review. Nothing is applied without you.'}>
              <Switch label="Prepare" checked={bh.prepare} onChange={(v) => setBH({ prepare: v })} disabled={bh.paused} />
            </Row>
            <Row title="Pause background help" body="Saving and search keep working while paused.">
              <Switch label="Pause background help" checked={bh.paused} onChange={(v) => setBH({ paused: v })} />
            </Row>
            <Row title="Quiet hours" body="No new prepared work arrives during these hours.">
              <Switch label="Quiet hours" checked={bh.quietHoursOn} onChange={(v) => setBH({ quietHoursOn: v })} />
            </Row>
            {bh.quietHoursOn ? (
              <div className="bb-row" style={{ gap: 16 }}>
                <TimeField label="From" value={bh.quietFrom} onChange={(v) => setBH({ quietFrom: v })} />
                <TimeField label="To" value={bh.quietTo} onChange={(v) => setBH({ quietTo: v })} />
              </div>
            ) : null}
            <Row title="Time zone" body="Detected from this device. Used for quiet hours and dates.">
              <span className="t-label">{bh.timeZone}</span>
            </Row>
          </Group>

          <Group id="spending" title="Processing & spending">
            <Row
              title="Allow outside processing"
              body="Lets BiBrain send selected text to the processing service you set up, to prepare work. Off means nothing leaves this computer."
            >
              <Switch label="Allow outside processing" checked={sp.providerConsent} onChange={(v) => setSP({ providerConsent: v })} />
            </Row>
            <div className="bb-row" style={{ gap: 16, alignItems: 'flex-start' }}>
              <CapField label="Daily limit" value={sp.dailyCap} onChange={(v) => setSP({ dailyCap: v })} disabled={!sp.providerConsent} />
              <CapField label="Limit per task" value={sp.perJobCap} onChange={(v) => setSP({ perJobCap: v })} disabled={!sp.providerConsent} />
            </div>
            <p className="bb-help">
              {sp.providerConsent
                ? 'BiBrain stops preparing when a limit is reached and tells you. Limits are enforced by the installed app.'
                : 'Turn on outside processing to set limits.'}
            </p>
            <Row title="Availability" body="Whether processing can run right now.">
              <StatusPill status="neutral" label="Unknown in this preview" />
            </Row>
            <details className="bb-details">
              <summary>Advanced</summary>
              <p className="t-muted" style={{ paddingBottom: 8 }}>
                Processing details such as the service, version and price are set by the installed app. They are not shown in
                this preview.
              </p>
            </details>
          </Group>

          <Group id="plan" title="Plan">
            <div className="bb-card bb-stack" style={{ gap: 8 }}>
              <div className="bb-row" style={{ justifyContent: 'space-between' }}>
                <p className="t-card">Local edition</p>
                <StatusPill status="ready" label="This computer" />
              </div>
              <p className="t-muted">Your brain runs and stays on this computer.</p>
            </div>
            <div className="bb-card bb-card--muted bb-stack" style={{ gap: 8 }}>
              <div className="bb-row" style={{ justifyContent: 'space-between' }}>
                <p className="t-card">Managed plan</p>
                <StatusPill status="paused" icon="lock" label="Unavailable in this preview" />
              </div>
              <p className="t-muted">Plan details and checkout are not part of this preview.</p>
              <div>
                <Button disabled aria-describedby="plan-na">
                  See plans
                </Button>
                <p id="plan-na" className="bb-help" style={{ marginTop: 6 }}>
                  Unavailable in this preview.
                </p>
              </div>
            </div>
          </Group>

          <Group id="privacy" title="Privacy & data">
            <Row title="Export everything" body="Download all notes and what BiBrain remembers as one Markdown file.">
              <Button size="sm" icon="download" onClick={p.onExport} disabled={!p.sourceCount}>
                Export
              </Button>
            </Row>
            <Row title="Backups" body="Keep your own copy: export regularly, or back up the folder where BiBrain is installed. BiBrain never deletes your backups." >
              <span />
            </Row>
            <Row title="Withdraw a note" body="Open any note in Your brain and choose “Withdraw from active use”. Agents stop receiving it; the original stays with you.">
              <a className="bb-btn bb-btn--sm" href="#brain">Your brain</a>
            </Row>
            <Row title="Delete everything" body="Permanently remove every note, version and prepared item in this brain.">
              <Button size="sm" variant="destructive" icon="trash" onClick={() => setConfirm('delete-all')} disabled={!p.sourceCount}>
                Delete…
              </Button>
            </Row>
          </Group>

          <Group id="security" title="Security">
            <Row title="Active sessions" body={p.isDemo ? 'This browser — example workspace' : 'This browser — preview session'}>
              <Button size="sm" onClick={p.onSignOut}>
                Sign out of this device
              </Button>
            </Row>
            <Row
              title="Agent access"
              body={`${activeAgents.length} ${activeAgents.length === 1 ? 'agent has' : 'agents have'} access right now.`}
            >
              <div className="bb-actions">
                <a className="bb-btn bb-btn--sm" href="#connections">
                  Review
                </a>
                <Button size="sm" variant="destructive" icon="lock" disabled={!activeAgents.length} onClick={() => setConfirm('revoke-all')}>
                  Revoke all
                </Button>
              </div>
            </Row>
          </Group>
        </div>
      </div>

      {p.isDemo ? (
        <InlineNotice tone="info" title="Settings in the example">
          Changes here only affect this preview tab.
        </InlineNotice>
      ) : null}

      {confirm === 'delete-all' ? (
        <ConfirmDialog
          variant="permanent"
          title="Delete everything?"
          body="Every note, version, and prepared item in this brain will be removed."
          consequences={[
            { label: 'Scope', text: `${p.sourceCount} notes and everything BiBrain remembers from them.` },
            { label: 'Backups', text: 'Exports and backups you made are not touched.' },
            { label: 'Delivered copies', text: 'Agents that already received notes keep their copies.' },
            { label: 'Reversible', text: 'No.' },
          ]}
          confirmLabel="Delete everything"
          confirmPhrase="delete everything"
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            p.onDeleteEverything();
            setConfirm(null);
          }}
        />
      ) : null}
      {confirm === 'revoke-all' ? (
        <ConfirmDialog
          variant="destructive"
          title="Revoke all agent access?"
          body="Every agent stops reading and proposing right away."
          consequences={[
            { label: 'Delivered copies', text: 'Anything already received stays with those agents.' },
            { label: 'Your notes', text: 'Nothing in your brain is deleted.' },
            { label: 'Reversible', text: 'You can create new access later.' },
          ]}
          confirmLabel="Revoke all"
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            p.onRevokeAll();
            setConfirm(null);
          }}
        />
      ) : null}
    </div>
  );
}

function Group({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    <section id={`set-${id}`} className="bb-setting-group bb-card" aria-labelledby={`set-${id}-h`}>
      <h2 id={`set-${id}-h`} className="t-section" tabIndex={-1} style={{ marginBottom: 12 }}>
        {title}
      </h2>
      <div className="bb-stack" style={{ gap: 0 }}>
        {children}
      </div>
    </section>
  );
}

function Row({ title, body, children }: { title: string; body: string; children: ReactNode }) {
  return (
    <div className="bb-setting">
      <div className="bb-setting__text">
        <p className="t-label" style={{ fontSize: 16 }}>
          {title}
        </p>
        <p className="t-muted" style={{ fontSize: 14 }}>
          {body}
        </p>
      </div>
      {children}
    </div>
  );
}

function Switch({ label, checked, onChange, disabled }: { label: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className="bb-switch"
      disabled={disabled}
      title={disabled ? 'Unavailable while background help is paused' : undefined}
      onClick={() => onChange(!checked)}
    />
  );
}

function TimeField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const id = useId();
  return (
    <div className="bb-field-group" style={{ width: 160 }}>
      <label className="bb-label" htmlFor={id}>
        {label}
      </label>
      <input id={id} type="time" className="bb-input bb-num" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function CapField({ label, value, onChange, disabled }: { label: string; value: string; onChange: (v: string) => void; disabled?: boolean }) {
  const id = useId();
  return (
    <div className="bb-field-group" style={{ flex: '1 1 180px', maxWidth: 240 }}>
      <label className="bb-label" htmlFor={id}>
        {label}
      </label>
      <input
        id={id}
        className="bb-input bb-num"
        inputMode="decimal"
        placeholder="Not set"
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value.replace(/[^0-9.]/g, ''))}
      />
    </div>
  );
}
