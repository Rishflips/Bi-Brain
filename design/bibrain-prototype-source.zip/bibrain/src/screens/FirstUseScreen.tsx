import { useId, useRef, useState } from 'react';
import { BrandLockup } from '../components/BrandLockup';
import { Button } from '../components/Button';
import { Icon } from '../components/Icon';
import { InlineNotice } from '../components/Feedback';

export interface FirstUseScreenProps {
  state: 'idle' | 'pairing' | 'error';
  errorMessage?: string;
  onOpenBrain: (code: string) => void;
  onTryExample: () => void;
}

export function FirstUseScreen({ state, errorMessage, onOpenBrain, onTryExample }: FirstUseScreenProps) {
  const [code, setCode] = useState('');
  const id = useId();
  const inputRef = useRef<HTMLInputElement>(null);
  const pairing = state === 'pairing';
  return (
    <main id="main" className="bb-firstuse" data-ui="first-use">
      <section className="bb-firstuse__intro" aria-labelledby={`${id}-h`}>
        <div style={{ marginBottom: 16 }}>
          <BrandLockup variant="horizontal" width={240} alt="BiBrain" />
        </div>
        <p className="t-eyebrow">Your thinking, still alive</p>
        <h1 id={`${id}-h`} className="t-display" style={{ maxWidth: '14ch' }}>
          A private brain for everything you are building.
        </h1>
        <p className="t-body-lg t-muted measure">
          Save what matters once. Continue with any agent without rebuilding the context.
        </p>
        <ul className="bb-trust" aria-label="What you can count on">
          <li>
            <span className="bb-trust__icon" aria-hidden="true">
              <Icon name="lock" />
            </span>
            Private by default
          </li>
          <li>
            <span className="bb-trust__icon" aria-hidden="true">
              <Icon name="file" />
            </span>
            Originals stay inspectable
          </li>
          <li>
            <span className="bb-trust__icon" aria-hidden="true">
              <Icon name="shield" />
            </span>
            You control every connection
          </li>
        </ul>
      </section>

      <section className="bb-pairing" aria-labelledby={`${id}-pair`}>
        <span className="bb-pairing__lock" aria-hidden="true">
          <Icon name="lock" size={22} />
        </span>
        <div className="bb-stack" style={{ gap: 6 }}>
          <h2 id={`${id}-pair`} className="t-section">
            Open your local brain
          </h2>
          <p className="t-muted">Enter the installation code stored on this computer. No account is required.</p>
        </div>
        <form
          className="bb-stack"
          onSubmit={(e) => {
            e.preventDefault();
            onOpenBrain(code);
          }}
          aria-busy={pairing || undefined}
        >
          <div className="bb-field-group">
            <label className="bb-label" htmlFor={`${id}-code`}>
              Installation code
            </label>
            <input
              ref={inputRef}
              id={`${id}-code`}
              className="bb-input bb-code-input"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="ABCD-1234-EFGH"
              autoComplete="one-time-code"
              spellCheck={false}
              disabled={pairing}
              aria-invalid={state === 'error' || undefined}
              aria-describedby={`${id}-sec ${state === 'error' ? `${id}-err` : ''}`}
            />
          </div>
          {state === 'error' ? (
            <div id={`${id}-err`}>
              <InlineNotice tone="failure" title="That didn’t open your brain." live>
                {errorMessage}
              </InlineNotice>
            </div>
          ) : null}
          <p id={`${id}-sec`} className="bb-security">
            <strong style={{ fontWeight: 620, color: 'var(--text)' }}>Why a code?</strong> It proves this browser is on
            the same computer as your brain. Your installation created it, and it stays on this computer.
          </p>
          <Button type="submit" variant="primary" loading={pairing} loadingLabel="Opening…" block>
            Open my brain
          </Button>
          <Button onClick={onTryExample} block icon="eye" disabled={pairing}>
            Try an example
          </Button>
          <p className="t-meta" style={{ textAlign: 'center' }}>
            The example uses synthetic demo data and is kept separate from your brain.
          </p>
        </form>
      </section>
    </main>
  );
}
