/**
 * BiBrain view models and state inputs.
 *
 * These types describe what the interface SHOWS. They are deliberately free of
 * transport, storage, or provider details so the existing BiBrain services can
 * map their own domain objects onto them without changing tested behavior.
 */

/* ------------------------------------------------------------------ */
/* Session and global state                                            */
/* ------------------------------------------------------------------ */

/** Who/what is open. `demo` is the clearly labelled synthetic workspace. */
export type SessionState =
  | { kind: 'first-use' }
  | { kind: 'pairing' }
  | { kind: 'pairing-error'; message: string }
  /** A paired local brain. In this prototype it is a preview with nothing stored. */
  | { kind: 'local'; preview: true }
  | { kind: 'demo'; workspaceName: string };

/** The state Today is in. Drives the hero copy and the living field. */
export type BrainState = 'new' | 'quiet' | 'active' | 'review' | 'failure' | 'paused' | 'offline';

/** The visual treatment of the living field (brief: "Create a recognizable living field"). */
export type FieldState =
  | 'ready'
  | 'organizing'
  | 'current'
  | 'review'
  | 'quiet'
  | 'paused'
  | 'offline'
  | 'failed';

export type BackgroundHelpState = 'on' | 'paused' | 'quiet-hours' | 'offline';

export type Appearance = 'light' | 'dark' | 'system';

export type Route =
  | { name: 'today' }
  | { name: 'brain'; sourceId?: string }
  | { name: 'connections' }
  | { name: 'settings' }
  | { name: 'components' };

/* ------------------------------------------------------------------ */
/* Sources ("Your brain")                                              */
/* ------------------------------------------------------------------ */

export type SourceType = 'note' | 'decision' | 'goal' | 'question' | 'import';

/** Freshness of a source or of BiBrain's understanding of it. */
export type SourceStatus = 'current' | 'updating' | 'stale' | 'withdrawn';

export interface ProjectRef {
  id: string;
  name: string;
}

export interface SourceSummary {
  id: string;
  title: string;
  type: SourceType;
  /** `null` = Inbox */
  project: ProjectRef | null;
  updatedAt: string; // ISO date
  status: SourceStatus;
  /** Plain text used for display and keyword matching only. */
  excerpt: string;
}

export interface SourceVersion {
  version: number;
  savedAt: string;
  note: string;
}

/** What BiBrain remembers – each statement keeps its kind visible. */
export type UnderstandingKind =
  | 'source-backed'
  | 'user-correction'
  | 'hypothesis'
  | 'updating'
  | 'stale'
  | 'withdrawn';

export interface UnderstandingStatement {
  id: string;
  kind: UnderstandingKind;
  text: string;
  /** Exact source + version a statement came from. Required for factual statements. */
  citation?: { sourceId: string; version: number; quote: string };
  note?: string;
}

export interface SourceDetail extends SourceSummary {
  original: string;
  sourceIdentifier: string;
  versions: SourceVersion[];
  understanding: UnderstandingStatement[];
  usedIn: { id: string; title: string; kind: 'prepared' | 'brief' }[];
}

/* ------------------------------------------------------------------ */
/* Search                                                              */
/* ------------------------------------------------------------------ */

export type SearchScope = { kind: 'everything' } | { kind: 'inbox' } | { kind: 'project'; projectId: string };

export interface SearchFilters {
  types: SourceType[];
  updated: 'any' | 'week' | 'month';
}

export interface SearchResult {
  source: SourceSummary;
  /** One bounded snippet with the matched words marked as [start, end) ranges. */
  snippet: string;
  highlights: [number, number][];
}

export type SearchState =
  | { kind: 'empty' }
  | { kind: 'loading'; query: string }
  | { kind: 'results'; query: string; results: SearchResult[] }
  | { kind: 'no-results'; query: string };

/* ------------------------------------------------------------------ */
/* Capture                                                             */
/* ------------------------------------------------------------------ */

export interface CaptureDraft {
  title: string;
  content: string;
  destination: ProjectRef | null; // null = Inbox
  importedFileName?: string;
}

/** What the service returned after a durable write. Never the raw draft. */
export interface SavedReceiptVM {
  sourceId: string;
  title: string;
  retainedContent: string;
  sourceIdentifier: string;
  destination: ProjectRef | null;
  savedAt: string;
}

export type CaptureState =
  | { kind: 'empty' }
  | { kind: 'drafting' }
  | { kind: 'saving' }
  | { kind: 'saved'; receipt: SavedReceiptVM }
  | { kind: 'duplicate'; existing: SourceSummary }
  | { kind: 'too-large'; currentChars: number; limitChars: number }
  | { kind: 'unsupported-file'; fileName: string }
  | { kind: 'write-failed'; message: string };

/** Preparation is tracked separately so a failure can never undo a confirmed save. */
export type PreparationState = 'idle' | 'preparing' | 'prepared' | 'delayed' | 'failed';

/* ------------------------------------------------------------------ */
/* Prepared work                                                       */
/* ------------------------------------------------------------------ */

export type PreparedStatus = 'prepared' | 'accepted' | 'snoozed' | 'dismissed' | 'stale';

export type EvidenceState = 'complete' | 'partial' | 'unavailable' | 'source-removed';

export interface EvidenceExcerpt {
  sourceId: string;
  sourceTitle: string;
  version: number;
  date: string;
  quote: string;
  available: boolean;
}

export interface PreparedItem {
  id: string;
  project: ProjectRef;
  goal: string;
  title: string;
  whyNow: string;
  status: PreparedStatus;
  earlierUnderstanding: string;
  suggestedChange: string;
  evidence: EvidenceExcerpt[];
  unknowns: { kind: 'unknown' | 'hypothesis'; text: string }[];
  artifact: string;
  /** True when a newer edit exists after acceptance; direct undo becomes Compare versions. */
  laterWorkExists?: boolean;
}

export type RevisionState = 'clean' | 'conflict' | 'newer-edit';

/* ------------------------------------------------------------------ */
/* Connections                                                         */
/* ------------------------------------------------------------------ */

/** The only six connection states. `connected` is set ONLY after a verified round trip. */
export type ConnectionState =
  | 'not-connected'
  | 'awaiting-authorization'
  | 'checking'
  | 'connected'
  | 'needs-attention'
  | 'revoked';

export interface KnowledgeSourceConnection {
  id: string;
  kind: 'knowledge';
  name: string;
  sourceType: string;
  scope: string;
  lastSuccessfulCheck: string | null;
  freshness: 'fresh' | 'behind' | 'unknown';
  state: ConnectionState;
  importedCount: number;
}

export interface AgentGrant {
  id: string;
  kind: 'agent';
  label: string;
  readableProjects: ProjectRef[];
  canPropose: boolean;
  expiresAt: string | null;
  lastVerifiedAccess: string | null;
  state: ConnectionState;
}

export type PermissionPreviewVariant = 'read-only' | 'propose-enabled' | 'expiring' | 'revoked';

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

export interface SettingsVM {
  appearance: Appearance;
  backgroundHelp: {
    remember: boolean;
    prepare: boolean;
    paused: boolean;
    quietHoursOn: boolean;
    quietFrom: string;
    quietTo: string;
    timeZone: string;
  };
  spending: {
    providerConsent: boolean;
    dailyCap: string;
    perJobCap: string;
  };
}

/* ------------------------------------------------------------------ */
/* Notices                                                             */
/* ------------------------------------------------------------------ */

export type NoticeTone = 'info' | 'attention' | 'failure' | 'success' | 'offline';

export interface Toast {
  id: number;
  tone: NoticeTone;
  text: string;
  action?: { label: string; onAction: () => void };
}
